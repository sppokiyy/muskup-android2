package app.muskup.remote

import android.app.Application
import android.os.SystemClock
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import org.webrtc.IceCandidate
import org.webrtc.PeerConnection
import org.webrtc.VideoTrack
import kotlin.math.roundToInt

sealed interface SessionState {
    data object Idle : SessionState
    data class Requesting(val peerId: String) : SessionState
    data object Connecting : SessionState
    data object Active : SessionState
}

enum class NoticeKind { Success, Warning, Error }
data class Notice(val kind: NoticeKind, val text: String, val stamp: Long = SystemClock.elapsedRealtime())
data class Perms(val control: Boolean = false, val macros: Boolean = false)
data class Stats(val fps: Int = 0, val mbps: Float = 0f, val pingMs: Int = -1)

data class PendingRun(val deviceId: String, val macroId: String)

val MODS = listOf("Ctrl", "Alt", "Shift", "Win")

class SessionVm(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)
    val settings: StateFlow<Settings?> = prefs.flow.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val signaling = Signaling(viewModelScope)
    val engine by lazy { RtcEngine(app) }

    private val _state = MutableStateFlow<SessionState>(SessionState.Idle)
    val state = _state.asStateFlow()
    private val _notice = MutableStateFlow<Notice?>(null)
    val notice = _notice.asStateFlow()
    private val _video = MutableStateFlow<VideoTrack?>(null)
    val video = _video.asStateFlow()
    private val _videoSize = MutableStateFlow(Pair(0, 0))
    val videoSize = _videoSize.asStateFlow()
    private val _perms = MutableStateFlow(Perms())
    val perms = _perms.asStateFlow()
    private val _stats = MutableStateFlow(Stats())
    val stats = _stats.asStateFlow()
    private val _mods = MutableStateFlow<Map<String, Int>>(emptyMap())
    val mods = _mods.asStateFlow()
    val controlEnabled = MutableStateFlow(true)
    val pending = MutableStateFlow<PendingRun?>(null)
    private var permsReceived = false
    val macros: StateFlow<List<Macro>> =
        settings.map { parseMacros(it?.macrosJson) }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private var peer: Peer? = null
    private var peerId: String? = null
    private var timeoutJob: Job? = null
    private var statsJob: Job? = null
    private val earlyIce = ArrayList<IceCandidate>()

    private fun str(id: Int) = getApplication<Application>().getString(id)

    init {
        viewModelScope.launch { prefs.ensureId() }
        viewModelScope.launch {
            prefs.flow.collect { s ->
                if (s.myId.isNotEmpty()) signaling.configure(s.serverUrl.trim(), s.myId)
            }
        }
        viewModelScope.launch { signaling.events.collect { onSignal(it) } }
    }

    // ---------- налаштування ----------
    fun saveString(k: androidx.datastore.preferences.core.Preferences.Key<String>, v: String) =
        viewModelScope.launch { prefs.setString(k, v) }
    fun saveBool(k: androidx.datastore.preferences.core.Preferences.Key<Boolean>, v: Boolean) =
        viewModelScope.launch { prefs.setBool(k, v) }

    fun clearNotice() { _notice.value = null }
    private fun post(kind: NoticeKind, text: String) { _notice.value = Notice(kind, text) }
    fun onVideoSize(w: Int, h: Int) { _videoSize.value = Pair(w, h) }

    // ---------- підключення ----------
    fun connect(id: String, pass: String) {
        val s = settings.value ?: return
        if (s.serverUrl.isBlank()) { post(NoticeKind.Error, str(R.string.need_server)); return }
        if (!signaling.registered.value) { post(NoticeKind.Error, str(R.string.no_server_conn)); return }
        if (_state.value != SessionState.Idle) return
        peerId = id
        saveString(K.lastPeer, id)
        pending.value?.let { if (it.deviceId.isNotBlank() && it.deviceId != id) pending.value = null }
        AppLog.log("vm", "connect-request to $id")
        _state.value = SessionState.Requesting(id)
        signaling.send(jo("type" to "connect-request", "to" to id, "pass" to pass))
        timeoutJob?.cancel()
        timeoutJob = viewModelScope.launch {
            delay(65_000)
            hangupAndClose(Notice(NoticeKind.Error, str(R.string.err_timeout)))
        }
    }

    /** Кнопка «Скасувати» / червона кнопка завершення. */
    fun cancel() = hangupAndClose(null)

    /** Виставляє MainActivity: true, поки застосунок згорнуто. */
    @Volatile var inBackground = false
    @Volatile var bgReason = ""

    fun onBackgroundTimeout() {
        val st = _state.value
        if (st == SessionState.Idle) return
        // Очікування згоди власника ПК — це ще не сеанс: не обриваємо, а перевіряємо знову.
        // Якщо підключення відбудеться, поки застосунок згорнуто, наступна перевірка закриє сеанс.
        if (st is SessionState.Requesting || st == SessionState.Connecting) {
            viewModelScope.launch { delay(5000); if (inBackground) onBackgroundTimeout() }
            return
        }
        val t = str(R.string.bg_closed) + if (bgReason.isNotBlank()) " ($bgReason)" else ""
        AppLog.log("vm", "background close: $t")
        hangupAndClose(Notice(NoticeKind.Warning, t))
        Toast.makeText(getApplication(), t, Toast.LENGTH_LONG).show()
    }

    private fun hangupAndClose(n: Notice?) {
        peerId?.let { signaling.send(jo("type" to "hangup", "to" to it)) }
        closeAll()
        if (n != null) _notice.value = n
    }

    private fun closeAll() {
        _state.value = SessionState.Idle
        timeoutJob?.cancel(); statsJob?.cancel()
        releaseAllMods()
        peer?.close(); peer = null
        peerId = null
        earlyIce.clear()
        _video.value = null
        _videoSize.value = Pair(0, 0)
        _perms.value = Perms(); permsReceived = false
        _stats.value = Stats()
        controlEnabled.value = true
    }

    private fun fromOk(m: JsonObject): Boolean { val f = m.str("from"); return f == null || f == peerId }

    private fun onSignal(m: JsonObject) {
        when (m.str("type")) {
            "connect-response" -> {
                if (_state.value !is SessionState.Requesting || !fromOk(m)) return
                timeoutJob?.cancel()
                if (m.bool("ok") == true) {
                    _state.value = SessionState.Connecting
                    timeoutJob = viewModelScope.launch {
                        delay(30_000)
                        hangupAndClose(Notice(NoticeKind.Error, str(R.string.err_timeout)))
                    }
                } else {
                    val t = when (m.str("reason")) {
                        "rejected" -> R.string.err_rejected
                        "bad-pass" -> R.string.err_badpass
                        "busy" -> R.string.err_busy
                        "locked" -> R.string.err_locked
                        else -> R.string.notice_err
                    }
                    closeAll(); post(NoticeKind.Error, str(t))
                }
            }
            "peer-offline" -> if (_state.value is SessionState.Requesting) {
                closeAll(); post(NoticeKind.Error, str(R.string.err_offline))
            }
            "offer" -> if (_state.value == SessionState.Connecting && fromOk(m)) onOffer(m)
            "ice" -> onIce(m)
            "hangup" -> if (_state.value != SessionState.Idle && fromOk(m)) {
                closeAll(); post(NoticeKind.Warning, str(R.string.notice_warn))
            }
        }
    }

    private fun onOffer(m: JsonObject) {
        val sdp = (m["sdp"] as? JsonObject)?.str("sdp") ?: return
        timeoutJob?.cancel()
        val s = settings.value
        val servers = buildList {
            add(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer())
            add(PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer())
            if (s != null && s.turnUrl.isNotBlank()) {
                add(PeerConnection.IceServer.builder(s.turnUrl.trim())
                    .setUsername(s.turnUser).setPassword(s.turnPass).createIceServer())
            }
        }
        val p = Peer(engine, servers, object : Peer.Callbacks {
            override fun onLocalIce(c: IceCandidate) {
                viewModelScope.launch {
                    val to = peerId ?: return@launch
                    signaling.send(jo("type" to "ice", "to" to to, "candidate" to jo(
                        "candidate" to c.sdp, "sdpMid" to c.sdpMid, "sdpMLineIndex" to c.sdpMLineIndex)))
                }
            }
            override fun onVideo(t: VideoTrack) { viewModelScope.launch { _video.value = t } }
            override fun onCtlText(s: String) { viewModelScope.launch { onCtl(s) } }
            override fun onState(s: PeerConnection.PeerConnectionState) { viewModelScope.launch { onPeerState(s) } }
        })
        peer = p
        earlyIce.toList().forEach { p.addIce(it) }; earlyIce.clear()
        p.handleOffer(sdp,
            onAnswer = { ans ->
                viewModelScope.launch {
                    val to = peerId ?: return@launch
                    signaling.send(jo("type" to "answer", "to" to to, "sdp" to jo("type" to "answer", "sdp" to ans)))
                }
            },
            onFail = { e ->
                AppLog.log("rtc", "offer failed: $e")
                viewModelScope.launch { hangupAndClose(Notice(NoticeKind.Error, str(R.string.notice_err))) }
            })
    }

    private fun onIce(m: JsonObject) {
        if (!fromOk(m)) return
        val c = m["candidate"] as? JsonObject ?: return
        val line = c.str("candidate")
        if (line.isNullOrBlank()) return
        val ic = IceCandidate(c.str("sdpMid"), c.int("sdpMLineIndex") ?: 0, line)
        val p = peer
        if (p != null) p.addIce(ic) else if (_state.value == SessionState.Connecting) earlyIce.add(ic)
    }

    private fun onPeerState(s: PeerConnection.PeerConnectionState) {
        when (s) {
            PeerConnection.PeerConnectionState.CONNECTED -> if (_state.value == SessionState.Connecting) {
                _state.value = SessionState.Active
                post(NoticeKind.Success, str(R.string.notice_ok))
                startStats()
                maybeRunPending()
            }
            PeerConnection.PeerConnectionState.FAILED, PeerConnection.PeerConnectionState.CLOSED ->
                if (_state.value == SessionState.Active || _state.value == SessionState.Connecting) {
                    val wasActive = _state.value == SessionState.Active
                    hangupAndClose(Notice(if (wasActive) NoticeKind.Warning else NoticeKind.Error,
                        str(if (wasActive) R.string.notice_warn else R.string.notice_err)))
                }
            PeerConnection.PeerConnectionState.DISCONNECTED -> {
                val p = peer
                viewModelScope.launch {
                    delay(10_000)
                    if (peer === p && p != null && p.connectionState() == PeerConnection.PeerConnectionState.DISCONNECTED
                        && _state.value != SessionState.Idle) {
                        hangupAndClose(Notice(NoticeKind.Warning, str(R.string.notice_warn)))
                    }
                }
            }
            else -> {}
        }
    }

    private fun onCtl(text: String) {
        val o = parseObj(text) ?: return
        when (o.str("t")) {
            "perms" -> {
                _perms.value = Perms(o.bool("control") == true, o.bool("macros") == true)
                AppLog.log("ctl", "perms=${_perms.value}")
                permsReceived = true
                maybeRunPending()
            }
            "denied" -> post(NoticeKind.Warning,
                str(if (o.str("what") == "macros") R.string.denied_macros else R.string.denied_control))
        }
    }

    private fun startStats() {
        statsJob?.cancel()
        var lastBytes = -1L; var lastT = 0L
        statsJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                val p = peer ?: break
                p.stats { fps, bytes, rtt ->
                    val now = SystemClock.elapsedRealtime()
                    val mbps = if (lastBytes >= 0 && now > lastT) (bytes - lastBytes) * 8f / ((now - lastT) * 1000f) else 0f
                    lastBytes = bytes; lastT = now
                    _stats.value = Stats(fps, mbps.coerceAtLeast(0f), rtt)
                }
            }
        }
    }

    // ---------- швидкі команди ----------
    fun saveMacros(list: List<Macro>) { saveString(K.macros, JX.encodeToString(Export(1, list))) }
    fun upsertMacro(m: Macro) {
        val l = macros.value.toMutableList()
        val i = l.indexOfFirst { it.id == m.id }
        if (i >= 0) l[i] = m else l.add(m)
        saveMacros(l)
    }
    fun deleteMacro(id: String) = saveMacros(macros.value.filter { it.id != id })
    fun exportJson(): String = JX.encodeToString(Export(1, macros.value))

    /** Повертає кількість імпортованих команд або -1 при помилці. Некоректні команди пропускаються. */
    fun importJson(text: String?): Int {
        if (text.isNullOrBlank()) return -1
        val list = runCatching { JX.decodeFromString<Export>(text).macros }.getOrNull() ?: return -1
        val ok = list.filter { it.name.isNotBlank() && validateSteps(it.steps) == null }
            .map { if (it.id.isBlank()) it.copy(id = newId()) else it }
        if (ok.isEmpty()) return -1
        val cur = macros.value.toMutableList()
        ok.forEach { m -> val i = cur.indexOfFirst { it.id == m.id }; if (i >= 0) cur[i] = m else cur.add(m) }
        saveMacros(cur)
        return ok.size
    }

    fun runMacro(m: Macro): Boolean {
        if (_state.value != SessionState.Active) return false
        if (!_perms.value.macros) { post(NoticeKind.Warning, str(R.string.denied_macros)); return false }
        val err = validateSteps(m.steps)
        if (err != null) { post(NoticeKind.Error, str(err)); return false }
        AppLog.log("macro", "run ${m.name} (${m.steps.size} steps)")
        return peer?.sendCtl(jo("t" to "macro", "steps" to JsonArray(m.steps)).toString()) ?: false
    }
    fun stopMacro() { peer?.sendCtl("""{"t":"stop"}""") }

    fun setPending(device: String, macroId: String) { pending.value = PendingRun(device, macroId) }

    private fun maybeRunPending() {
        val p = pending.value ?: return
        if (_state.value != SessionState.Active || !permsReceived) return
        pending.value = null
        macros.value.firstOrNull { it.id == p.macroId }?.let { runMacro(it) }
    }

    // ---------- введення (Клієнт → хост) ----------
    private val canControl get() = _perms.value.control && controlEnabled.value && _state.value == SessionState.Active
    private var cx = 0.5f
    private var cy = 0.5f
    private var lastMv = 0L

    private fun sendMvNow() {
        val x = (cx * 65535f).roundToInt().coerceIn(0, 65535)
        val y = (cy * 65535f).roundToInt().coerceIn(0, 65535)
        peer?.sendMv("""{"t":"m","x":$x,"y":$y}""")
    }

    /** Нормалізовані координати кадру 0..1 → 0..65535. Throttle ~8 мс. */
    fun moveTo(nx: Float, ny: Float, force: Boolean = false) {
        if (!canControl) return
        cx = nx.coerceIn(0f, 1f); cy = ny.coerceIn(0f, 1f)
        val now = SystemClock.elapsedRealtimeNanos()
        if (!force && now - lastMv < 8_000_000) return
        lastMv = now; sendMvNow()
    }
    fun moveBy(dx: Float, dy: Float) = moveTo(cx + dx, cy + dy)
    fun flushMove() { if (canControl) { lastMv = SystemClock.elapsedRealtimeNanos(); sendMvNow() } }

    fun button(b: String, down: Boolean) {
        if (!canControl) return
        flushMove()
        peer?.sendCtl("""{"t":"b","b":"$b","d":${if (down) 1 else 0}}""")
    }
    fun click(b: String) { button(b, true); button(b, false) }

    fun wheel(dx: Int, dy: Int) {
        if (!canControl) return
        val x = dx.coerceIn(-1200, 1200); val y = dy.coerceIn(-1200, 1200)
        if (x == 0 && y == 0) return
        peer?.sendCtl("""{"t":"w","dy":$y,"dx":$x}""")
    }

    private fun key(n: String, down: Boolean) {
        peer?.sendCtl("""{"t":"k","n":"$n","d":${if (down) 1 else 0}}""")
    }

    fun pressKey(name: String) {
        if (!canControl) return
        key(name, true); key(name, false)
        releaseSticky()
    }

    /** Текст з системної клавіатури → {"t":"t","s":...}. З активним модифікатором A–Z/0–9 йдуть як клавіші. */
    fun typed(text: String) {
        if (!canControl || text.isEmpty()) return
        val anyMod = _mods.value.values.any { it > 0 }
        if (anyMod && text.length == 1 && text[0].isLetterOrDigit() && text[0].code < 128) {
            pressKey(text[0].uppercaseChar().toString()); return
        }
        peer?.sendCtl("""{"t":"t","s":${JsonPrimitive(text)}}""")
        releaseSticky()
    }

    /** Модифікатор: 0 → залипання (1) → фіксація (2) → вимкнено. */
    fun toggleMod(name: String) {
        if (!canControl) return
        val cur = _mods.value[name] ?: 0
        val next = (cur + 1) % 3
        if (cur == 0) key(name, true)
        if (next == 0) key(name, false)
        _mods.value = _mods.value + (name to next)
    }

    private fun releaseSticky() {
        val m = _mods.value
        if (m.none { it.value == 1 }) return
        m.filter { it.value == 1 }.keys.forEach { key(it, false) }
        _mods.value = m.mapValues { if (it.value == 1) 0 else it.value }
    }

    private fun releaseAllMods() {
        _mods.value.filter { it.value > 0 }.keys.forEach { key(it, false) }
        _mods.value = emptyMap()
    }

    override fun onCleared() { closeAll(); super.onCleared() }
}
