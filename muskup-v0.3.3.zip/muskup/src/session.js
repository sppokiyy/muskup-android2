// Приводить адресу сервера до вигляду wss://хост (приймає https://, без схеми, з пробілами і слешем)
window.normalizeServerUrl = function (raw) {
  let u = String(raw || '').trim().replace(/\s+/g, '');
  if (!u) return '';
  u = u.replace(/^https:\/\//i, 'wss://').replace(/^http:\/\//i, 'ws://');
  if (!/^wss?:\/\//i.test(u)) u = 'wss://' + u;
  return u.replace(/\/+$/, '');
};
// Сигналізація (WebSocket) + WebRTC. Хост віддає екран, клієнт дивиться.
window.createSession = function (api) {
  const QUALITY = {
    fast: { bitrate: 6000000, fps: 60 },
    balanced: { bitrate: 3000000, fps: 30 },
    best: { bitrate: 12000000, fps: 60 }
  };
  let ws = null, reconnectTimer = null, pingTimer = null;
  let state = 'idle'; // idle | calling | connecting | hosting | active
  let peer = null, pc = null, stream = null, role = null;
  let pendingIce = [], remoteSet = false;
  let statsTimer = null, reqTimer = null, discTimer = null;
  let pendingReq = null;
  let ctl = null, mv = null, hostPerms = null;
  const deniedShown = {};
  const attempts = {};

  const S = () => api.settings();
  const log = (m) => api.log('info', '[rtc] ' + m);
  const send = (o) => { if (ws && ws.readyState === 1) ws.send(JSON.stringify(o)); };
  const rtcConfig = () => ({
    iceServers: [{ urls: 'stun:stun.l.google.com:19302' }, { urls: 'stun:stun1.l.google.com:19302' }].concat(S().iceServers || []),
    bundlePolicy: 'max-bundle'
  });

  // ---------- Сигналізація ----------
  function connectSignal() {
    clearTimeout(reconnectTimer);
    const url = window.normalizeServerUrl(S().serverUrl);
    if (!url) { api.online(false); return; }
    log('Підключення до ' + url);
    try { ws = new WebSocket(url); } catch (e) {
      log('Невірна адреса сервера: ' + e.message);
      api.online(false);
      reconnectTimer = setTimeout(connectSignal, 5000);
      return;
    }
    ws.onopen = () => {
      log('Сервер: з\'єднання відкрито');
      send({ type: 'register', id: S().myId });
      clearInterval(pingTimer);
      pingTimer = setInterval(() => { if (ws && ws.readyState === 1) ws.send('ping'); }, 25000);
    };
    ws.onmessage = (e) => { let m; try { m = JSON.parse(e.data); } catch (_) { return; } onSignal(m); };
    ws.onclose = (e) => { log('Сервер: з\'єднання закрито, код ' + (e && e.code)); clearInterval(pingTimer); api.online(false); reconnectTimer = setTimeout(connectSignal, 4000); };
    ws.onerror = () => { log('Сервер: помилка WebSocket (перевірте адресу wss://...)'); };
  }
  function reconnect() {
    clearTimeout(reconnectTimer);
    if (ws) { ws.onclose = null; try { ws.close(); } catch (_) {} }
    api.online(false);
    connectSignal();
  }

  function onSignal(m) {
    switch (m.type) {
      case 'registered': api.online(true); log('Зареєстровано на сервері'); break;
      case 'id-taken': log('ID зайнятий, повтор через 5 с...'); setTimeout(() => send({ type: 'register', id: S().myId }), 5000); break;
      case 'peer-offline': if (state === 'calling') fail('toastErr'); break;
      case 'connect-request': onRequest(m); break;
      case 'connect-response': onResponse(m); break;
      case 'offer': if (m.from === peer) onOffer(m); break;
      case 'answer': if (m.from === peer) onAnswer(m); break;
      case 'ice': if (m.from === peer) onIce(m); break;
      case 'hangup': if (m.from === peer) end(false, 'remote'); break;
    }
  }

  // ---------- Клієнт: запит на підключення ----------
  function connect(id, pass) {
    id = String(id).replace(/\D/g, '');
    if (state !== 'idle') return;
    if (id.length !== 9 || id === S().myId || !ws || ws.readyState !== 1) return api.toast('err', 'toastErr');
    state = 'calling'; peer = id; role = 'client';
    log('Запит підключення до ' + id);
    send({ type: 'connect-request', to: id, pass: String(pass || '') });
    api.toast('info', 'toastWaiting');
    reqTimer = setTimeout(() => { if (state === 'calling') fail('toastErr'); }, 60000);
  }
  function onResponse(m) {
    if (state !== 'calling' || m.from !== peer) return;
    clearTimeout(reqTimer);
    if (!m.ok) {
      const key = m.reason === 'rejected' ? 'toastRejected' : m.reason === 'bad-pass' ? 'toastBadPass' : m.reason === 'busy' ? 'toastBusy' : 'toastErr';
      return fail(key);
    }
    state = 'connecting';
  }
  function fail(key) {
    cleanup();
    api.toast('err', key);
  }

  // ---------- Хост: вхідний запит ----------
  function reply(to, ok, reason) { send({ type: 'connect-response', to, ok, reason }); }
  function onRequest(m) {
    if (state !== 'idle' || pendingReq) return reply(m.from, false, 'busy');
    attempts[m.from] = (attempts[m.from] || 0) + 1;
    if (attempts[m.from] > 5) return reply(m.from, false, 'locked');
    if (String(m.pass) !== S().tempPass) { log('Невірний пароль від ' + m.from); return reply(m.from, false, 'bad-pass'); }
    pendingReq = m.from;
    let done = false;
    const decide = (allow, perms) => {
      if (done) return; done = true; clearTimeout(t); pendingReq = null; api.incomingClose();
      if (!allow) { log('Відхилено: ' + m.from); return reply(m.from, false, 'rejected'); }
      attempts[m.from] = 0;
      acceptHost(m.from, perms);
    };
    const t = setTimeout(() => decide(false), 30000);
    api.incoming(m.from, decide);
  }
  async function acceptHost(from, perms) {
    state = 'hosting'; peer = from; role = 'host';
    hostPerms = { control: !!(perms && perms.control), macros: !!(perms && perms.macros) };
    reply(from, true);
    log('Дозволено підключення: ' + from);
    try { await startHost(); } catch (e) { log('Помилка старту хоста: ' + (e.stack || e)); end(true, 'error'); }
  }

  // ---------- WebRTC ----------
  function newPc() {
    pc = new RTCPeerConnection(rtcConfig());
    pendingIce = []; remoteSet = false;
    pc.onicecandidate = (e) => { if (e.candidate) send({ type: 'ice', to: peer, candidate: e.candidate }); };
    pc.onconnectionstatechange = () => {
      const s = pc.connectionState;
      log('Стан з\'єднання: ' + s);
      clearTimeout(discTimer);
      if (s === 'connected') {
        state = role === 'host' ? 'hosting' : 'active';
        if (role === 'host') api.hostActive(true, hostPerms, peer);
        api.connected(role, peer);
        if (role === 'client') startStats();
      } else if (s === 'disconnected') {
        discTimer = setTimeout(() => { if (pc && pc.connectionState !== 'connected') end(true, 'lost'); }, 6000);
      } else if (s === 'failed') end(true, 'lost');
    };
  }
  function preferCodecs(tr) {
    try {
      const rank = (c) => /h264/i.test(c.mimeType) ? 0 : /vp8/i.test(c.mimeType) ? 1 : /vp9/i.test(c.mimeType) ? 2 : 3;
      tr.setCodecPreferences(RTCRtpSender.getCapabilities('video').codecs.slice().sort((a, b) => rank(a) - rank(b)));
    } catch (e) { log('Кодеки за замовчуванням: ' + e.message); }
  }
  async function tuneSender(sender) {
    const q = QUALITY[S().quality] || QUALITY.fast;
    const p = sender.getParameters();
    if (!p.encodings || !p.encodings.length) p.encodings = [{}];
    p.encodings[0].maxBitrate = q.bitrate;
    p.encodings[0].maxFramerate = q.fps;
    p.encodings[0].networkPriority = 'high';
    p.degradationPreference = 'maintain-framerate'; // при поганій мережі падає роздільність, а не плавність
    await sender.setParameters(p);
  }
  async function startHost() {
    const q = QUALITY[S().quality] || QUALITY.fast;
    stream = await navigator.mediaDevices.getDisplayMedia({
      video: { frameRate: { ideal: q.fps, max: q.fps }, width: { max: 1920 }, height: { max: 1080 }, cursor: 'always' },
      audio: false
    });
    const track = stream.getVideoTracks()[0];
    track.contentHint = 'motion';
    track.onended = () => end(true, 'local');
    newPc();
    ctl = pc.createDataChannel('ctl');
    mv = pc.createDataChannel('mv', { ordered: false, maxRetransmits: 0 });
    ctl.onopen = () => sendCtl({ t: 'perms', control: hostPerms.control, macros: hostPerms.macros });
    ctl.onmessage = (e) => onHostMsg(e.data);
    mv.onmessage = (e) => onHostMsg(e.data);
    const tr = pc.addTransceiver(track, { direction: 'sendonly', streams: [stream] });
    preferCodecs(tr);
    await tuneSender(tr.sender);
    await pc.setLocalDescription(await pc.createOffer());
    send({ type: 'offer', to: peer, sdp: pc.localDescription });
  }
  async function onOffer(m) {
    if (role !== 'client') return;
    newPc();
    pc.ondatachannel = (e) => {
      if (e.channel.label === 'ctl') { ctl = e.channel; ctl.onmessage = (ev) => onClientMsg(ev.data); }
      else if (e.channel.label === 'mv') mv = e.channel;
    };
    pc.ontrack = (e) => {
      try { e.receiver.jitterBufferTarget = 30; } catch (_) {}
      try { e.receiver.playoutDelayHint = 0; } catch (_) {}
      api.stream(e.streams[0] || new MediaStream([e.track]));
    };
    await pc.setRemoteDescription(m.sdp);
    remoteSet = true;
    await flushIce();
    await pc.setLocalDescription(await pc.createAnswer());
    send({ type: 'answer', to: peer, sdp: pc.localDescription });
  }
  async function onAnswer(m) {
    if (!pc || role !== 'host') return;
    await pc.setRemoteDescription(m.sdp);
    remoteSet = true;
    await flushIce();
  }
  async function onIce(m) {
    if (pc && remoteSet) { try { await pc.addIceCandidate(m.candidate); } catch (_) {} }
    else pendingIce.push(m.candidate);
  }
  async function flushIce() {
    for (const c of pendingIce) { try { await pc.addIceCandidate(c); } catch (_) {} }
    pendingIce = [];
  }

  // ---------- Статистика (клієнт) ----------
  function startStats() {
    let lastBytes = 0, lastT = 0;
    clearInterval(statsTimer);
    statsTimer = setInterval(async () => {
      if (!pc) return;
      const rep = await pc.getStats();
      let fps = 0, rtt = 0, bytes = 0;
      rep.forEach((r) => {
        if (r.type === 'inbound-rtp' && r.kind === 'video') { fps = r.framesPerSecond || 0; bytes = r.bytesReceived; }
        if (r.type === 'candidate-pair' && r.nominated && r.currentRoundTripTime) rtt = r.currentRoundTripTime * 1000;
      });
      const now = performance.now();
      const mbps = lastT ? ((bytes - lastBytes) * 8) / ((now - lastT) / 1000) / 1e6 : 0;
      lastBytes = bytes; lastT = now;
      api.stats({ fps: Math.round(fps), rtt: Math.round(rtt), mbps: mbps.toFixed(1) });
    }, 1000);
  }

  // ---------- Канал керування ----------
  function sendCtl(o) { if (ctl && ctl.readyState === 'open') ctl.send(JSON.stringify(o)); }
  function sendMove(o) { if (mv && mv.readyState === 'open') mv.send(JSON.stringify(o)); }
  function onHostMsg(raw) { // повідомлення від клієнта; права перевіряє ХОСТ
    let m; try { m = JSON.parse(raw); } catch (_) { return; }
    if (!hostPerms) return;
    const need = m.t === 'macro' ? 'macros' : ('mbwk'.includes(m.t) && m.t.length === 1) ? 'control' : null;
    if (m.t === 'stop') return api.input(m);
    if (!need) return;
    if (!hostPerms[need]) { sendCtl({ t: 'denied', what: need }); return; }
    api.input(m);
  }
  function onClientMsg(raw) {
    let m; try { m = JSON.parse(raw); } catch (_) { return; }
    if (m.t === 'perms') api.perms({ control: !!m.control, macros: !!m.macros });
    else if (m.t === 'denied' && !deniedShown[m.what]) { deniedShown[m.what] = true; api.denied(m.what); }
  }

  // ---------- Завершення ----------
  function cleanup() {
    clearTimeout(reqTimer); clearTimeout(discTimer); clearInterval(statsTimer);
    if (stream) { stream.getTracks().forEach((t) => { t.onended = null; t.stop(); }); stream = null; }
    if (pc) { pc.onconnectionstatechange = null; try { pc.close(); } catch (_) {} pc = null; }
    if (role === 'host' && hostPerms) api.hostActive(false, null, null);
    hostPerms = null; ctl = null; mv = null;
    pendingIce = []; remoteSet = false; peer = null; role = null; state = 'idle';
  }
  function end(notify, reason) {
    if (state === 'idle') return;
    const was = state;
    if (notify && peer) send({ type: 'hangup', to: peer });
    log('Сеанс завершено: ' + reason);
    cleanup();
    if (was === 'hosting' || was === 'active' || was === 'connecting') api.ended(reason);
  }

  return {
    start: connectSignal,
    reconnect,
    connect,
    end: () => end(true, 'local'),
    sendCtl,
    sendMove,
    state: () => state
  };
};
