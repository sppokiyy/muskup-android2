// Перехоплення миші/клавіатури клієнта і відправка на хост (координати нормалізовані 0..65535)
window.createRemoteInput = function (video, send, sendMove) {
  let enabled = false, active = false, pend = null, raf = 0;
  const down = new Set(), btns = new Set();
  const clamp = (v) => Math.min(1, Math.max(0, v));

  function content() {
    const r = video.getBoundingClientRect(), vw = video.videoWidth, vh = video.videoHeight;
    if (!vw || !vh) return null;
    const s = Math.min(r.width / vw, r.height / vh), w = vw * s, h = vh * s;
    return { l: r.left + (r.width - w) / 2, t: r.top + (r.height - h) / 2, w, h };
  }
  function pos(e) {
    const c = content(); if (!c) return null;
    return { x: Math.round(clamp((e.clientX - c.l) / c.w) * 65535), y: Math.round(clamp((e.clientY - c.t) / c.h) * 65535) };
  }
  function flush() { raf = 0; if (pend) { sendMove({ t: 'm', x: pend.x, y: pend.y }); pend = null; } }
  function queueMove(p) { pend = p; if (!raf) raf = requestAnimationFrame(flush); }

  const NAMES = { ControlLeft: 'Ctrl', ControlRight: 'Ctrl', AltLeft: 'Alt', AltRight: 'Alt', ShiftLeft: 'Shift', ShiftRight: 'Shift',
    MetaLeft: 'Win', MetaRight: 'Win', Enter: 'Enter', NumpadEnter: 'Enter', Escape: 'Esc', Space: 'Space', Backspace: 'Backspace', Tab: 'Tab',
    Delete: 'Delete', Insert: 'Insert', Home: 'Home', End: 'End', PageUp: 'PageUp', PageDown: 'PageDown',
    ArrowLeft: 'Left', ArrowRight: 'Right', ArrowUp: 'Up', ArrowDown: 'Down', Minus: '-', Equal: '=', Comma: ',', Period: '.',
    Slash: '/', Backquote: '`', BracketLeft: '[', BracketRight: ']', Backslash: '\\', Quote: "'", Semicolon: ';',
    CapsLock: 'CapsLock', ContextMenu: 'Apps', PrintScreen: 'PrintScreen' };
  function nameOf(code) {
    if (/^Key[A-Z]$/.test(code)) return code.slice(3);
    if (/^Digit\d$/.test(code)) return code.slice(5);
    if (/^F([1-9]|1[0-2])$/.test(code)) return code;
    if (/^Numpad\d$/.test(code)) return 'Num' + code.slice(6);
    return NAMES[code] || null;
  }
  const on = () => enabled && active;

  video.addEventListener('mousemove', (e) => { if (!on()) return; const p = pos(e); if (p) queueMove(p); });
  video.addEventListener('mousedown', (e) => {
    if (!on()) return; e.preventDefault();
    const p = pos(e); if (p) { pend = null; sendMove({ t: 'm', x: p.x, y: p.y }); }
    const b = e.button === 2 ? 'r' : e.button === 1 ? 'm' : 'l';
    btns.add(b); send({ t: 'b', b, d: 1 });
  });
  window.addEventListener('mouseup', (e) => {
    const b = e.button === 2 ? 'r' : e.button === 1 ? 'm' : 'l';
    if (btns.has(b)) { btns.delete(b); send({ t: 'b', b, d: 0 }); }
  });
  video.addEventListener('contextmenu', (e) => e.preventDefault());
  video.addEventListener('wheel', (e) => {
    if (!on()) return; e.preventDefault();
    const k = e.deltaMode === 1 ? 40 : 1.2;
    send({ t: 'w', dy: -Math.round(e.deltaY * k), dx: Math.round(e.deltaX * k) });
  }, { passive: false });

  function keyEv(e, d) {
    if (!on()) return;
    const tag = (e.target && e.target.tagName) || '';
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
    const n = nameOf(e.code); if (!n) return;
    e.preventDefault(); e.stopPropagation();
    if (d) down.add(n); else down.delete(n);
    send({ t: 'k', n, d });
  }
  window.addEventListener('keydown', (e) => keyEv(e, 1), true);
  window.addEventListener('keyup', (e) => keyEv(e, 0), true);
  function releaseAll() {
    down.forEach((n) => send({ t: 'k', n, d: 0 })); down.clear();
    btns.forEach((b) => send({ t: 'b', b, d: 0 })); btns.clear();
  }
  window.addEventListener('blur', releaseAll);

  return {
    setEnabled: (v) => { if (!v) releaseAll(); enabled = v; },
    setActive: (v) => { if (!v) releaseAll(); active = v; },
    isEnabled: () => enabled
  };
};
