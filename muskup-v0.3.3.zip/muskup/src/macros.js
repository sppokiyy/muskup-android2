// Швидкі команди («біндер»): шаблони, редактор, експорт/імпорт, плаваюча панель
window.createMacros = function (ctx) {
  const { $, t, get, save, toast } = ctx;
  const TYPES = ['key', 'text', 'wait', 'click', 'run', 'url'];
  const COLORS = ['#6d4aff', '#3b82f6', '#22c55e', '#ef4444', '#eab308', '#71717a', '#ec4899', '#06b6d4'];
  const ICONS = ['⌨', '💻', '📊', '📁', '⚙', '🔒', '🖥', '🌐', '▶', '📝', '📸', '🔊', '🎵', '🔍', '⚡', '🏠'];
  const clamp = (v, a, b) => Math.min(b, Math.max(a, Number(v) || 0));
  const uid = () => Math.random().toString(36).slice(2, 10);

  const TEMPLATES = [
    { id: 'tpl-cmd', name: 'CMD', icon: '⌨', color: '#71717a', steps: [{ type: 'key', combo: 'Win+R' }, { type: 'wait', ms: 300 }, { type: 'text', text: 'cmd' }, { type: 'key', combo: 'Enter' }] },
    { id: 'tpl-ps', name: 'PowerShell', icon: '💻', color: '#3b82f6', steps: [{ type: 'key', combo: 'Win+R' }, { type: 'wait', ms: 300 }, { type: 'text', text: 'powershell' }, { type: 'key', combo: 'Enter' }] },
    { id: 'tpl-tm', name: 'Диспетчер завдань', icon: '📊', color: '#22c55e', steps: [{ type: 'key', combo: 'Ctrl+Shift+Esc' }] },
    { id: 'tpl-ex', name: 'Провідник', icon: '📁', color: '#eab308', steps: [{ type: 'key', combo: 'Win+E' }] },
    { id: 'tpl-set', name: 'Налаштування', icon: '⚙', color: '#6d4aff', steps: [{ type: 'key', combo: 'Win+I' }] },
    { id: 'tpl-lock', name: 'Блокування', icon: '🔒', color: '#ef4444', steps: [{ type: 'run', target: 'rundll32.exe user32.dll,LockWorkStation' }] },
    { id: 'tpl-desk', name: 'Робочий стіл', icon: '🖥', color: '#06b6d4', steps: [{ type: 'key', combo: 'Win+D' }] },
    { id: 'tpl-note', name: 'Блокнот', icon: '📝', color: '#71717a', steps: [{ type: 'run', target: 'notepad' }] },
    { id: 'tpl-shot', name: 'Скріншот', icon: '📸', color: '#ec4899', steps: [{ type: 'key', combo: 'Win+Shift+S' }] },
    { id: 'tpl-yt', name: 'YouTube', icon: '▶', color: '#ef4444', steps: [{ type: 'url', url: 'https://www.youtube.com' }] },
    { id: 'tpl-g', name: 'Google', icon: '🌐', color: '#3b82f6', steps: [{ type: 'url', url: 'https://www.google.com' }] }
  ];

  function cleanStep(s) {
    if (!s || !TYPES.includes(s.type)) return null;
    switch (s.type) {
      case 'key': return { type: 'key', combo: String(s.combo || '').slice(0, 60) };
      case 'text': return { type: 'text', text: String(s.text || '').slice(0, 500) };
      case 'wait': return { type: 'wait', ms: clamp(s.ms, 0, 30000) };
      case 'click': return { type: 'click', x: clamp(s.x, 0, 100), y: clamp(s.y, 0, 100), button: s.button === 'right' ? 'right' : 'left', double: !!s.double };
      case 'run': return { type: 'run', target: String(s.target || '').replace(/[\r\n]/g, ' ').slice(0, 500) };
      case 'url': return { type: 'url', url: String(s.url || '').slice(0, 500) };
    }
  }
  function cleanMacro(m, keepId) {
    if (!m || typeof m !== 'object') return null;
    return {
      id: keepId && m.id ? String(m.id).slice(0, 40) : uid(),
      name: String(m.name || 'Без назви').slice(0, 40),
      icon: Array.from(String(m.icon || '⚡')).slice(0, 2).join('') || '⚡',
      color: /^#[0-9a-f]{6}$/i.test(m.color) ? m.color : COLORS[0],
      steps: (Array.isArray(m.steps) ? m.steps : []).slice(0, 100).map(cleanStep).filter(Boolean)
    };
  }
  const list = () => get().macros || [];
  async function setList(l) { await save({ macros: l }); }
  async function seed() { if (!get().macros) await setList(TEMPLATES.map((m) => cleanMacro(m, true))); }

  // ---------- Сітка кнопок ----------
  function renderGrid(el, onClick) {
    el.innerHTML = '';
    list().forEach((m) => {
      const b = document.createElement('button');
      b.className = 'mbtn'; b.style.setProperty('--mc', m.color);
      b.innerHTML = '<span class="mi"></span><span class="mn"></span>';
      b.querySelector('.mi').textContent = m.icon; b.querySelector('.mn').textContent = m.name;
      b.title = m.steps.length + ' ' + t('mSteps');
      b.onclick = () => onClick(m);
      el.appendChild(b);
    });
  }
  function renderLibrary() { renderGrid($('#macro-grid'), (m) => openEditor(m)); }

  // ---------- Редактор ----------
  let draft = null, isNew = false;
  const mk = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };
  function inp(type, val, onIn, ph, w) {
    const i = mk('input'); i.type = type; i.value = val; if (ph) i.placeholder = ph; if (w) i.style.width = w;
    i.oninput = () => onIn(type === 'number' ? Number(i.value) : i.value); return i;
  }
  const defaults = (type) => ({ key: { type, combo: '' }, text: { type, text: '' }, wait: { type, ms: 300 }, click: { type, x: 50, y: 50, button: 'left', double: false }, run: { type, target: '' }, url: { type, url: 'https://' } }[type]);

  function stepRow(s, i) {
    const row = mk('div', 'step');
    const h = mk('span', 'handle', '≡'); h.draggable = true;
    h.ondragstart = (e) => { e.dataTransfer.setData('text/plain', String(i)); e.dataTransfer.setDragImage(row, 10, 10); };
    row.ondragover = (e) => { e.preventDefault(); row.classList.add('over'); };
    row.ondragleave = () => row.classList.remove('over');
    row.ondrop = (e) => { e.preventDefault(); const from = Number(e.dataTransfer.getData('text/plain')); if (!Number.isNaN(from)) move(from, i); };
    const sel = mk('select', 'stype');
    TYPES.forEach((ty) => { const o = mk('option', null, t('st_' + ty)); o.value = ty; if (ty === s.type) o.selected = true; sel.appendChild(o); });
    sel.onchange = () => { draft.steps[i] = defaults(sel.value); renderSteps(); };
    const body = mk('div', 'sbody');
    if (s.type === 'key') body.appendChild(inp('text', s.combo, (v) => (s.combo = v), 'Win+R'));
    if (s.type === 'text') body.appendChild(inp('text', s.text, (v) => (s.text = v), 'cmd'));
    if (s.type === 'wait') { body.appendChild(inp('number', s.ms, (v) => (s.ms = v), '300', '110px')); body.appendChild(mk('span', 'muted', 'ms')); }
    if (s.type === 'run') body.appendChild(inp('text', s.target, (v) => (s.target = v), 'notepad'));
    if (s.type === 'url') body.appendChild(inp('text', s.url, (v) => (s.url = v), 'https://...'));
    if (s.type === 'click') {
      body.appendChild(mk('span', 'muted', 'X%')); body.appendChild(inp('number', s.x, (v) => (s.x = v), '', '70px'));
      body.appendChild(mk('span', 'muted', 'Y%')); body.appendChild(inp('number', s.y, (v) => (s.y = v), '', '70px'));
      const bs = mk('select'); bs.style.width = '110px';
      [['left', t('btnLeft')], ['right', t('btnRight')]].forEach(([v, l]) => { const o = mk('option', null, l); o.value = v; if (s.button === v) o.selected = true; bs.appendChild(o); });
      bs.onchange = () => (s.button = bs.value); body.appendChild(bs);
      const lab = mk('label', 'chk'); const cb = mk('input'); cb.type = 'checkbox'; cb.checked = !!s.double; cb.onchange = () => (s.double = cb.checked);
      lab.appendChild(cb); lab.appendChild(mk('span', null, t('dbl'))); body.appendChild(lab);
    }
    const up = mk('button', 'mini', '↑'); up.onclick = () => move(i, i - 1);
    const dn = mk('button', 'mini', '↓'); dn.onclick = () => move(i, i + 1);
    const rm = mk('button', 'mini danger', '✕'); rm.onclick = () => { draft.steps.splice(i, 1); renderSteps(); };
    [h, sel, body, up, dn, rm].forEach((e) => row.appendChild(e));
    return row;
  }
  function move(from, to) {
    if (to < 0 || to >= draft.steps.length || from === to) return;
    const [x] = draft.steps.splice(from, 1); draft.steps.splice(to, 0, x); renderSteps();
  }
  function renderSteps() {
    const box = $('#mc-steps'); box.innerHTML = '';
    if (!draft.steps.length) box.appendChild(mk('p', 'muted', t('noSteps')));
    draft.steps.forEach((s, i) => box.appendChild(stepRow(s, i)));
  }
  function renderPickers() {
    const c = $('#mc-colors'); c.innerHTML = '';
    COLORS.forEach((col) => {
      const b = mk('button', 'sw' + (draft.color === col ? ' sel' : '')); b.style.background = col; b.type = 'button';
      b.onclick = () => { draft.color = col; renderPickers(); }; c.appendChild(b);
    });
    const ic = $('#mc-icons'); ic.innerHTML = '';
    ICONS.forEach((x) => {
      const b = mk('button', 'ic' + (draft.icon === x ? ' sel' : ''), x); b.type = 'button';
      b.onclick = () => { draft.icon = x; $('#mc-icon').value = x; renderPickers(); }; ic.appendChild(b);
    });
  }
  function openEditor(m) {
    isNew = !m;
    draft = m ? JSON.parse(JSON.stringify(m)) : { id: uid(), name: '', icon: '⚡', color: COLORS[0], steps: [] };
    $('#mc-name').value = draft.name; $('#mc-icon').value = draft.icon;
    $('#mc-del').classList.toggle('hidden', isNew);
    renderPickers(); renderSteps(); $('#modal-macro').classList.remove('hidden');
  }
  $('#mc-name').oninput = (e) => (draft.name = e.target.value);
  $('#mc-icon').oninput = (e) => { draft.icon = e.target.value; };
  $('#mc-add').onclick = () => { draft.steps.push(defaults($('#mc-addtype').value)); renderSteps(); };
  $('#mc-cancel').onclick = () => $('#modal-macro').classList.add('hidden');
  $('#mc-save').onclick = async () => {
    const m = cleanMacro(draft, true);
    if (!m.steps.length) return toast('warn', 'noSteps');
    const l = list().slice(); const i = l.findIndex((x) => x.id === m.id);
    if (i >= 0) l[i] = m; else l.push(m);
    await setList(l); $('#modal-macro').classList.add('hidden'); renderLibrary(); toast('ok', 'saved');
  };
  $('#mc-del').onclick = async () => {
    await setList(list().filter((x) => x.id !== draft.id)); $('#modal-macro').classList.add('hidden'); renderLibrary();
  };
  const sel = $('#mc-addtype'); TYPES.forEach((ty) => { const o = mk('option', null, t('st_' + ty)); o.value = ty; sel.appendChild(o); });

  // ---------- Кнопки бібліотеки ----------
  $('#mc-new').onclick = () => openEditor(null);
  $('#mc-templates').onclick = async () => {
    const have = new Set(list().map((m) => m.id));
    const add = TEMPLATES.filter((x) => !have.has(x.id)).map((x) => cleanMacro(x, true));
    await setList(list().concat(add)); renderLibrary(); toast('ok', add.length ? 'tplAdded' : 'tplNone');
  };
  $('#mc-export').onclick = async () => {
    const json = JSON.stringify({ muskup: 1, macros: list() }, null, 2);
    try { await navigator.clipboard.writeText(json); } catch (_) {}
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([json], { type: 'application/json' })); a.download = 'muskup-macros.json'; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000); toast('ok', 'exported');
  };
  $('#mc-import').onclick = () => $('#mc-file').click();
  $('#mc-file').onchange = async (e) => {
    const f = e.target.files[0]; e.target.value = ''; if (!f) return;
    try {
      const data = JSON.parse(await f.text());
      const arr = Array.isArray(data) ? data : data.macros;
      const add = (arr || []).slice(0, 100).map((m) => cleanMacro(m, false)).filter((m) => m && m.steps.length);
      if (!add.length) throw new Error('empty');
      await setList(list().concat(add)); renderLibrary(); toast('ok', 'imported');
    } catch (_) { toast('err', 'importErr'); }
  };

  return { seed, renderLibrary, renderGrid, list };
};
