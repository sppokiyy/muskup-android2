const q = new URLSearchParams(location.search);
const uk = q.get('lang') !== 'en';
document.getElementById('t').textContent = uk ? 'Триває віддалений сеанс' : 'Remote session in progress';
document.getElementById('p').textContent = q.get('peer') || '';
const b = document.getElementById('end');
b.textContent = uk ? 'Завершити' : 'End';
b.title = 'Ctrl+Alt+Shift+Q';
b.onclick = () => window.overlay.end();
