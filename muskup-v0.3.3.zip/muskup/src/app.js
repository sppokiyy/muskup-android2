(async () => {
  const $ = (s) => document.querySelector(s);
  let settings = await window.muskup.getSettings();
  let lang = settings.lang || 'uk';
  const t = (k) => (window.I18N[lang] && window.I18N[lang][k]) || k;
  const fmtId = (id) => String(id).replace(/(\d{3})(?=\d)/g, '$1 ');
  const save = async (patch) => { settings = await window.muskup.setSettings(patch); return settings; };

  function applyI18n() {
    document.documentElement.lang = lang;
    document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
    document.querySelectorAll('[data-i18n-ph]').forEach((el) => { el.placeholder = t(el.dataset.i18nPh); });
  }
  function toast(kind, key) {
    const d = document.createElement('div');
    d.className = 'toast ' + (kind === 'ok' ? '' : kind);
    d.textContent = t(key);
    $('#toasts').appendChild(d);
    setTimeout(() => d.remove(), 4000);
  }
  function setOnline(v) {
    $('#dot').classList.toggle('off', !v);
    const st = $('#status-text'); st.dataset.i18n = v ? 'online' : 'offline'; st.textContent = t(st.dataset.i18n);
  }
  const showServerWarn = () => $('#server-warn').classList.toggle('hidden', !!(settings.serverUrl || '').trim());
  const open = (sel) => $(sel).classList.remove('hidden');
  const go = (v) => document.querySelector(`.nav[data-view="${v}"]`).click();

  // ---------- Керування (клієнт) ----------
  let remotePerms = { control: false, macros: false };
  let ctrlWanted = true;
  const remote = createRemoteInput($('#remote'), (m) => sess.sendCtl(m), (m) => sess.sendMove(m));
  function refreshCtrl() {
    const on = remotePerms.control && ctrlWanted;
    remote.setEnabled(on);
    $('#btn-ctrl').textContent = t(on ? 'ctrlOn' : 'ctrlOff');
    $('#btn-ctrl').disabled = !remotePerms.control;
    $('#btn-cmds').disabled = !remotePerms.macros;
  }

  // ---------- Сеанс ----------
  let cur = null; // поточний сеанс для журналу
  const sess = createSession({
    settings: () => settings,
    log: (l, m) => window.muskup.log(l, m),
    online: setOnline,
    toast,
    incoming: (from, decide) => {
      $('#incoming-id').textContent = fmtId(from);
      $('#perm-control').checked = true; $('#perm-macros').checked = true;
      open('#modal-incoming');
      $('#btn-allow').onclick = () => decide(true, { control: $('#perm-control').checked, macros: $('#perm-macros').checked });
      $('#btn-deny').onclick = () => decide(false);
    },
    incomingClose: () => $('#modal-incoming').classList.add('hidden'),
    stream: (s) => { const v = $('#remote'); v.srcObject = s; v.play().catch(() => {}); },
    stats: (s) => { $('#sstats').textContent = `${s.fps} fps · ${s.rtt} ms · ${s.mbps} Mbit/s`; },
    perms: (p) => { remotePerms = p; refreshCtrl(); if (!p.control) toast('warn', 'viewOnly'); },
    denied: (what) => toast('warn', what === 'macros' ? 'deniedMacros' : 'deniedControl'),
    input: (m) => window.muskup.input(m),
    hostActive: (on, perms, peer) => window.muskup.hostSession({ active: on, perms, peer: on ? fmtId(peer) : '' }),
    connected: (role, peer) => {
      cur = { dir: role === 'host' ? 'in' : 'out', peer, start: Date.now(), perms: null };
      if (role === 'client') {
        open('#session'); remote.setActive(true); ctrlWanted = true; refreshCtrl(); toast('ok', 'toastOk');
      } else { $('#banner-peer').textContent = fmtId(peer); open('#host-banner'); document.body.classList.add('has-banner'); }
    },
    ended: async (reason) => {
      remote.setActive(false); remotePerms = { control: false, macros: false };
      $('#session').classList.add('hidden'); $('#qpanel').classList.add('hidden');
      $('#host-banner').classList.add('hidden'); document.body.classList.remove('has-banner');
      $('#remote').srcObject = null; window.muskup.win('fs-off');
      if (cur) {
        await window.muskup.addHistory({ dir: cur.dir, peer: cur.peer, start: cur.start, sec: Math.round((Date.now() - cur.start) / 1000) });
        cur = null; renderHistory();
      }
      if (reason === 'lost' || reason === 'error') toast('warn', 'toastWarn');
      else if (reason === 'remote') toast('warn', 'toastEnded');
    }
  });
  window.muskup.onHostEnd(() => sess.end()); // кнопка/гаряча клавіша на оверлеї хоста

  // ---------- Швидкі команди ----------
  const macros = createMacros({ $, t, get: () => settings, save, toast });
  await macros.seed(); macros.renderLibrary();
  function runMacro(m) { sess.sendCtl({ t: 'macro', steps: m.steps }); toast('info', 'macroSent'); }
  function renderPanel() { macros.renderGrid($('#qgrid'), runMacro); }
  $('#btn-cmds').onclick = () => { renderPanel(); $('#qpanel').classList.toggle('hidden'); };
  $('#qclose').onclick = () => $('#qpanel').classList.add('hidden');
  $('#btn-ctrl').onclick = () => { ctrlWanted = !ctrlWanted; refreshCtrl(); };
  (() => { // перетягування панелі
    const p = $('#qpanel'); let dx = 0, dy = 0, drag = false;
    $('#qhead').onmousedown = (e) => { if (e.target.tagName === 'BUTTON') return; drag = true; dx = e.clientX - p.offsetLeft; dy = e.clientY - p.offsetTop; };
    window.addEventListener('mousemove', (e) => { if (drag) { p.style.left = (e.clientX - dx) + 'px'; p.style.top = (e.clientY - dy) + 'px'; p.style.right = 'auto'; } });
    window.addEventListener('mouseup', () => { drag = false; });
  })();

  // ---------- Контакти ----------
  function renderContacts() {
    const box = $('#ct-list'); box.innerHTML = '';
    const list = settings.contacts || [];
    if (!list.length) { const p = document.createElement('p'); p.className = 'muted'; p.textContent = t('ctEmpty'); box.appendChild(p); return; }
    list.forEach((c, i) => {
      const row = document.createElement('div'); row.className = 'item';
      const nm = document.createElement('span'); nm.className = 'nm'; nm.textContent = c.name;
      const id = document.createElement('span'); id.className = 'id'; id.textContent = fmtId(c.id);
      const go1 = document.createElement('button'); go1.className = 'btn-primary'; go1.textContent = t('connectBtn');
      go1.onclick = () => openConnect(c.id);
      const del = document.createElement('button'); del.className = 'mini danger'; del.textContent = '✕';
      del.onclick = async () => { const l = (settings.contacts || []).slice(); l.splice(i, 1); await save({ contacts: l }); renderContacts(); };
      [nm, id, go1, del].forEach((e) => row.appendChild(e)); box.appendChild(row);
    });
  }
  $('#ct-id').oninput = (e) => { e.target.value = fmtId(e.target.value.replace(/\D/g, '').slice(0, 9)); };
  $('#ct-add').onclick = async () => {
    const id = $('#ct-id').value.replace(/\D/g, ''), name = $('#ct-name').value.trim().slice(0, 40);
    if (id.length !== 9 || !name) return toast('warn', 'toastErr');
    await save({ contacts: (settings.contacts || []).concat([{ name, id }]).slice(0, 200) });
    $('#ct-name').value = ''; $('#ct-id').value = ''; renderContacts();
  };

  // ---------- Історія ----------
  async function renderHistory() {
    const box = $('#hist-list'); box.innerHTML = '';
    const list = await window.muskup.getHistory();
    if (!list.length) { const p = document.createElement('p'); p.className = 'muted'; p.textContent = t('histEmpty'); box.appendChild(p); return; }
    list.forEach((h) => {
      const row = document.createElement('div'); row.className = 'item';
      const nm = document.createElement('span'); nm.className = 'nm';
      nm.textContent = (h.dir === 'in' ? t('histIn') : t('histOut')) + ' · ' + fmtId(h.peer);
      const when = document.createElement('span'); when.className = 'id';
      const m = Math.floor(h.sec / 60), s = h.sec % 60;
      when.textContent = new Date(h.start).toLocaleString(lang === 'uk' ? 'uk-UA' : 'en-GB') + ' · ' + m + ':' + String(s).padStart(2, '0');
      row.appendChild(nm); row.appendChild(when);
      if (h.dir === 'out') { const b = document.createElement('button'); b.className = 'btn-secondary'; b.textContent = t('connectBtn'); b.onclick = () => openConnect(h.peer); row.appendChild(b); }
      box.appendChild(row);
    });
  }
  $('#hist-clear').onclick = async () => { await window.muskup.clearHistory(); renderHistory(); };

  // ---------- Початкові значення ----------
  document.body.dataset.accent = settings.accent;
  $('#set-accent').value = settings.accent;
  $('#set-quality').value = settings.quality;
  $('#set-lang').value = lang;
  $('#set-server').value = settings.serverUrl || '';
  $('#my-id').textContent = fmtId(settings.myId);
  $('#my-pass').textContent = settings.tempPass;
  const info = await window.muskup.info();
  $('#app-version').textContent = 'v' + info.version;
  applyI18n(); showServerWarn(); renderContacts(); renderHistory(); refreshCtrl();
  window.muskup.log('info', 'UI завантажено');
  sess.start();

  // ---------- Вікно, навігація, модалки ----------
  $('#w-min').onclick = () => window.muskup.win('min');
  $('#w-max').onclick = () => window.muskup.win('max');
  $('#w-close').onclick = () => window.muskup.win('close');
  document.querySelectorAll('.nav').forEach((b) => {
    b.onclick = () => {
      document.querySelectorAll('.nav').forEach((x) => x.classList.remove('active'));
      b.classList.add('active');
      document.querySelectorAll('.view').forEach((v) => v.classList.add('hidden'));
      $('#view-' + b.dataset.view).classList.remove('hidden');
      if (b.dataset.view === 'history') renderHistory();
    };
  });
  document.querySelectorAll('[data-close]').forEach((b) => { b.onclick = () => $(b.dataset.close).classList.add('hidden'); });
  $('#tile-id').onclick = () => open('#modal-id');
  $('#tile-sec').onclick = () => open('#modal-sec');
  $('#tile-set').onclick = () => go('settings');
  $('#btn-swap').onclick = () => go('history');
  $('#copy-id').onclick = async () => { await navigator.clipboard.writeText(settings.myId); toast('ok', 'copied'); };
  $('#copy-pass').onclick = async () => { await navigator.clipboard.writeText(settings.tempPass); toast('ok', 'copied'); };

  // ---------- Підключення ----------
  function openConnect(id) {
    if (!(settings.serverUrl || '').trim()) return toast('warn', 'toastNoServer');
    $('#connect-id').value = id ? fmtId(id) : ''; $('#connect-pass').value = '';
    open('#modal-connect'); (id ? $('#connect-pass') : $('#connect-id')).focus();
  }
  $('#btn-open-connect').onclick = () => openConnect('');
  $('#connect-id').oninput = (e) => { e.target.value = fmtId(e.target.value.replace(/\D/g, '').slice(0, 9)); };
  $('#btn-connect').onclick = () => {
    sess.connect($('#connect-id').value, $('#connect-pass').value.trim());
    $('#modal-connect').classList.add('hidden');
  };
  $('#btn-end').onclick = () => sess.end();
  $('#btn-banner-end').onclick = () => sess.end();
  $('#btn-fs').onclick = () => window.muskup.win('fs');

  // ---------- Налаштування ----------
  let srvTimer = null;
  const applyServer = async () => {
    const v = window.normalizeServerUrl($('#set-server').value);
    await save({ serverUrl: v }); showServerWarn(); sess.reconnect();
  };
  $('#set-server').oninput = () => { clearTimeout(srvTimer); srvTimer = setTimeout(applyServer, 900); }; // зберігається саме
  $('#set-server').onchange = () => { clearTimeout(srvTimer); applyServer(); };
  $('#btn-test').onclick = async () => {
    const out = $('#server-test-res'); const url = window.normalizeServerUrl($('#set-server').value);
    if (!url) { out.textContent = t('toastNoServer'); return; }
    out.textContent = '…';
    const res = await new Promise((resolve) => {
      let done = false; const fin = (r) => { if (!done) { done = true; try { w.close(); } catch (_) {} resolve(r); } };
      let w; try { w = new WebSocket(url); } catch (_) { return resolve('bad'); }
      const id = String(Math.floor(100000000 + Math.random() * 899999999));
      w.onopen = () => w.send(JSON.stringify({ type: 'register', id }));
      w.onmessage = (e) => { try { if (JSON.parse(e.data).type === 'registered') fin('ok'); } catch (_) {} };
      w.onerror = () => fin('ws');
      w.onclose = () => fin('ws');
      setTimeout(() => fin('timeout'), 10000);
    });
    if (res === 'ok') { out.textContent = '✔ ' + t('testOk'); window.muskup.log('info', 'Перевірка сервера: OK'); return; }
    let http = false;
    try { await fetch(url.replace(/^ws/i, 'http'), { mode: 'no-cors' }); http = true; } catch (_) {}
    out.textContent = '✖ ' + t(http ? 'testWsFail' : 'testNoHost');
    window.muskup.log('warn', 'Перевірка сервера: ' + res + ', http=' + http + ', url=' + url);
  };
  $('#set-accent').onchange = async (e) => { document.body.dataset.accent = e.target.value; await save({ accent: e.target.value }); };
  $('#set-quality').onchange = async (e) => { await save({ quality: e.target.value }); };
  $('#set-lang').onchange = async (e) => {
    lang = e.target.value; await save({ lang }); applyI18n(); refreshCtrl(); renderContacts(); renderHistory();
    setOnline(!$('#dot').classList.contains('off'));
  };

  // ---------- Лог і звіт ----------
  $('#btn-copy-log').onclick = async () => { await window.muskup.copyLog(); toast('ok', 'logCopied'); };
  $('#btn-report').onclick = () => open('#modal-report');
  $('#btn-report-copy').onclick = async () => {
    const log = await window.muskup.readLog();
    await navigator.clipboard.writeText(`MUSKUP v${info.version}\nОпис: ${$('#report-text').value}\n\n${log}`);
    $('#modal-report').classList.add('hidden');
    toast('ok', 'reportCopied');
  };
})();
