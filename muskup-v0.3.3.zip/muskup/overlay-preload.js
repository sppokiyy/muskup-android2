const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('overlay', { end: () => ipcRenderer.send('overlay:end') });
