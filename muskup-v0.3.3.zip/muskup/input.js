// Введення миші/клавіатури на хості через SendInput (PowerShell-помічник без нативних модулів)
// + виконання швидких команд. Працює ТІЛЬКИ коли хост дозволив (див. setSession).
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
let shell = null;
try { shell = require('electron').shell; } catch (_) {}

const PS_SCRIPT = String.raw`
$ErrorActionPreference = 'Continue'
$src = @'
using System;
using System.Runtime.InteropServices;
public static class MI {
  [StructLayout(LayoutKind.Sequential)] struct MOUSEINPUT { public int dx; public int dy; public uint mouseData; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }
  [StructLayout(LayoutKind.Sequential)] struct KEYBDINPUT { public ushort wVk; public ushort wScan; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }
  [StructLayout(LayoutKind.Explicit)] struct U { [FieldOffset(0)] public MOUSEINPUT mi; [FieldOffset(0)] public KEYBDINPUT ki; }
  [StructLayout(LayoutKind.Sequential)] struct INPUT { public uint type; public U u; }
  [DllImport("user32.dll", SetLastError = true)] static extern uint SendInput(uint n, INPUT[] i, int size);
  [DllImport("user32.dll")] static extern uint MapVirtualKey(uint code, uint type);
  static void Send(INPUT i) { SendInput(1, new INPUT[] { i }, Marshal.SizeOf(typeof(INPUT))); }
  static void Mouse(int dx, int dy, uint data, uint flags) {
    INPUT i = new INPUT(); i.type = 0; i.u.mi.dx = dx; i.u.mi.dy = dy; i.u.mi.mouseData = data; i.u.mi.dwFlags = flags; Send(i);
  }
  public static void Move(int x, int y) { Mouse(x, y, 0, 0x8001); }
  public static void Btn(string b, bool down) {
    uint f;
    if (b == "r") f = down ? 0x0008u : 0x0010u;
    else if (b == "m") f = down ? 0x0020u : 0x0040u;
    else f = down ? 0x0002u : 0x0004u;
    Mouse(0, 0, 0, f);
  }
  public static void Wheel(int d, bool horiz) { Mouse(0, 0, unchecked((uint)d), horiz ? 0x1000u : 0x0800u); }
  public static void Key(int vk, bool ext, bool down) {
    INPUT i = new INPUT(); i.type = 1; i.u.ki.wVk = (ushort)vk; i.u.ki.wScan = (ushort)MapVirtualKey((uint)vk, 0);
    i.u.ki.dwFlags = (down ? 0u : 2u) | (ext ? 1u : 0u); Send(i);
  }
  public static void Text(string s) {
    foreach (char c in s) {
      foreach (uint fl in new uint[] { 4u, 6u }) {
        INPUT i = new INPUT(); i.type = 1; i.u.ki.wScan = c; i.u.ki.dwFlags = fl; Send(i);
      }
    }
  }
}
'@
Add-Type -TypeDefinition $src
[Console]::Out.WriteLine('ready'); [Console]::Out.Flush()
while ($true) {
  $line = [Console]::In.ReadLine()
  if ($line -eq $null) { break }
  $p = $line.Split(' ')
  try {
    switch ($p[0]) {
      'm' { [MI]::Move([int]$p[1], [int]$p[2]) }
      'b' { [MI]::Btn($p[1], ($p[2] -eq '1')) }
      'w' { [MI]::Wheel([int]$p[1], $false) }
      'h' { [MI]::Wheel([int]$p[1], $true) }
      'k' { [MI]::Key([int]$p[1], ($p[2] -eq '1'), ($p[3] -eq '1')) }
      't' { [MI]::Text([System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($p[1]))) }
    }
  } catch { [Console]::Error.WriteLine($_.Exception.Message) }
}
`;

// ---------- Таблиця клавіш: ім'я -> [VK, extended] ----------
const KEYS = {
  ctrl: [0x11, 0], control: [0x11, 0], alt: [0x12, 0], shift: [0x10, 0],
  win: [0x5B, 1], windows: [0x5B, 1], meta: [0x5B, 1],
  enter: [0x0D, 0], return: [0x0D, 0], esc: [0x1B, 0], escape: [0x1B, 0], tab: [0x09, 0], space: [0x20, 0],
  backspace: [0x08, 0], delete: [0x2E, 1], del: [0x2E, 1], insert: [0x2D, 1],
  home: [0x24, 1], end: [0x23, 1], pageup: [0x21, 1], pagedown: [0x22, 1],
  left: [0x25, 1], up: [0x26, 1], right: [0x27, 1], down: [0x28, 1],
  printscreen: [0x2C, 1], prtsc: [0x2C, 1], capslock: [0x14, 0], apps: [0x5D, 1],
  ';': [0xBA, 0], '=': [0xBB, 0], ',': [0xBC, 0], '-': [0xBD, 0], '.': [0xBE, 0], '/': [0xBF, 0],
  '`': [0xC0, 0], '[': [0xDB, 0], '\\': [0xDC, 0], ']': [0xDD, 0], "'": [0xDE, 0]
};
for (let i = 0; i < 26; i++) KEYS[String.fromCharCode(97 + i)] = [0x41 + i, 0];
for (let i = 0; i < 10; i++) { KEYS[String(i)] = [0x30 + i, 0]; KEYS['num' + i] = [0x60 + i, 0]; }
for (let i = 1; i <= 12; i++) KEYS['f' + i] = [0x6F + i, 0];

function keyOf(name) { return KEYS[String(name).trim().toLowerCase()] || null; }
function parseCombo(combo) {
  const parts = String(combo).split('+').map((s) => s.trim()).filter(Boolean);
  const keys = parts.map(keyOf);
  if (!keys.length || keys.some((k) => !k)) return null;
  return keys;
}

// ---------- Очищення вхідних даних (довіряємо лише перевіреному) ----------
const clamp = (v, a, b) => Math.min(b, Math.max(a, Number(v) || 0));
const TYPES = ['key', 'text', 'wait', 'click', 'run', 'url'];
function cleanStep(s) {
  if (!s || !TYPES.includes(s.type)) return null;
  switch (s.type) {
    case 'key': return { type: 'key', combo: String(s.combo || '').slice(0, 60) };
    case 'text': return { type: 'text', text: String(s.text || '').slice(0, 500) };
    case 'wait': return { type: 'wait', ms: clamp(s.ms, 0, 30000) };
    case 'click': return { type: 'click', x: clamp(s.x, 0, 100), y: clamp(s.y, 0, 100), button: s.button === 'right' ? 'right' : 'left', double: !!s.double };
    case 'run': return { type: 'run', target: String(s.target || '').replace(/[\r\n]/g, ' ').slice(0, 500) };
    case 'url': return { type: 'url', url: String(s.url || '').slice(0, 500) };
  }
  return null;
}
function cleanSteps(steps) {
  if (!Array.isArray(steps)) return [];
  return steps.slice(0, 100).map(cleanStep).filter(Boolean);
}

// ---------- Стан ----------
let log = () => {};
let proc = null, ready = false, queue = [];
let session = { active: false, perms: null };
let pendingMove = null, flushScheduled = false;
const keysDown = new Map(); // "vk:ext" -> [vk, ext]
const btnDown = new Set();
let macroToken = 0;

function ensureProc() {
  if (proc) return;
  const file = path.join(require('os').tmpdir(), 'muskup-input.ps1');
  fs.writeFileSync(file, PS_SCRIPT, 'utf8');
  proc = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', file], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
  ready = false;
  proc.stdout.on('data', (d) => { if (String(d).includes('ready')) { ready = true; log('INFO', 'input: помічник готовий'); queue.forEach((l) => proc.stdin.write(l + '\n')); queue = []; } });
  proc.stderr.on('data', (d) => log('ERROR', 'input: ' + String(d).trim()));
  proc.on('error', (e) => { log('ERROR', 'input: не вдалося запустити PowerShell: ' + e.message); proc = null; });
  proc.on('exit', () => { proc = null; ready = false; });
  proc.stdin.on('error', () => {});
}
function raw(line) {
  if (!proc) ensureProc();
  if (!proc) return;
  if (ready) proc.stdin.write(line + '\n'); else if (queue.length < 500) queue.push(line);
}
function flushMove() {
  if (pendingMove) { raw(`m ${pendingMove.x} ${pendingMove.y}`); pendingMove = null; }
}
function write(line) { flushMove(); raw(line); }
function move(x, y) {
  pendingMove = { x: Math.round(clamp(x, 0, 65535)), y: Math.round(clamp(y, 0, 65535)) };
  if (!flushScheduled) { flushScheduled = true; setImmediate(() => { flushScheduled = false; flushMove(); }); }
}
function button(b, down) {
  const k = b === 'r' || b === 'm' ? b : 'l';
  if (down) btnDown.add(k); else btnDown.delete(k);
  write(`b ${k} ${down ? 1 : 0}`);
}
function key(vk, ext, down) {
  const id = vk + ':' + ext;
  if (down) keysDown.set(id, [vk, ext]); else keysDown.delete(id);
  write(`k ${vk} ${ext} ${down ? 1 : 0}`);
}
function releaseAll() {
  for (const [vk, ext] of keysDown.values()) write(`k ${vk} ${ext} 0`);
  keysDown.clear();
  for (const b of btnDown) write(`b ${b} 0`);
  btnDown.clear();
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------- Швидкі команди ----------
async function pressCombo(combo) {
  const keys = parseCombo(combo);
  if (!keys) { log('WARN', 'macro: невідома комбінація «' + combo + '»'); return; }
  for (const [vk, ext] of keys) { key(vk, ext, true); await sleep(15); }
  for (const [vk, ext] of keys.slice().reverse()) { key(vk, ext, false); await sleep(15); }
}
function openUrl(u) {
  try {
    const p = new URL(u);
    if (p.protocol !== 'http:' && p.protocol !== 'https:') return log('WARN', 'macro: дозволені тільки http/https');
    if (shell) shell.openExternal(p.href);
  } catch (_) { log('WARN', 'macro: некоректна адреса сайту'); }
}
function runTarget(target) {
  if (!target.trim()) return;
  const c = spawn('cmd.exe', ['/d', '/s', '/c', 'start "" ' + target], { windowsVerbatimArguments: true, detached: true, stdio: 'ignore', windowsHide: true });
  c.on('error', (e) => log('ERROR', 'macro: запуск не вдався: ' + e.message));
  c.unref();
}
async function runMacro(rawSteps) {
  const steps = cleanSteps(rawSteps);
  const token = ++macroToken;
  log('INFO', `macro: старт, кроків: ${steps.length}`);
  let waited = 0;
  for (const s of steps) {
    if (token !== macroToken || !session.active) { log('INFO', 'macro: перервано'); break; }
    switch (s.type) {
      case 'key': await pressCombo(s.combo); break;
      case 'text': if (s.text) write('t ' + Buffer.from(s.text, 'utf8').toString('base64')); break;
      case 'wait': { const ms = Math.min(s.ms, 120000 - waited); waited += ms; await sleep(ms); break; }
      case 'click': {
        move(s.x * 655.35, s.y * 655.35); await sleep(40);
        const b = s.button === 'right' ? 'r' : 'l';
        for (let i = 0; i < (s.double ? 2 : 1); i++) { button(b, true); await sleep(30); button(b, false); await sleep(60); }
        break;
      }
      case 'run': runTarget(s.target); break;
      case 'url': openUrl(s.url); break;
    }
    await sleep(40);
  }
  log('INFO', 'macro: завершено');
}

// ---------- Публічний інтерфейс ----------
function setSession(st) {
  const was = session.active;
  session = { active: !!st.active, perms: st.active ? { control: !!(st.perms && st.perms.control), macros: !!(st.perms && st.perms.macros) } : null };
  if (session.active && !was) { ensureProc(); log('INFO', 'input: сеанс активний, права: ' + JSON.stringify(session.perms)); }
  if (!session.active && was) {
    macroToken++; releaseAll();
    setTimeout(() => { if (proc && !session.active) { try { proc.stdin.end(); } catch (_) {} proc = null; ready = false; } }, 300);
    log('INFO', 'input: сеанс завершено, введення вимкнено');
  }
}

function handle(m) {
  if (!session.active || !m) return;
  const p = session.perms;
  switch (m.t) {
    case 'm': if (p.control) move(clamp(m.x, 0, 65535), clamp(m.y, 0, 65535)); break;
    case 'b': if (p.control) button(m.b, !!m.d); break;
    case 'w': if (p.control) { const d = Math.round(clamp(m.dy, -1200, 1200)); if (d) write('w ' + d); const h = Math.round(clamp(m.dx, -1200, 1200)); if (h) write('h ' + h); } break;
    case 'k': { if (!p.control) break; const k = keyOf(m.n); if (k) key(k[0], k[1], !!m.d); break; }
    case 'macro': if (p.macros) runMacro(m.steps).catch((e) => log('ERROR', 'macro: ' + e)); break;
    case 'stop': macroToken++; break;
  }
}

module.exports = { setSession, handle, parseCombo, cleanSteps, setLogger: (f) => { log = f; } };
