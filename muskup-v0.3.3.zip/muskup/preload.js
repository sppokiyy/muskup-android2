const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('muskup', {
  info: () => ipcRenderer.invoke('app:info'),
  getSettings: () => ipcRenderer.invoke('settings:get'),
  setSettings: (patch) => ipcRenderer.invoke('settings:set', patch),
  log: (level, msg) => ipcRenderer.send('log:write', level, msg),
  readLog: () => ipcRenderer.invoke('log:read'),
  copyLog: () => ipcRenderer.invoke('log:copy'),
  win: (action) => ipcRenderer.send('win:ctl', action),
  input: (m) => ipcRenderer.send('input:send', m),
  hostSession: (st) => ipcRenderer.send('host:session', st),
  onHostEnd: (cb) => ipcRenderer.on('host:end', () => cb()),
  getHistory: () => ipcRenderer.invoke('history:get'),
  addHistory: (item) => ipcRenderer.invoke('history:add', item),
  clearHistory: () => ipcRenderer.invoke('history:clear')
});
