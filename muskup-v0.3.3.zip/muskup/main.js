const { app, BrowserWindow, ipcMain, clipboard, shell, desktopCapturer, session, screen, globalShortcut } = require('electron');
const inputMod = require('./input');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

// ---------- Логування у файл ----------
let logFile;
function initLog() {
  const dir = path.join(app.getPath('userData'), 'logs');
  fs.mkdirSync(dir, { recursive: true });
  logFile = path.join(dir, 'muskup.log');
  try {
    if (fs.existsSync(logFile) && fs.statSync(logFile).size > 2 * 1024 * 1024) {
      fs.renameSync(logFile, logFile + '.old');
    }
  } catch (_) {}
}
function log(level, ...args) {
  const line = `[${new Date().toISOString()}] [${level}] ${args.map(String).join(' ')}\n`;
  try { fs.appendFileSync(logFile, line); } catch (_) {}
  console.log(line.trim());
}
process.on('uncaughtException', (e) => log('FATAL', e.stack || e));
process.on('unhandledRejection', (e) => log('ERROR', 'unhandledRejection', e));

// ---------- Налаштування ----------
let settingsPath;
const defaults = { lang: 'uk', accent: 'purple', quality: 'fast', myId: null, tempPass: null, serverUrl: '', contacts: [], macros: null };
function loadSettings() {
  let s = {};
  try { s = JSON.parse(fs.readFileSync(settingsPath, 'utf8')); } catch (_) {}
  s = { ...defaults, ...s };
  if (!s.myId) s.myId = String(crypto.randomInt(100000000, 999999999));
  s.tempPass = crypto.randomBytes(4).toString('hex'); // новий одноразовий пароль при кожному запуску
  saveSettings(s);
  return s;
}
function saveSettings(s) { fs.writeFileSync(settingsPath, JSON.stringify(s, null, 2)); }
let settings;

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 760,
    minWidth: 1000,
    minHeight: 640,
    frame: false,
    backgroundColor: '#000000',
    title: 'MUSKUP',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  win.removeMenu();
  win.loadFile(path.join(__dirname, 'src', 'index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:\/\//i.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.on('closed', () => { hideOverlay(); app.quit(); });
  mainWin = win;
}

// ---------- Постійний індикатор «Триває віддалений сеанс» (завжди поверх усіх вікон) ----------
let mainWin = null, overlay = null;
const KILL_KEY = 'CommandOrControl+Alt+Shift+Q';
function endFromHost() { if (mainWin && !mainWin.isDestroyed()) mainWin.webContents.send('host:end'); }
function showOverlay(peer) {
  hideOverlay();
  const wa = screen.getPrimaryDisplay().workArea;
  const w = 520, h = 56;
  overlay = new BrowserWindow({
    width: w, height: h, x: Math.round(wa.x + (wa.width - w) / 2), y: wa.y + 6,
    frame: false, transparent: true, resizable: false, skipTaskbar: true, alwaysOnTop: true, hasShadow: false,
    webPreferences: { preload: path.join(__dirname, 'overlay-preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  overlay.setAlwaysOnTop(true, 'screen-saver');
  overlay.loadFile(path.join(__dirname, 'src', 'overlay.html'), { query: { lang: settings.lang || 'uk', peer: String(peer || '') } });
  overlay.on('closed', () => { overlay = null; });
  try { globalShortcut.register(KILL_KEY, endFromHost); } catch (e) { log('WARN', 'гаряча клавіша: ' + e); }
}
function hideOverlay() {
  try { globalShortcut.unregister(KILL_KEY); } catch (_) {}
  if (overlay && !overlay.isDestroyed()) overlay.destroy();
  overlay = null;
}

// ---------- Історія сеансів (журнал на хості і клієнті) ----------
let historyPath;
function readHistory() { try { return JSON.parse(fs.readFileSync(historyPath, 'utf8')); } catch (_) { return []; } }

app.whenReady().then(() => {
  initLog();
  settingsPath = path.join(app.getPath('userData'), 'settings.json');
  settings = loadSettings();
  log('INFO', `MUSKUP v${app.getVersion()} запущено, electron ${process.versions.electron}`);

  // Захоплення екрана: віддаємо основний монітор (вибір монітора — наступні етапи)
  session.defaultSession.setDisplayMediaRequestHandler(async (_req, callback) => {
    try {
      const sources = await desktopCapturer.getSources({ types: ['screen'] });
      const primary = String(screen.getPrimaryDisplay().id);
      const src = sources.find((s) => s.display_id === primary) || sources[0];
      callback({ video: src });
    } catch (e) {
      log('ERROR', 'захоплення екрана: ' + e);
      callback({});
    }
  }, { useSystemPicker: false });

  ipcMain.on('win:ctl', (e, action) => {
    const w = BrowserWindow.fromWebContents(e.sender);
    if (!w) return;
    if (action === 'min') w.minimize();
    else if (action === 'max') { if (w.isMaximized()) w.unmaximize(); else w.maximize(); }
    else if (action === 'close') w.close();
    else if (action === 'fs') w.setFullScreen(!w.isFullScreen());
    else if (action === 'fs-off') w.setFullScreen(false);
  });

  // Введення і швидкі команди (працюють лише коли хост дозволив)
  inputMod.setLogger(log);
  ipcMain.on('input:send', (_e, m) => { try { inputMod.handle(m); } catch (e) { log('ERROR', 'input: ' + e); } });
  ipcMain.on('host:session', (_e, st) => {
    inputMod.setSession(st || {});
    if (st && st.active) showOverlay(st.peer); else hideOverlay();
  });
  ipcMain.on('overlay:end', endFromHost);
  historyPath = path.join(app.getPath('userData'), 'history.json');
  ipcMain.handle('history:get', () => readHistory());
  ipcMain.handle('history:add', (_e, item) => {
    const list = readHistory();
    list.unshift({
      dir: item && item.dir === 'in' ? 'in' : 'out', peer: String(item && item.peer || '').slice(0, 12),
      start: Number(item && item.start) || Date.now(), sec: Math.max(0, Number(item && item.sec) || 0),
      perms: item && item.perms ? { control: !!item.perms.control, macros: !!item.perms.macros } : null
    });
    fs.writeFileSync(historyPath, JSON.stringify(list.slice(0, 200), null, 2));
    return true;
  });
  ipcMain.handle('history:clear', () => { fs.writeFileSync(historyPath, '[]'); return true; });
  ipcMain.handle('app:info', () => ({ version: app.getVersion(), platform: process.platform }));
  ipcMain.handle('settings:get', () => settings);
  ipcMain.handle('settings:set', (_e, patch) => {
    settings = { ...settings, ...patch };
    saveSettings(settings);
    return settings;
  });
  ipcMain.on('log:write', (_e, level, msg) => log(String(level).toUpperCase(), '[renderer]', msg));
  ipcMain.handle('log:read', () => {
    try { return fs.readFileSync(logFile, 'utf8').split('\n').slice(-500).join('\n'); } catch (_) { return ''; }
  });
  ipcMain.handle('log:copy', () => {
    try { clipboard.writeText(fs.readFileSync(logFile, 'utf8')); return true; } catch (_) { return false; }
  });

  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on('will-quit', () => { try { globalShortcut.unregisterAll(); inputMod.setSession({ active: false }); } catch (_) {} });
app.on('window-all-closed',() => { if (process.platform !== 'darwin') app.quit(); });
