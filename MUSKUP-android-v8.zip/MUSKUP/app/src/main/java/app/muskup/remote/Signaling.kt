package app.muskup.remote

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.serialization.json.JsonObject
import okhttp3.*

/** WebSocket-сигналізація: реєстрація, keepalive 25 с (текстовий "ping"), перепідключення кожні 4 с. */
class Signaling(private val scope: CoroutineScope) {
    private val client = OkHttpClient.Builder().readTimeout(0, java.util.concurrent.TimeUnit.MILLISECONDS).build()
    @Volatile private var ws: WebSocket? = null
    private var job: Job? = null
    private var url = ""
    private var id = ""

    private val _registered = MutableStateFlow(false)
    val registered = _registered.asStateFlow()
    private val _events = MutableSharedFlow<JsonObject>(extraBufferCapacity = 64)
    val events = _events.asSharedFlow()

    fun configure(newUrl: String, newId: String) {
        if (newUrl == url && newId == id && job?.isActive == true) return
        url = newUrl; id = newId
        job?.cancel()
        job = scope.launch(Dispatchers.IO) {
            while (isActive) {
                if (url.isBlank() || id.isBlank()) { delay(1000); continue }
                runCatching { runOnce() }.onFailure {
                    if (it is CancellationException) throw it
                    AppLog.log("sig", "error: ${it.message}")
                }
                delay(4000)
            }
        }
    }

    private fun registerMsg() = jo("type" to "register", "id" to id).toString()

    private suspend fun runOnce() = coroutineScope {
        val closed = CompletableDeferred<Unit>()
        val req = Request.Builder().url(url).build()
        val socket = client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                AppLog.log("sig", "open"); webSocket.send(registerMsg())
            }
            override fun onMessage(webSocket: WebSocket, text: String) = handle(webSocket, text)
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                AppLog.log("sig", "closed $code"); closed.complete(Unit)
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                AppLog.log("sig", "failure ${t.message}"); closed.complete(Unit)
            }
        })
        ws = socket
        val pinger = launch { while (true) { delay(25_000); socket.send("ping") } }
        try { closed.await() } finally {
            pinger.cancel(); _registered.value = false; socket.cancel(); ws = null
        }
    }

    private fun handle(socket: WebSocket, text: String) {
        if (text == "pong") return
        val o = parseObj(text) ?: return
        when (o.str("type")) {
            "registered" -> { AppLog.log("sig", "registered"); _registered.value = true }
            "id-taken" -> { AppLog.log("sig", "id-taken, retry 5s"); scope.launch { delay(5000); socket.send(registerMsg()) } }
            "error" -> AppLog.log("sig", "error code=${o.str("code")}")
            else -> { AppLog.log("sig", "<- ${o.str("type")}"); _events.tryEmit(o) }
        }
    }

    /** Лог містить лише тип повідомлення (пароль у лог не потрапляє). */
    fun send(o: JsonObject): Boolean {
        AppLog.log("sig", "-> ${o.str("type")}")
        return ws?.send(o.toString()) ?: false
    }
}
