package app.muskup.remote

import kotlinx.serialization.json.*

val J = Json { ignoreUnknownKeys = true }

fun jo(vararg p: Pair<String, Any?>): JsonObject = JsonObject(
    p.filter { it.second != null }.associate { (k, v) ->
        k to when (v) {
            is JsonElement -> v
            is String -> JsonPrimitive(v)
            is Boolean -> JsonPrimitive(v)
            is Number -> JsonPrimitive(v)
            else -> JsonPrimitive(v.toString())
        }
    }
)

fun JsonObject.str(k: String): String? = (this[k] as? JsonPrimitive)?.contentOrNull
fun JsonObject.bool(k: String): Boolean? = (this[k] as? JsonPrimitive)?.booleanOrNull
fun JsonObject.int(k: String): Int? = (this[k] as? JsonPrimitive)?.intOrNull
fun parseObj(s: String): JsonObject? = runCatching { J.parseToJsonElement(s) as? JsonObject }.getOrNull()
