package app.muskup.remote

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

const val DEFAULT_SERVER = "wss://muskup-signal.sttarukmatviy.workers.dev"

private val Context.ds by preferencesDataStore("muskup")

data class Settings(
    val myId: String = "",
    val serverUrl: String = DEFAULT_SERVER,
    val theme: String = "purple",
    val turnUrl: String = "",
    val turnUser: String = "",
    val turnPass: String = "",
    val keepOn: Boolean = true,
    val macrosJson: String = "",
    val lastPeer: String = "",
    val quality: String = "high",
    val sens: Float = 1.4f,
    val invertScroll: Boolean = false,
    val haptics: Boolean = true,
    val startTouch: Boolean = false,
    val autoHide: Boolean = true,
    val bgClose: Boolean = true,
)

object K {
    val id = stringPreferencesKey("id")
    val server = stringPreferencesKey("server")
    val theme = stringPreferencesKey("theme")
    val turnUrl = stringPreferencesKey("turn_url")
    val turnUser = stringPreferencesKey("turn_user")
    val turnPass = stringPreferencesKey("turn_pass")
    val keepOn = booleanPreferencesKey("keep_on")
    val macros = stringPreferencesKey("macros")
    val lastPeer = stringPreferencesKey("last_peer")
    val quality = stringPreferencesKey("quality")
    val sens = floatPreferencesKey("sens")
    val invertScroll = booleanPreferencesKey("invert_scroll")
    val haptics = booleanPreferencesKey("haptics")
    val startTouch = booleanPreferencesKey("start_touch")
    val autoHide = booleanPreferencesKey("auto_hide")
    val bgClose = booleanPreferencesKey("bg_close")
}

class Prefs(private val ctx: Context) {
    val flow: Flow<Settings> = ctx.ds.data.map { p ->
        Settings(
            myId = p[K.id] ?: "",
            serverUrl = p[K.server]?.takeIf { it.isNotBlank() } ?: DEFAULT_SERVER,
            theme = p[K.theme] ?: "purple",
            turnUrl = p[K.turnUrl] ?: "",
            turnUser = p[K.turnUser] ?: "",
            turnPass = p[K.turnPass] ?: "",
            keepOn = p[K.keepOn] ?: true,
            macrosJson = p[K.macros] ?: "",
            lastPeer = p[K.lastPeer] ?: "",
            quality = p[K.quality] ?: "high",
            sens = p[K.sens] ?: 1.4f,
            invertScroll = p[K.invertScroll] ?: false,
            haptics = p[K.haptics] ?: true,
            startTouch = p[K.startTouch] ?: false,
            autoHide = p[K.autoHide] ?: true,
            bgClose = p[K.bgClose] ?: true,
        )
    }

    suspend fun ensureId(): String {
        val cur = ctx.ds.data.first()[K.id]
        if (!cur.isNullOrEmpty()) return cur
        val n = (100_000_000..999_999_999).random().toString()
        ctx.ds.edit { it[K.id] = n }
        return n
    }

    suspend fun setString(k: Preferences.Key<String>, v: String) { ctx.ds.edit { it[k] = v } }
    suspend fun setFloat(k: Preferences.Key<Float>, v: Float) { ctx.ds.edit { it[k] = v } }
    suspend fun setBool(k: Preferences.Key<Boolean>, v: Boolean) { ctx.ds.edit { it[k] = v } }
}
