package app.muskup.remote

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.serialization.json.JsonObject

fun colorOf(hex: String): Color =
    runCatching { Color(android.graphics.Color.parseColor(hex)) }.getOrDefault(Color(0xFF6D4AFF))

private var uidGen = 0L
private fun nextUid() = ++uidGen

/** Редагований крок. Зберігається у форматі Windows-версії через toJson(). */
class StepUi(val uid: Long, type: String) {
    var type by mutableStateOf(type)
    var v1 by mutableStateOf("")
    var v2 by mutableStateOf("")
    var btn by mutableStateOf("left")
    var dbl by mutableStateOf(false)

    fun toJson(): JsonObject = when (type) {
        "key" -> jo("type" to "key", "combo" to v1.trim())
        "text" -> jo("type" to "text", "text" to v1)
        "wait" -> jo("type" to "wait", "ms" to (v1.trim().toIntOrNull() ?: 0).coerceIn(0, 30000))
        "click" -> jo(
            "type" to "click",
            "x" to (v1.trim().toIntOrNull() ?: 50).coerceIn(0, 100),
            "y" to (v2.trim().toIntOrNull() ?: 50).coerceIn(0, 100),
            "button" to btn, "double" to dbl
        )
        "run" -> jo("type" to "run", "target" to v1.trim())
        else -> jo("type" to "url", "url" to v1.trim())
    }

    companion object {
        fun from(o: JsonObject): StepUi {
            val s = StepUi(nextUid(), o.str("type") ?: "key")
            when (s.type) {
                "key" -> s.v1 = o.str("combo") ?: ""
                "text" -> s.v1 = o.str("text") ?: ""
                "wait" -> s.v1 = (o.int("ms") ?: 300).toString()
                "click" -> {
                    s.v1 = (o.int("x") ?: 50).toString(); s.v2 = (o.int("y") ?: 50).toString()
                    s.btn = o.str("button") ?: "left"; s.dbl = o.bool("double") ?: false
                }
                "run" -> s.v1 = o.str("target") ?: ""
                "url" -> s.v1 = o.str("url") ?: ""
            }
            return s
        }
    }
}

private val STEP_TYPES = listOf("key", "text", "wait", "click", "run", "url")

@Composable
private fun typeLabel(t: String) = stringResource(
    when (t) {
        "key" -> R.string.st_key; "text" -> R.string.st_text; "wait" -> R.string.st_wait
        "click" -> R.string.st_click; "run" -> R.string.st_run; else -> R.string.st_url
    }
)

// ---------- вкладка «Швидкі команди» ----------
@Composable
fun MacrosScreen(vm: SessionVm, s: Settings) {
    val ctx = LocalContext.current
    val macros by vm.macros.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<Macro?>(null) }
    var showTpl by remember { mutableStateOf(false) }

    val exportL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) runCatching {
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(vm.exportJson().toByteArray(Charsets.UTF_8)) }
        }
    }
    val importL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = runCatching { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull()
            val n = vm.importJson(text)
            Toast.makeText(ctx, if (n >= 0) ctx.getString(R.string.imp_ok, n) else ctx.getString(R.string.imp_err), Toast.LENGTH_LONG).show()
        }
    }

    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(stringResource(R.string.macros_title), color = C.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("＋ " + stringResource(R.string.new_macro), selected = true) { editing = Macro() }
            Chip(stringResource(R.string.templates), selected = false) { showTpl = true }
            Chip(stringResource(R.string.import_), selected = false) { importL.launch(arrayOf("*/*")) }
            Chip(stringResource(R.string.export_), selected = false) { exportL.launch("muskup-macros.json") }
        }
        if (macros.isEmpty()) {
            Text(stringResource(R.string.no_macros), color = C.Muted)
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(macros, key = { it.id }) { m ->
                    Surface(
                        Modifier.fillMaxWidth().clickable { editing = m },
                        color = C.Card, shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, C.Border)
                    ) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(colorOf(m.color)), contentAlignment = Alignment.Center) {
                                Text(m.icon, fontSize = 22.sp)
                            }
                            Column(Modifier.weight(1f)) {
                                Text(m.name, color = C.Text, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                Text(stringResource(R.string.steps_count, m.steps.size), color = C.Muted, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showTpl) Dialog(onDismissRequest = { showTpl = false }) {
        CardBox(Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.tpl_title), color = C.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TEMPLATES.forEach { t ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(C.Panel)
                            .clickable { vm.upsertMacro(t.copy(id = newId())); showTpl = false }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(colorOf(t.color)), contentAlignment = Alignment.Center) { Text(t.icon, fontSize = 18.sp) }
                        Text(t.name, color = C.Text)
                    }
                }
            }
        }
    }

    editing?.let { m -> MacroEditor(vm, m, s.lastPeer) { editing = null } }
}

// ---------- редактор ----------
@Composable
fun MacroEditor(vm: SessionVm, initial: Macro, lastPeer: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val isNew = initial.id.isBlank()
    var name by remember { mutableStateOf(initial.name) }
    var icon by remember { mutableStateOf(initial.icon) }
    var color by remember { mutableStateOf(initial.color) }
    val steps = remember { mutableStateListOf<StepUi>().also { l -> initial.steps.forEach { l.add(StepUi.from(it)) } } }
    var error by remember { mutableStateOf<Int?>(null) }
    var showPin by remember { mutableStateOf(false) }

    fun build(): Macro? {
        val js = steps.map { it.toJson() }
        val err = validateSteps(js)
        error = err
        if (err != null) return null
        return Macro(initial.id.ifBlank { newId() }, name.trim().ifBlank { "Команда" }, icon.ifBlank { "⚡" }, color, js)
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = C.Bg) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.macros_title), color = C.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("✕", color = C.Muted, fontSize = 22.sp, modifier = Modifier.clickable { onClose() }.padding(8.dp))
                }
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text(stringResource(R.string.macro_name)) },
                    shape = RoundedCornerShape(16.dp), colors = fieldColors(), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(icon, { icon = it.take(4) }, singleLine = true, label = { Text(stringResource(R.string.macro_icon)) },
                    shape = RoundedCornerShape(16.dp), colors = fieldColors(), modifier = Modifier.fillMaxWidth())
                Text(stringResource(R.string.macro_color), color = C.Muted, fontSize = 13.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MACRO_COLORS.forEach { hex ->
                        Box(
                            Modifier.size(36.dp).clip(CircleShape).background(colorOf(hex))
                                .then(if (hex.equals(color, true)) Modifier.border(2.dp, Color.White, CircleShape) else Modifier)
                                .clickable { color = hex }
                        )
                    }
                }

                steps.forEach { s -> key(s.uid) { StepRow(steps, s) } }

                Text(stringResource(R.string.add_step), color = C.Muted, fontSize = 13.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    STEP_TYPES.forEach { t ->
                        Chip("＋ " + typeLabel(t), selected = false) {
                            if (steps.size < 100) steps.add(StepUi(nextUid(), t).also { if (t == "wait") it.v1 = "300"; if (t == "click") { it.v1 = "50"; it.v2 = "50" } })
                        }
                    }
                }
                error?.let { Text(stringResource(it), color = C.Danger, fontSize = 13.sp) }

                GradButton(stringResource(R.string.save), Modifier.fillMaxWidth()) {
                    build()?.let { vm.upsertMacro(it); onClose() }
                }
                if (!isNew) {
                    OutlinedButton(onClick = { if (build() != null) showPin = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.shortcut_btn))
                    }
                    OutlinedButton(onClick = { vm.deleteMacro(initial.id); onClose() }, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.delete), color = C.Danger)
                    }
                }
            }
        }
    }

    if (showPin) {
        var dev by remember { mutableStateOf(lastPeer) }
        Dialog(onDismissRequest = { showPin = false }) {
            CardBox(Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.shortcut_btn), color = C.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(dev, { v -> dev = v.filter { it.isDigit() }.take(9) }, singleLine = true,
                    label = { Text(stringResource(R.string.shortcut_dev)) }, visualTransformation = IdTransform(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    shape = RoundedCornerShape(16.dp), colors = fieldColors(), modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(14.dp))
                GradButton(stringResource(R.string.create), Modifier.fillMaxWidth(), enabled = dev.length == 9) {
                    val m = build()
                    if (m != null) {
                        vm.upsertMacro(m)
                        val ok = Shortcuts.pin(ctx, m, dev)
                        Toast.makeText(ctx, if (ok) R.string.shortcut_ok else R.string.shortcut_no, Toast.LENGTH_LONG).show()
                    }
                    showPin = false
                }
            }
        }
    }
}

@Composable
private fun SmallField(value: String, label: String, num: Boolean = false, modifier: Modifier = Modifier, onChange: (String) -> Unit) {
    OutlinedTextField(
        value, onChange, singleLine = true, label = { Text(label, fontSize = 12.sp) },
        keyboardOptions = KeyboardOptions(keyboardType = if (num) KeyboardType.Number else KeyboardType.Text),
        shape = RoundedCornerShape(12.dp), colors = fieldColors(), modifier = modifier.fillMaxWidth()
    )
}

/** Рядок кроку; перетягування за «≡» змінює порядок. */
@Composable
private fun StepRow(steps: SnapshotStateList<StepUi>, s: StepUi) {
    var acc by remember { mutableFloatStateOf(0f) }
    var h by remember { mutableIntStateOf(1) }
    Surface(
        Modifier.fillMaxWidth().onSizeChanged { h = it.height },
        color = C.Card, shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, C.Border)
    ) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.Top) {
            Box(
                Modifier.size(40.dp).pointerInput(s.uid) {
                    detectVerticalDragGestures(onDragEnd = { acc = 0f }, onDragCancel = { acc = 0f }) { change, dy ->
                        change.consume()
                        acc += dy
                        val i = steps.indexOf(s)
                        if (acc > h * 0.6f && i in 0 until steps.lastIndex) { steps.add(i + 1, steps.removeAt(i)); acc -= h }
                        else if (acc < -h * 0.6f && i > 0) { steps.add(i - 1, steps.removeAt(i)); acc += h }
                    }
                },
                contentAlignment = Alignment.Center
            ) { Text("≡", color = C.Muted, fontSize = 24.sp) }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(typeLabel(s.type), color = LocalAccent.current.end, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                when (s.type) {
                    "key" -> SmallField(s.v1, stringResource(R.string.f_combo)) { s.v1 = it }
                    "text" -> SmallField(s.v1, stringResource(R.string.f_text)) { s.v1 = it.take(500) }
                    "wait" -> SmallField(s.v1, stringResource(R.string.f_ms), num = true) { s.v1 = it.filter(Char::isDigit).take(5) }
                    "run" -> SmallField(s.v1, stringResource(R.string.f_target)) { s.v1 = it }
                    "url" -> SmallField(s.v1, stringResource(R.string.f_url)) { s.v1 = it }
                    "click" -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SmallField(s.v1, stringResource(R.string.f_x), true, Modifier.weight(1f)) { s.v1 = it.filter(Char::isDigit).take(3) }
                            SmallField(s.v2, stringResource(R.string.f_y), true, Modifier.weight(1f)) { s.v2 = it.filter(Char::isDigit).take(3) }
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Chip(stringResource(R.string.f_left), selected = s.btn == "left") { s.btn = "left" }
                            Chip(stringResource(R.string.f_right), selected = s.btn == "right") { s.btn = "right" }
                            Chip(stringResource(R.string.f_double), selected = s.dbl) { s.dbl = !s.dbl }
                        }
                    }
                }
            }
            Text("✕", color = C.Muted, fontSize = 18.sp, modifier = Modifier.clickable { steps.remove(s) }.padding(10.dp))
        }
    }
}

// ---------- панель у сеансі ----------
@Composable
fun MacroPanelHost(vm: SessionVm, visible: Boolean, modifier: Modifier) {
    AnimatedVisibility(visible, modifier = modifier, enter = slideInHorizontally { it }, exit = slideOutHorizontally { it }) {
        val macros by vm.macros.collectAsStateWithLifecycle()
        val perms by vm.perms.collectAsStateWithLifecycle()
        Column(
            Modifier.width(160.dp).fillMaxHeight().background(C.Panel.copy(alpha = 0.92f))
                .verticalScroll(rememberScrollState()).padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Spacer(Modifier.height(84.dp)) // під верхньою панеллю
            if (!perms.macros) Text(stringResource(R.string.macros_off), color = C.Warn, fontSize = 12.sp)
            Chip("⏹ " + stringResource(R.string.stop), selected = true, color = C.Danger) { vm.stopMacro() }
            macros.forEach { m ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(colorOf(m.color).copy(alpha = if (perms.macros) 1f else 0.35f))
                        .clickable(enabled = perms.macros) { vm.runMacro(m) }.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(m.icon, fontSize = 18.sp)
                    Text(m.name, color = Color.White, fontSize = 13.sp, maxLines = 2)
                }
            }
        }
    }
}
