package app.muskup.remote

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Лог у файл. НІКОЛИ не передавай сюди пароль ПК. */
object AppLog {
    private var file: File? = null
    private val fmt = SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US)

    fun init(ctx: Context) {
        val f = File(ctx.filesDir, "muskup.log")
        if (f.length() > 1_000_000) f.delete()
        file = f
    }

    @Synchronized
    fun log(tag: String, msg: String) {
        val line = "${fmt.format(Date())} $tag: $msg"
        Log.d("MUSKUP", line)
        runCatching { file?.appendText(line + "\n") }
    }

    fun read(): String = runCatching { file?.readText() ?: "" }.getOrDefault("")
}
