package app.muskup.remote

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object C {
    val Bg = Color(0xFF000000)
    val Panel = Color(0xFF08080D)
    val Card = Color(0xFF0D0D14)
    val Border = Color(0xFF1A1A25)
    val Text = Color(0xFFF4F4F8)
    val Muted = Color(0xFF8B8B9C)
    val Online = Color(0xFF2FD37A)
    val Danger = Color(0xFFE5484D)
    val Warn = Color(0xFFFFB020)
}

/** Фіолетова — з макета. Інші 5 кольорів підібрано в тому ж стилі (ПОЗНАЧКА: погодити з замовником). */
enum class AppTheme(val key: String, val start: Color, val end: Color) {
    Purple("purple", Color(0xFF4A2BE0), Color(0xFF6D4AFF)),
    Blue("blue", Color(0xFF1D5FE0), Color(0xFF3D8BFF)),
    Green("green", Color(0xFF12A150), Color(0xFF2FD37A)),
    Red("red", Color(0xFFD6252E), Color(0xFFFF5560)),
    Yellow("yellow", Color(0xFFD9A400), Color(0xFFFFD23D)),
    Gray("gray", Color(0xFF55555F), Color(0xFF8B8B9C));

    val brush: Brush get() = Brush.horizontalGradient(listOf(start, end))

    companion object {
        fun from(k: String) = entries.firstOrNull { it.key == k } ?: Purple
    }
}

val LocalAccent = staticCompositionLocalOf { AppTheme.Purple }

@Composable
fun MuskupTheme(theme: AppTheme, content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalAccent provides theme) {
        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = theme.end, onPrimary = Color.White,
                background = C.Bg, onBackground = C.Text,
                surface = C.Panel, onSurface = C.Text,
                surfaceVariant = C.Card, onSurfaceVariant = C.Muted,
                outline = C.Border,
            ),
            content = content
        )
    }
}
