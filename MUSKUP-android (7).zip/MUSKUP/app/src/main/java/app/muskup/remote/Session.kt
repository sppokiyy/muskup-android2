package app.muskup.remote

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.SystemClock
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEvent
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import org.webrtc.EglBase
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.abs
import kotlin.math.max

private const val SENT = "\u200B\u200B\u200B\u200B\u200B\u200B\u200B\u200B"

private fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }
    return null
}

@Composable
fun SessionScreen(vm: SessionVm) {
    val track by vm.video.collectAsStateWithLifecycle()
    val vsize by vm.videoSize.collectAsStateWithLifecycle()
    val perms by vm.perms.collectAsStateWithLifecycle()
    val stats by vm.stats.collectAsStateWithLifecycle()
    val ctlOn by vm.controlEnabled.collectAsStateWithLifecycle()
    val mods by vm.mods.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val haptic = LocalHapticFeedback.current
    val view = LocalView.current

    var touchMode by rememberSaveable { mutableStateOf(false) }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    var showKeys by remember { mutableStateOf(false) }
    var showKb by remember { mutableStateOf(false) }
    var showMacros by remember { mutableStateOf(false) }
    val canControl = perms.control && ctlOn

    // Повноекранний режим + утримання екрана
    DisposableEffect(Unit) {
        val w = view.context.findActivity()?.window
        val c = w?.let { WindowCompat.getInsetsController(it, view) }
        c?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { c?.show(WindowInsetsCompat.Type.systemBars()) }
    }
    val keepOn = settings?.keepOn ?: true
    DisposableEffect(keepOn) { view.keepScreenOn = keepOn; onDispose { view.keepScreenOn = false } }

    // Прямокутник відео в контейнері (збереження пропорцій)
    fun fit(): Rect {
        val vw = max(vsize.first, 1).toFloat(); val vh = max(vsize.second, 1).toFloat()
        val cw = max(box.width, 1).toFloat(); val ch = max(box.height, 1).toFloat()
        val k = minOf(cw / vw, ch / vh)
        val w = vw * k; val h = vh * k
        return Rect((cw - w) / 2f, (ch - h) / 2f, (cw + w) / 2f, (ch + h) / 2f)
    }

    Box(Modifier.fillMaxSize().background(Color.Black).onSizeChanged { box = it }) {
        VideoView(
            track, vm.engine.egl, vm::onVideoSize,
            Modifier.fillMaxSize().graphicsLayer(
                scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y
            )
        )

        // Шар жестів
        Box(
            Modifier.fillMaxSize().pointerInput(touchMode, canControl) {
                remoteGestures(
                    touchMode = touchMode, canControl = { canControl }, fit = { fit() },
                    getView = { Pair(scale, offset) },
                    setView = { s, o -> scale = s; offset = o },
                    vm = vm, onLongPress = { haptic.performHapticFeedback(HapticFeedbackType.LongPress) }
                )
            }
        )

        // Верхня панель
        Column(Modifier.align(Alignment.TopCenter).fillMaxWidth().background(C.Panel.copy(alpha = 0.85f)).padding(horizontal = 8.dp, vertical = 6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip(stringResource(R.string.end_session), color = C.Danger, selected = true) { vm.cancel() }
                Text(
                    "${stats.fps} fps · ${if (stats.pingMs >= 0) "${stats.pingMs} мс" else "— мс"} · ${"%.1f".format(stats.mbps)} Мбіт/с",
                    color = C.Muted, fontSize = 11.sp, modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (perms.control) {
                    Chip(stringResource(if (ctlOn) R.string.mode_control else R.string.mode_view), selected = ctlOn) {
                        vm.controlEnabled.value = !ctlOn
                    }
                } else {
                    Chip(stringResource(R.string.host_no_control), color = C.Warn, selected = false) {}
                }
                Chip(stringResource(if (touchMode) R.string.mode_touch else R.string.mode_touchpad), selected = true) { touchMode = !touchMode }
                Chip("⌨", selected = showKb) { showKb = !showKb }
                Chip("Fn", selected = showKeys) { showKeys = !showKeys }
                Chip("⚡", selected = showMacros) { showMacros = !showMacros }
                if (scale > 1.01f) Chip("⤢ 100%", selected = false) { scale = 1f; offset = Offset.Zero }
            }
        }

        MacroPanelHost(vm, showMacros, Modifier.align(Alignment.CenterEnd))

        if (showKeys) {
            Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(C.Panel.copy(alpha = 0.9f)).padding(8.dp)) {
                KeysPanel(vm, mods)
            }
        }

        if (showKb) HiddenKeyboard(vm) { showKb = false }
    }
}

@Composable
fun Chip(text: String, selected: Boolean, color: Color? = null, onClick: () -> Unit) {
    val a = LocalAccent.current
    val bg = if (selected) (color ?: a.start) else C.Card
    Box(
        Modifier.clip(RoundedCornerShape(12.dp)).background(bg).clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = if (selected) Color.White else C.Text, fontSize = 12.sp, maxLines = 1) }
}

@Composable
fun KeysPanel(vm: SessionVm, mods: Map<String, Int>) {
    val keys = listOf(
        "Esc" to "Esc", "Tab" to "Tab", "Ctrl" to "Ctrl", "Alt" to "Alt", "Win" to "Win", "Shift" to "Shift",
        "←" to "Left", "↑" to "Up", "↓" to "Down", "→" to "Right", "Del" to "Delete",
        "Enter" to "Enter", "Bksp" to "Backspace", "Home" to "Home", "End" to "End", "PgUp" to "PageUp", "PgDn" to "PageDown",
    ) + (1..12).map { "F$it" to "F$it" }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        keys.forEach { (label, name) ->
            val m = mods[name] ?: 0
            Chip(label + if (m == 2) " 🔒" else "", selected = m > 0) {
                if (name in MODS) vm.toggleMod(name) else vm.pressKey(name)
            }
        }
    }
}

/** Прихований текстовий ввід: відкриває системну клавіатуру, текст → крок набору {"t":"t"}. */
@Composable
fun HiddenKeyboard(vm: SessionVm, onDone: () -> Unit) {
    val focus = remember { FocusRequester() }
    val kb = LocalSoftwareKeyboardController.current
    var tf by remember { mutableStateOf(TextFieldValue(SENT, TextRange(SENT.length))) }
    BasicTextField(
        value = tf,
        onValueChange = { nv ->
            val diff = nv.text.length - SENT.length
            if (diff > 0) vm.typed(nv.text.takeLast(diff))
            else if (diff < 0) repeat(-diff) { vm.pressKey("Backspace") }
            tf = TextFieldValue(SENT, TextRange(SENT.length))
        },
        modifier = Modifier.size(1.dp).focusRequester(focus),
        textStyle = TextStyle(color = Color.Transparent, fontSize = 1.sp),
        cursorBrush = SolidColor(Color.Transparent),
        keyboardOptions = KeyboardOptions(autoCorrect = false, keyboardType = KeyboardType.Text, imeAction = ImeAction.Send),
        keyboardActions = KeyboardActions(onSend = { vm.pressKey("Enter") }),
    )
    LaunchedEffect(Unit) { focus.requestFocus(); kb?.show() }
    DisposableEffect(Unit) { onDispose { kb?.hide() } }
}

@Composable
fun VideoView(track: VideoTrack?, egl: EglBase, onSize: (Int, Int) -> Unit, modifier: Modifier) {
    class Holder { var t: VideoTrack? = null }
    val holder = remember { Holder() }
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            SurfaceViewRenderer(ctx).apply {
                init(egl.eglBaseContext, object : RendererCommon.RendererEvents {
                    override fun onFirstFrameRendered() {}
                    override fun onFrameResolutionChanged(w: Int, h: Int, rotation: Int) {
                        if (rotation % 180 == 0) onSize(w, h) else onSize(h, w)
                    }
                })
                setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT)
                setEnableHardwareScaler(true)
            }
        },
        update = { r ->
            if (holder.t !== track) {
                holder.t?.let { runCatching { it.removeSink(r) } }
                track?.addSink(r)
                holder.t = track
            }
        },
        onRelease = { r ->
            holder.t?.let { runCatching { it.removeSink(r) } }
            holder.t = null
            r.release()
        }
    )
}

/**
 * Жести. Координати йдуть нормалізовано по КАДРУ відео (не по екрану).
 * Тачпад: рух = відносний курсор; тап = ЛКМ; тап 2 пальцями = ПКМ; 2 пальці = колесо (або щіпок = масштаб);
 * довге утримання + рух = перетягування. Дотик: курсор у точці дотику; рух = перетягування; 2 пальці = масштаб/переміщення.
 */
private suspend fun PointerInputScope.remoteGestures(
    touchMode: Boolean,
    canControl: () -> Boolean,
    fit: () -> Rect,
    getView: () -> Pair<Float, Offset>,
    setView: (Float, Offset) -> Unit,
    vm: SessionVm,
    onLongPress: () -> Unit,
) {
    val slop = viewConfiguration.touchSlop
    val longMs = 450L
    val scrollStep = 24f

    fun center() = Offset(size.width / 2f, size.height / 2f)
    fun norm(p: Offset): Offset {
        val (s, t) = getView()
        val q = center() + (p - center() - t) / s
        val r = fit()
        return Offset(((q.x - r.left) / r.width).coerceIn(0f, 1f), ((q.y - r.top) / r.height).coerceIn(0f, 1f))
    }
    fun clampT(t: Offset, s: Float): Offset {
        val mx = (s - 1f) * size.width / 2f; val my = (s - 1f) * size.height / 2f
        return Offset(t.x.coerceIn(-mx, mx), t.y.coerceIn(-my, my))
    }

    awaitEachGesture {
        val first = awaitFirstDown(requireUnconsumed = false)
        val t0 = SystemClock.uptimeMillis()
        var maxPtr = 1
        var moved = 0f
        var armed = true
        var dragging = false
        var pressedTouch = false
        var mode = 0 // 0 — не визначено, 1 — масштаб/переміщення, 2 — прокрутка
        var twoStarted = false
        var startSpan = 0f; var startCentroid = Offset.Zero
        var prevSpan = 0f; var prevCentroid = Offset.Zero
        var acc = Offset.Zero
        var lastPos = first.position
        val startPos = first.position
        first.consume()

        while (true) {
            val ev: PointerEvent? = if (armed) {
                val left = longMs - (SystemClock.uptimeMillis() - t0)
                withTimeoutOrNull(max(left, 1L)) { awaitPointerEvent() }
            } else awaitPointerEvent()

            if (ev == null) { // таймаут довгого утримання
                armed = false
                if (maxPtr == 1 && moved < slop && canControl()) {
                    dragging = true
                    if (touchMode) vm.moveTo(norm(lastPos).x, norm(lastPos).y, true)
                    vm.button("l", true)
                    onLongPress()
                }
                continue
            }

            val pressed = ev.changes.filter { it.pressed }
            if (pressed.isEmpty()) {
                val dur = SystemClock.uptimeMillis() - t0
                if (canControl()) {
                    when {
                        dragging || pressedTouch -> vm.button("l", false)
                        maxPtr == 1 && moved < slop && dur < longMs -> {
                            if (touchMode) { val n = norm(lastPos); vm.moveTo(n.x, n.y, true) }
                            vm.click("l")
                        }
                        maxPtr == 2 && mode == 0 && dur < 500 -> vm.click("r")
                    }
                    vm.flushMove()
                }
                ev.changes.forEach { it.consume() }
                break
            }

            maxPtr = max(maxPtr, pressed.size)

            if (pressed.size == 1 && maxPtr == 1) {
                val c = pressed[0]
                val d = c.position - c.previousPosition
                moved += d.getDistance()
                if (moved >= slop) armed = false
                if (canControl()) {
                    if (touchMode) {
                        if (!dragging && !pressedTouch && moved >= slop) {
                            val n = norm(startPos); vm.moveTo(n.x, n.y, true)
                            vm.button("l", true); pressedTouch = true
                        }
                        if (dragging || pressedTouch) { val n = norm(c.position); vm.moveTo(n.x, n.y) }
                    } else if (moved >= slop || dragging) {
                        val r = fit(); val s = getView().first
                        val k = 1.4f
                        vm.moveBy(d.x * k / (r.width * s), d.y * k / (r.height * s))
                    }
                }
                lastPos = c.position
            } else if (pressed.size >= 2) {
                armed = false
                val a = pressed[0]; val b = pressed[1]
                val cNow = (a.position + b.position) / 2f
                val sNow = (a.position - b.position).getDistance()
                if (!twoStarted) {
                    twoStarted = true
                    if (pressedTouch) { vm.button("l", false); pressedTouch = false }
                    startSpan = sNow; startCentroid = cNow; prevSpan = sNow; prevCentroid = cNow
                } else {
                    if (mode == 0) {
                        val spanD = abs(sNow - startSpan)
                        val panD = (cNow - startCentroid).getDistance()
                        if (spanD > slop && spanD > panD) mode = 1
                        else if (panD > slop) mode = if (touchMode || !canControl()) 1 else 2
                    }
                    val delta = cNow - prevCentroid
                    if (mode == 1) {
                        val (s, t) = getView()
                        val zoom = if (prevSpan > 0f) sNow / prevSpan else 1f
                        val s2 = (s * zoom).coerceIn(1f, 6f)
                        val t2 = cNow - center() - (prevCentroid - center() - t) * (s2 / s)
                        setView(s2, clampT(t2, s2))
                    } else if (mode == 2) {
                        acc += delta
                        val sy = (acc.y / scrollStep).toInt()
                        val sx = (acc.x / scrollStep).toInt()
                        if (sy != 0 || sx != 0) {
                            vm.wheel(-sx * 120, sy * 120)
                            acc = Offset(acc.x - sx * scrollStep, acc.y - sy * scrollStep)
                        }
                    }
                    prevCentroid = cNow; prevSpan = sNow
                }
            }
            ev.changes.forEach { it.consume() }
        }
    }
}
