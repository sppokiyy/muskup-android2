package app.muskup.remote

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay

@Composable
fun MuskupApp(vm: SessionVm) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val st = s
    MuskupTheme(AppTheme.from(st?.theme ?: "purple")) {
        val state by vm.state.collectAsStateWithLifecycle()
        val notice by vm.notice.collectAsStateWithLifecycle()
        Box(Modifier.fillMaxSize().background(C.Bg)) {
            if (st != null) {
                if (state is SessionState.Active) SessionScreen(vm) else MainScaffold(vm, st)
            }
            if (state is SessionState.Requesting || state is SessionState.Connecting) {
                WaitDialog(state is SessionState.Requesting) { vm.cancel() }
            }
            NoticeBanner(notice) { vm.clearNotice() }
        }
    }
}

// ---------- спільні елементи ----------
@Composable
fun CardBox(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(modifier, color = C.Card, shape = RoundedCornerShape(24.dp), border = BorderStroke(1.dp, C.Border)) {
        Column(Modifier.padding(18.dp), content = content)
    }
}

@Composable
fun GradButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    val a = LocalAccent.current
    val bg = if (enabled) a.brush else Brush.horizontalGradient(listOf(C.Border, C.Border))
    Box(
        modifier.height(52.dp).clip(RoundedCornerShape(16.dp)).background(bg)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.SemiBold) }
}

/** ТИМЧАСОВО: плейсхолдер логотипа, поки не підключено assets/logo-mark.svg. */
@Composable
fun LogoMark(size: androidx.compose.ui.unit.Dp) {
    val a = LocalAccent.current
    Box(Modifier.size(size).clip(RoundedCornerShape(size / 4)).background(a.brush), contentAlignment = Alignment.Center) {
        Text("M", color = Color.White, fontSize = (size.value * 0.55f).sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun NoticeBanner(n: Notice?, onDismiss: () -> Unit) {
    if (n == null) return
    LaunchedEffect(n.stamp) { delay(4500); onDismiss() }
    val color = when (n.kind) { NoticeKind.Success -> C.Online; NoticeKind.Warning -> C.Warn; NoticeKind.Error -> C.Danger }
    Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.TopCenter) {
        Surface(
            color = C.Card, shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, color),
            modifier = Modifier.clickable { onDismiss() }
        ) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(color))
                Text(n.text, color = C.Text, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun WaitDialog(requesting: Boolean, onCancel: () -> Unit) {
    Dialog(onDismissRequest = {}) {
        CardBox {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                CircularProgressIndicator(Modifier.size(28.dp), color = LocalAccent.current.end, strokeWidth = 3.dp)
                Text(stringResource(if (requesting) R.string.waiting_confirm else R.string.connecting_media), color = C.Text)
            }
            Spacer(Modifier.height(16.dp))
            TextButton(onClick = onCancel, modifier = Modifier.align(Alignment.End)) { Text(stringResource(R.string.cancel)) }
        }
    }
}

@Composable
fun fieldColors(): TextFieldColors {
    val a = LocalAccent.current
    return OutlinedTextFieldDefaults.colors(
        focusedBorderColor = a.end, unfocusedBorderColor = C.Border,
        focusedContainerColor = C.Card, unfocusedContainerColor = C.Card,
        focusedTextColor = C.Text, unfocusedTextColor = C.Text,
        cursorColor = a.end, focusedLabelColor = a.end, unfocusedLabelColor = C.Muted,
    )
}

// ---------- каркас з нижньою навігацією ----------
@Composable
fun MainScaffold(vm: SessionVm, s: Settings) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val a = LocalAccent.current
    val macros by vm.macros.collectAsStateWithLifecycle()
    val pending by vm.pending.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    LaunchedEffect(macros, s.lastPeer) { Shortcuts.updateDynamic(ctx, macros, s.lastPeer) }
    LaunchedEffect(pending) { if (pending != null) tab = 0 }
    val items = listOf(
        Icons.Filled.Home to R.string.nav_desktop,
        Icons.Filled.Person to R.string.nav_contacts,
        Icons.Filled.PlayArrow to R.string.nav_macros,
        Icons.Filled.List to R.string.nav_history,
        Icons.Filled.Settings to R.string.nav_settings,
    )
    Scaffold(
        containerColor = C.Bg,
        bottomBar = {
            NavigationBar(containerColor = C.Panel) {
                items.forEachIndexed { i, (icon, label) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icon, null) },
                        label = { Text(stringResource(label), fontSize = 10.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White, selectedTextColor = a.end,
                            indicatorColor = a.start.copy(alpha = 0.55f),
                            unselectedIconColor = C.Muted, unselectedTextColor = C.Muted
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(vm, s, onHistory = { tab = 3 }, onSettings = { tab = 4 })
                2 -> MacrosScreen(vm, s)
                4 -> SettingsScreen(vm, s)
                else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(stringResource(items[tab].second), color = C.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        Text(stringResource(R.string.soon), color = C.Muted)
                    }
                }
            }
        }
    }
}

// ---------- головний екран ----------
@Composable
fun HomeScreen(vm: SessionVm, s: Settings, onHistory: () -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val online by vm.signaling.registered.collectAsStateWithLifecycle()
    var showConnect by remember { mutableStateOf(false) }
    var showSec by remember { mutableStateOf(false) }
    val pending by vm.pending.collectAsStateWithLifecycle()
    val macros by vm.macros.collectAsStateWithLifecycle()
    LaunchedEffect(pending) {
        if (pending != null) {
            if (s.serverUrl.isBlank()) Toast.makeText(ctx, R.string.need_server, Toast.LENGTH_LONG).show() else showConnect = true
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        LogoMark(112.dp)
        Text("MUSKUP", color = C.Text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(stringResource(R.string.tagline1), color = C.Text, fontSize = 16.sp, textAlign = TextAlign.Center)
        Text(stringResource(R.string.tagline2), color = C.Muted, fontSize = 14.sp)
        Spacer(Modifier.height(4.dp))

        CardBox(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.nav_desktop), color = C.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Box(Modifier.size(9.dp).clip(CircleShape).background(if (online) C.Online else C.Muted))
                Spacer(Modifier.width(6.dp))
                Text(stringResource(if (online) R.string.online else R.string.offline), color = if (online) C.Online else C.Muted, fontSize = 12.sp)
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                GradButton(stringResource(R.string.connect), Modifier.weight(1f)) {
                    if (s.serverUrl.isBlank()) Toast.makeText(ctx, R.string.need_server, Toast.LENGTH_LONG).show()
                    else showConnect = true
                }
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(C.Panel)
                        .clickable { onHistory() },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.List, null, tint = C.Muted) }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tile(Icons.Filled.Person, stringResource(R.string.tile_id), Modifier.weight(1f)) {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("id", s.myId))
                Toast.makeText(ctx, ctx.getString(R.string.id_copied), Toast.LENGTH_SHORT).show()
            }
            Tile(Icons.Filled.Lock, stringResource(R.string.tile_security), Modifier.weight(1f)) { showSec = true }
            Tile(Icons.Filled.Settings, stringResource(R.string.nav_settings), Modifier.weight(1f), onClick = onSettings)
        }
        Text("${stringResource(R.string.your_id)}: ${fmtId(s.myId)}", color = C.Muted, fontSize = 13.sp)
    }

    if (showConnect) ConnectDialog(
        initialId = pending?.deviceId?.ifBlank { null } ?: "",
        hint = pending?.let { p -> macros.firstOrNull { it.id == p.macroId }?.let { stringResource(R.string.pending_hint, it.name) } },
        onDismiss = { showConnect = false; vm.pending.value = null },
        onConnect = { id, pass -> showConnect = false; vm.connect(id, pass) }
    )
    if (showSec) AlertDialog(
        onDismissRequest = { showSec = false },
        confirmButton = { TextButton(onClick = { showSec = false }) { Text(stringResource(R.string.ok)) } },
        title = { Text(stringResource(R.string.tile_security)) },
        text = { Text(stringResource(R.string.security_text)) },
        containerColor = C.Card, titleContentColor = C.Text, textContentColor = C.Muted
    )
}

fun fmtId(id: String) = id.chunked(3).joinToString(" ")

@Composable
fun Tile(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        modifier.clickable(onClick = onClick), color = C.Card, shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, C.Border)
    ) {
        Column(Modifier.padding(vertical = 16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = LocalAccent.current.end)
            Text(label, color = C.Text, fontSize = 11.sp, maxLines = 1)
        }
    }
}

/** Поле ID у вигляді 123 456 789 */
class IdTransform : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val t = text.text
        val out = buildString { t.forEachIndexed { i, c -> if (i == 3 || i == 6) append(' '); append(c) } }
        val map = object : OffsetMapping {
            override fun originalToTransformed(offset: Int) = offset + (if (offset > 6) 2 else if (offset > 3) 1 else 0)
            override fun transformedToOriginal(offset: Int) =
                (offset - (if (offset > 7) 2 else if (offset > 3) 1 else 0)).coerceIn(0, t.length)
        }
        return TransformedText(AnnotatedString(out), map)
    }
}

@Composable
fun ConnectDialog(initialId: String, hint: String?, onDismiss: () -> Unit, onConnect: (String, String) -> Unit) {
    var id by remember { mutableStateOf(initialId) }
    var pass by remember { mutableStateOf("") }
    Dialog(onDismissRequest = onDismiss) {
        CardBox(Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.dlg_connect_title), color = C.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            if (hint != null) { Spacer(Modifier.height(6.dp)); Text(hint, color = C.Muted, fontSize = 12.sp) }
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                id, { v -> id = v.filter { it.isDigit() }.take(9) }, singleLine = true,
                label = { Text(stringResource(R.string.field_id)) },
                visualTransformation = IdTransform(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                shape = RoundedCornerShape(16.dp), colors = fieldColors(), modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                pass, { pass = it }, singleLine = true,
                label = { Text(stringResource(R.string.field_pass)) },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                shape = RoundedCornerShape(16.dp), colors = fieldColors(), modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(16.dp))
            GradButton(stringResource(R.string.connect), Modifier.fillMaxWidth(), enabled = id.length == 9 && pass.isNotEmpty()) {
                onConnect(id, pass)
            }
        }
    }
}

// ---------- налаштування ----------
@Composable
fun SettingsScreen(vm: SessionVm, s: Settings) {
    val ctx = LocalContext.current
    var url by remember(s.serverUrl) { mutableStateOf(s.serverUrl) }
    var tUrl by remember(s.turnUrl) { mutableStateOf(s.turnUrl) }
    var tUser by remember(s.turnUser) { mutableStateOf(s.turnUser) }
    var tPass by remember(s.turnPass) { mutableStateOf(s.turnPass) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(stringResource(R.string.nav_settings), color = C.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            url, { url = it }, singleLine = true, label = { Text(stringResource(R.string.set_server)) },
            placeholder = { Text("wss://muskup-signal.XXX.workers.dev", color = C.Muted) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            shape = RoundedCornerShape(16.dp), colors = fieldColors(), modifier = Modifier.fillMaxWidth()
        )
        Text(stringResource(R.string.set_turn), color = C.Muted, fontSize = 13.sp)
        OutlinedTextField(tUrl, { tUrl = it }, singleLine = true, label = { Text(stringResource(R.string.turn_url)) },
            shape = RoundedCornerShape(16.dp), colors = fieldColors(), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(tUser, { tUser = it }, singleLine = true, label = { Text(stringResource(R.string.turn_user)) },
            shape = RoundedCornerShape(16.dp), colors = fieldColors(), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(tPass, { tPass = it }, singleLine = true, label = { Text(stringResource(R.string.turn_pass)) },
            visualTransformation = PasswordVisualTransformation(),
            shape = RoundedCornerShape(16.dp), colors = fieldColors(), modifier = Modifier.fillMaxWidth())
        GradButton(stringResource(R.string.save), Modifier.fillMaxWidth()) {
            vm.saveString(K.server, url.trim()); vm.saveString(K.turnUrl, tUrl.trim())
            vm.saveString(K.turnUser, tUser.trim()); vm.saveString(K.turnPass, tPass)
            Toast.makeText(ctx, R.string.saved, Toast.LENGTH_SHORT).show()
        }

        Text(stringResource(R.string.set_theme), color = C.Muted, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            AppTheme.entries.forEach { t ->
                Box(
                    Modifier.size(38.dp).clip(CircleShape).background(t.brush)
                        .clickable { vm.saveString(K.theme, t.key) },
                    contentAlignment = Alignment.Center
                ) { if (t.key == s.theme) Icon(Icons.Filled.Check, null, tint = Color.White) }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.set_keepon), color = C.Text, modifier = Modifier.weight(1f))
            Switch(s.keepOn, { vm.saveBool(K.keepOn, it) }, colors = SwitchDefaults.colors(checkedTrackColor = LocalAccent.current.end))
        }

        OutlinedButton(onClick = {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("log", AppLog.read().takeLast(200_000)))
            Toast.makeText(ctx, R.string.log_copied, Toast.LENGTH_SHORT).show()
        }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.copy_log)) }

        Text("${stringResource(R.string.version)}: ${BuildConfig.VERSION_NAME}", color = C.Muted, fontSize = 12.sp)
    }
}
