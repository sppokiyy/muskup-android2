package app.muskup.remote

import android.content.Context
import org.webrtc.*
import java.nio.ByteBuffer

class RtcEngine(app: Context) {
    val egl: EglBase = EglBase.create()
    val factory: PeerConnectionFactory

    init {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(app).createInitializationOptions()
        )
        factory = PeerConnectionFactory.builder()
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(egl.eglBaseContext)) // апаратне декодування
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(egl.eglBaseContext, true, true))
            .createPeerConnectionFactory()
    }
}

open class SdpObs : SdpObserver {
    override fun onCreateSuccess(d: SessionDescription?) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(e: String?) {}
    override fun onSetFailure(e: String?) {}
}

/** Один сеанс WebRTC: клієнт тільки приймає (offer від хоста). */
class Peer(engine: RtcEngine, servers: List<PeerConnection.IceServer>, private val cb: Callbacks) {
    interface Callbacks {
        fun onLocalIce(c: IceCandidate)
        fun onVideo(t: VideoTrack)
        fun onCtlText(s: String)
        fun onState(s: PeerConnection.PeerConnectionState)
    }

    private val pending = ArrayList<IceCandidate>()
    @Volatile private var remoteSet = false
    @Volatile private var ctl: DataChannel? = null
    @Volatile private var mv: DataChannel? = null

    private val observer = object : PeerConnection.Observer {
        override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
        override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) { AppLog.log("rtc", "ice=$s") }
        override fun onIceConnectionReceivingChange(b: Boolean) {}
        override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {}
        override fun onIceCandidate(c: IceCandidate?) { if (c != null) cb.onLocalIce(c) }
        override fun onIceCandidatesRemoved(c: Array<out IceCandidate>?) {}
        override fun onAddStream(s: MediaStream?) {}
        override fun onRemoveStream(s: MediaStream?) {}
        override fun onRenegotiationNeeded() {}
        override fun onConnectionChange(s: PeerConnection.PeerConnectionState?) {
            AppLog.log("rtc", "conn=$s"); if (s != null) cb.onState(s)
        }
        override fun onTrack(t: RtpTransceiver?) {
            val r = t?.receiver ?: return
            val tr = r.track()
            if (tr is VideoTrack) {
                tr.setEnabled(true)
                // Мінімальна затримка буфера (якщо підтримується збіркою)
                runCatching {
                    r.javaClass.getMethod("setJitterBufferMinimumPlayoutDelay", Double::class.javaObjectType)
                        .invoke(r, 0.0)
                }
                AppLog.log("rtc", "video track")
                cb.onVideo(tr)
            }
        }
        override fun onDataChannel(dc: DataChannel?) {
            if (dc == null) return
            AppLog.log("rtc", "datachannel ${dc.label()}")
            when (dc.label()) {
                "ctl" -> {
                    ctl = dc
                    dc.registerObserver(object : DataChannel.Observer {
                        override fun onBufferedAmountChange(p: Long) {}
                        override fun onStateChange() { AppLog.log("rtc", "ctl state=${dc.state()}") }
                        override fun onMessage(b: DataChannel.Buffer?) {
                            if (b == null || b.binary) return
                            val bytes = ByteArray(b.data.remaining()); b.data.get(bytes)
                            cb.onCtlText(String(bytes, Charsets.UTF_8))
                        }
                    })
                }
                "mv" -> mv = dc
            }
        }
    }

    private val pc: PeerConnection

    init {
        val cfg = PeerConnection.RTCConfiguration(servers).apply {
            bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
        }
        pc = engine.factory.createPeerConnection(cfg, observer)!!
    }

    fun connectionState() = pc.connectionState()

    fun handleOffer(sdp: String, onAnswer: (String) -> Unit, onFail: (String) -> Unit) {
        pc.setRemoteDescription(object : SdpObs() {
            override fun onSetSuccess() {
                remoteSet = true
                flushIce()
                pc.createAnswer(object : SdpObs() {
                    override fun onCreateSuccess(d: SessionDescription?) {
                        if (d == null) return onFail("empty answer")
                        pc.setLocalDescription(object : SdpObs() {
                            override fun onSetSuccess() { onAnswer(d.description) }
                            override fun onSetFailure(e: String?) { onFail("setLocal: $e") }
                        }, d)
                    }
                    override fun onCreateFailure(e: String?) { onFail("createAnswer: $e") }
                }, MediaConstraints())
            }
            override fun onSetFailure(e: String?) { onFail("setRemote: $e") }
        }, SessionDescription(SessionDescription.Type.OFFER, sdp))
    }

    fun addIce(c: IceCandidate) {
        if (remoteSet) pc.addIceCandidate(c) else synchronized(pending) { pending.add(c) }
    }

    private fun flushIce() {
        val list = synchronized(pending) { pending.toList().also { pending.clear() } }
        list.forEach { pc.addIceCandidate(it) }
    }

    private fun DataChannel.sendText(s: String): Boolean =
        state() == DataChannel.State.OPEN &&
            send(DataChannel.Buffer(ByteBuffer.wrap(s.toByteArray(Charsets.UTF_8)), false))

    fun sendCtl(s: String): Boolean = ctl?.sendText(s) ?: false
    /** Рух миші йде в "mv"; якщо його нема — у "ctl". */
    fun sendMv(s: String): Boolean = mv?.sendText(s) ?: sendCtl(s)

    /** fps, байти відео, ping мс (-1 якщо невідомо) */
    fun stats(cb: (Int, Long, Int) -> Unit) {
        pc.getStats { report ->
            var fps = 0; var bytes = 0L; var rtt = -1
            for (st in report.statsMap.values) {
                val m = st.members
                if (st.type == "inbound-rtp" && (m["kind"] == "video" || m["mediaType"] == "video")) {
                    fps = (m["framesPerSecond"] as? Number)?.toInt() ?: 0
                    bytes = (m["bytesReceived"] as? Number)?.toLong() ?: 0L
                } else if (st.type == "candidate-pair" && m["state"] == "succeeded") {
                    val r = (m["currentRoundTripTime"] as? Number)?.toDouble()
                    if (r != null) rtt = (r * 1000).toInt()
                }
            }
            cb(fps, bytes, rtt)
        }
    }

    fun close() {
        runCatching { ctl?.close() }
        runCatching { mv?.close() }
        runCatching { pc.close() }
        runCatching { pc.dispose() }
    }
}
