package app.muskup.remote

import android.content.Context
import android.content.Intent
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.*
import java.util.UUID

/** Формат сумісний із Windows-версією: {"muskup":1,"macros":[{"id","name","icon","color","steps":[...]}]} */
@Serializable
data class Macro(
    val id: String = "",
    val name: String = "",
    val icon: String = "⚡",
    val color: String = "#6d4aff",
    val steps: List<JsonObject> = emptyList(),
)

@Serializable
data class Export(val muskup: Int = 1, val macros: List<Macro> = emptyList())

val JX = Json { ignoreUnknownKeys = true; encodeDefaults = true; prettyPrint = true }

fun newId(): String = UUID.randomUUID().toString().take(8)

fun parseMacros(json: String?): List<Macro> =
    if (json.isNullOrBlank()) emptyList()
    else runCatching { JX.decodeFromString<Export>(json).macros }.getOrDefault(emptyList())

/** Повертає id рядка з помилкою або null, якщо кроки коректні. Ліміти: до 100 кроків, text до 500, wait 0..30000. */
fun validateSteps(steps: List<JsonObject>): Int? {
    if (steps.isEmpty()) return R.string.v_empty
    if (steps.size > 100) return R.string.v_many
    for (s in steps) {
        when (s.str("type")) {
            "key" -> if (s.str("combo").isNullOrBlank()) return R.string.v_key
            "text" -> { val t = s.str("text"); if (t.isNullOrEmpty() || t.length > 500) return R.string.v_text }
            "wait" -> { val ms = s.int("ms"); if (ms == null || ms !in 0..30000) return R.string.v_wait }
            "click" -> {
                val x = s.int("x"); val y = s.int("y")
                if (x == null || y == null || x !in 0..100 || y !in 0..100) return R.string.v_click
                if (s.str("button") !in listOf("left", "right")) return R.string.v_click
            }
            "run" -> if (s.str("target").isNullOrBlank()) return R.string.v_target
            "url" -> { val u = s.str("url") ?: ""; if (!(u.startsWith("http://") || u.startsWith("https://"))) return R.string.v_url }
            else -> return R.string.v_empty
        }
    }
    return null
}

// ---------- шаблони ----------
private fun sKey(c: String) = jo("type" to "key", "combo" to c)
private fun sText(t: String) = jo("type" to "text", "text" to t)
private fun sWait(ms: Int) = jo("type" to "wait", "ms" to ms)
private fun sRun(t: String) = jo("type" to "run", "target" to t)
private fun sUrl(u: String) = jo("type" to "url", "url" to u)

val TEMPLATES: List<Macro> = listOf(
    Macro("", "CMD", "⌨️", "#4a2be0", listOf(sKey("Win+R"), sWait(300), sText("cmd"), sKey("Enter"))),
    Macro("", "PowerShell", "🔷", "#1d5fe0", listOf(sKey("Win+R"), sWait(300), sText("powershell"), sKey("Enter"))),
    Macro("", "Диспетчер завдань", "📊", "#12a150", listOf(sKey("Ctrl+Shift+Esc"))),
    Macro("", "Провідник", "📁", "#d9a400", listOf(sKey("Win+E"))),
    Macro("", "Налаштування", "⚙️", "#55555f", listOf(sKey("Win+I"))),
    Macro("", "Блокування", "🔒", "#d6252e", listOf(sRun("rundll32.exe user32.dll,LockWorkStation"))),
    Macro("", "Робочий стіл", "🖥️", "#6d4aff", listOf(sKey("Win+D"))),
    Macro("", "Блокнот", "📝", "#3d8bff", listOf(sRun("notepad"))),
    Macro("", "Скріншот", "📸", "#2fd37a", listOf(sKey("Win+Shift+S"))),
    Macro("", "YouTube", "▶️", "#d6252e", listOf(sUrl("https://www.youtube.com"))),
    Macro("", "Google", "🔍", "#1d5fe0", listOf(sUrl("https://www.google.com"))),
)

val MACRO_COLORS = listOf("#4a2be0", "#6d4aff", "#1d5fe0", "#3d8bff", "#12a150", "#2fd37a", "#d6252e", "#d9a400", "#55555f")

// ---------- ярлики ----------
object Shortcuts {
    const val ACTION = "app.muskup.remote.RUN_MACRO"

    private fun info(ctx: Context, m: Macro, device: String, sid: String): ShortcutInfoCompat {
        val intent = Intent(ctx, MainActivity::class.java).setAction(ACTION)
            .putExtra("device", device).putExtra("macro", m.id)
        val label = m.name.ifBlank { "MUSKUP" }
        return ShortcutInfoCompat.Builder(ctx, sid)
            .setShortLabel(label.take(12)).setLongLabel(label)
            .setIcon(IconCompat.createWithResource(ctx, R.mipmap.ic_launcher))
            .setIntent(intent).build()
    }

    /** Ярлик на головний екран. Запуск відбувається лише після підключення й підтвердження власником ПК. */
    fun pin(ctx: Context, m: Macro, device: String): Boolean {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) return false
        return ShortcutManagerCompat.requestPinShortcut(ctx, info(ctx, m, device, "pin_${m.id}_$device"), null)
    }

    /** Швидкі дії по довгому тапу на іконці застосунку. */
    fun updateDynamic(ctx: Context, macros: List<Macro>, device: String) {
        runCatching {
            val max = ShortcutManagerCompat.getMaxShortcutCountPerActivity(ctx).coerceAtMost(4)
            ShortcutManagerCompat.setDynamicShortcuts(ctx, macros.take(max).map { info(ctx, it, device, "dyn_${it.id}") })
        }
    }
}
