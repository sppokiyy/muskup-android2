package app.muskup.remote

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.security.SecureRandom

/** Лише для одноразового перенесення старих (незашифрованих) налаштувань. */
private val Context.legacyDs by preferencesDataStore("muskup")

/** Типізований ключ налаштування. */
class SKey<T>(val name: String)

data class Settings(
    val myId: String = "",
    val serverUrl: String = ServerConfig.signalUrl,
    val theme: String = "purple",
    val turnUrl: String = "",
    val turnUser: String = "",
    val turnPass: String = "",
    val keepOn: Boolean = true,
    val macrosJson: String = "",
    val lastPeer: String = "",
    val quality: String = "high",
    val sens: Float = 1.4f,
    val invertScroll: Boolean = false,
    val haptics: Boolean = true,
    val startTouch: Boolean = false,
    val autoHide: Boolean = true,
    val bgClose: Boolean = true,
    val contactsJson: String = "[]",
    val historyJson: String = "[]",
)

object K {
    val id = SKey<String>("id")
    val regSecret = SKey<String>("reg_secret")
    val theme = SKey<String>("theme")
    val keepOn = SKey<Boolean>("keep_on")
    val macros = SKey<String>("macros")
    val lastPeer = SKey<String>("last_peer")
    val quality = SKey<String>("quality")
    val sens = SKey<Float>("sens")
    val invertScroll = SKey<Boolean>("invert_scroll")
    val haptics = SKey<Boolean>("haptics")
    val startTouch = SKey<Boolean>("start_touch")
    val autoHide = SKey<Boolean>("auto_hide")
    val bgClose = SKey<Boolean>("bg_close")
    val contacts = SKey<String>("contacts")
    val history = SKey<String>("history")
}

/**
 * Захищене сховище: усі значення (налаштування, контакти, історія, команди, ID та секрет реєстрації)
 * шифруються AES-256-GCM ключем Android Keystore перед записом на диск.
 */
class Prefs(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("muskup_secure", Context.MODE_PRIVATE)
    private val lock = Any()
    private val cache = MutableStateFlow(load())

    private fun load(): Map<String, String> {
        val out = HashMap<String, String>()
        for ((k, v) in sp.all) {
            val s = v as? String ?: continue
            SecureBox.decrypt(s)?.let { out[k] = it }
        }
        return out
    }

    private fun str(p: Map<String, String>, k: SKey<String>, d: String = "") = p[k.name] ?: d
    private fun bool(p: Map<String, String>, k: SKey<Boolean>, d: Boolean) = p[k.name]?.toBooleanStrictOrNull() ?: d
    private fun flt(p: Map<String, String>, k: SKey<Float>, d: Float) = p[k.name]?.toFloatOrNull() ?: d

    val flow: Flow<Settings> = cache.map { p ->
        Settings(
            myId = str(p, K.id),
            serverUrl = ServerConfig.signalUrl,
            theme = str(p, K.theme, "purple"),
            turnUrl = ServerConfig.turnUrl,
            turnUser = ServerConfig.turnUser,
            turnPass = ServerConfig.turnPass,
            keepOn = bool(p, K.keepOn, true),
            macrosJson = str(p, K.macros),
            lastPeer = str(p, K.lastPeer),
            quality = str(p, K.quality, "high"),
            sens = flt(p, K.sens, 1.4f),
            invertScroll = bool(p, K.invertScroll, false),
            haptics = bool(p, K.haptics, true),
            startTouch = bool(p, K.startTouch, false),
            autoHide = bool(p, K.autoHide, true),
            bgClose = bool(p, K.bgClose, true),
            contactsJson = str(p, K.contacts, "[]"),
            historyJson = str(p, K.history, "[]"),
        )
    }

    private fun put(name: String, v: String) = synchronized(lock) {
        val m = HashMap(cache.value)
        m[name] = v
        cache.value = m
        try {
            sp.edit().putString(name, SecureBox.encrypt(v)).apply()
        } catch (e: Exception) {
            AppLog.log("store", "encrypt failed: ${e.javaClass.simpleName}")
        }
    }

    /** Секрет володіння ID (32 байти, hex). Сервер бачить лише його хеш. */
    fun regSecret(): String = cache.value[K.regSecret.name] ?: ""
    fun regTok(): String = V2.regTok(regSecret())

    private fun newId(): String = (100_000_000 + SecureRandom().nextInt(900_000_000)).toString()

    /** Новий випадковий ID (наприклад, після id-conflict). */
    fun regenerateId(): String { val n = newId(); put(K.id.name, n); return n }

    suspend fun ensureId(): String {
        // Секрет створюємо ПЕРШИМ: реєстрація з порожнім секретом закріпила б ID за хибним токеном
        if (regSecret().isEmpty()) put(K.regSecret.name, V2.hex(V2.random(32)))
        migrateLegacy()
        val cur = cache.value[K.id.name]
        if (!cur.isNullOrEmpty()) return cur
        return regenerateId()
    }

    private suspend fun migrateLegacy() {
        if (sp.getBoolean("legacy_done", false)) return
        try {
            val old = ctx.legacyDs.data.first().asMap()
            val skip = setOf("server", "turn_url", "turn_user", "turn_pass")
            old.forEach { (k, v) -> if (k.name !in skip && cache.value[k.name] == null) put(k.name, v.toString()) }
            ctx.legacyDs.edit { it.clear() }
        } catch (e: Exception) {
            AppLog.log("store", "legacy migrate: ${e.javaClass.simpleName}")
        }
        sp.edit().putBoolean("legacy_done", true).apply()
    }

    fun setString(k: SKey<String>, v: String) = put(k.name, v)
    fun setBool(k: SKey<Boolean>, v: Boolean) = put(k.name, v.toString())
    fun setFloat(k: SKey<Float>, v: Float) = put(k.name, v.toString())
    /** Атомарне оновлення рядка (читання-зміна-запис під блокуванням). */
    fun update(k: SKey<String>, f: (String) -> String) {
        synchronized(lock) { put(k.name, f(cache.value[k.name] ?: "")) }
    }
}
