package app.muskup.remote

import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/** Збережений пристрій. */
@Serializable
data class Contact(val id: String, val name: String, val added: Long = 0L)

/** Запис в історії: outcome = ok | rejected | bad-pass | busy | locked | offline | timeout | cancelled | failed. */
@Serializable
data class HistoryItem(val peer: String, val at: Long, val durSec: Int = 0, val outcome: String = "ok")

private val SJ = Json { ignoreUnknownKeys = true }

fun parseContacts(s: String?): List<Contact> =
    if (s.isNullOrBlank()) emptyList() else runCatching { SJ.decodeFromString<List<Contact>>(s) }.getOrDefault(emptyList())

fun encodeContacts(l: List<Contact>): String = SJ.encodeToString(l)

fun parseHistory(s: String?): List<HistoryItem> =
    if (s.isNullOrBlank()) emptyList() else runCatching { SJ.decodeFromString<List<HistoryItem>>(s) }.getOrDefault(emptyList())

fun encodeHistory(l: List<HistoryItem>): String = SJ.encodeToString(l)
