package app.muskup.remote

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.DesktopWindows
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------------------------------------------------------------- спільне

@Composable
private fun ScreenHeader(title: String, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = C.Text, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        trailing()
    }
}

@Composable
private fun RoundIconButton(icon: ImageVector, tint: Color, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun EmptyState(icon: ImageVector, title: String, text: String, action: (@Composable () -> Unit)? = null) {
    val a = LocalAccent.current
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier.size(84.dp).clip(CircleShape).background(a.start.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = a.end, modifier = Modifier.size(40.dp)) }
        Spacer(Modifier.height(18.dp))
        Text(title, color = C.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(text, color = C.Muted, fontSize = 14.sp, textAlign = TextAlign.Center)
        if (action != null) { Spacer(Modifier.height(20.dp)); action() }
    }
}

private fun dayStart(ms: Long): Long {
    val c = Calendar.getInstance()
    c.timeInMillis = ms
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

private fun fmtTime(ms: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ms))

private fun fmtDur(sec: Int): String =
    if (sec >= 3600) "%d:%02d:%02d".format(sec / 3600, (sec % 3600) / 60, sec % 60)
    else "%d:%02d".format(sec / 60, sec % 60)

private fun outcomeRes(o: String): Int = when (o) {
    "ok" -> R.string.out_ok
    "rejected" -> R.string.out_rejected
    "bad-pass" -> R.string.out_badpass
    "busy" -> R.string.out_busy
    "locked" -> R.string.out_locked
    "offline" -> R.string.out_offline
    "timeout" -> R.string.out_timeout
    "cancelled" -> R.string.out_cancelled
    else -> R.string.out_failed
}

// ---------------------------------------------------------------- історія

private sealed interface HRow {
    data class Day(val label: String) : HRow
    data class Entry(val item: HistoryItem) : HRow
}

@Composable
fun HistoryScreen(vm: SessionVm, onConnect: (String) -> Unit) {
    val ctx = LocalContext.current
    val a = LocalAccent.current
    val hist by vm.history.collectAsStateWithLifecycle()
    val contacts by vm.contacts.collectAsStateWithLifecycle()
    var confirmClear by remember { mutableStateOf(false) }
    var saveFor by remember { mutableStateOf<String?>(null) }

    val today = stringResource(R.string.today)
    val yesterday = stringResource(R.string.yesterday)
    val rows = remember(hist, today, yesterday) {
        val now = dayStart(System.currentTimeMillis())
        val fmt = SimpleDateFormat("d MMMM yyyy", Locale.getDefault())
        val out = ArrayList<HRow>()
        var lastDay = -1L
        hist.forEach { it0 ->
            val d = dayStart(it0.at)
            if (d != lastDay) {
                lastDay = d
                val diff = Math.round((now - d) / 86_400_000.0).toInt()
                out.add(HRow.Day(when (diff) { 0 -> today; 1 -> yesterday; else -> fmt.format(Date(d)) }))
            }
            out.add(HRow.Entry(it0))
        }
        out
    }
    val names = remember(contacts) { contacts.associate { it.id to it.name } }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        ScreenHeader(stringResource(R.string.nav_history)) {
            if (hist.isNotEmpty()) RoundIconButton(Icons.Filled.Close, C.Muted) { confirmClear = true }
        }
        if (hist.isEmpty()) {
            EmptyState(Icons.Outlined.History, stringResource(R.string.hist_empty_title), stringResource(R.string.hist_empty_text))
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(rows) { row ->
                    when (row) {
                        is HRow.Day -> Text(
                            row.label, color = C.Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(start = 4.dp, top = 8.dp)
                        )
                        is HRow.Entry -> {
                            val it0 = row.item
                            val ok = it0.outcome == "ok"
                            val name = names[it0.peer]
                            GlassCard(Modifier.fillMaxWidth().bounceClick { onConnect(it0.peer) }, RoundedCornerShape(20.dp)) {
                                Row(
                                    Modifier.padding(start = 14.dp, end = 6.dp, top = 12.dp, bottom = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    val badge = if (ok) C.Online else if (it0.outcome == "cancelled") C.Muted else C.Danger
                                    Box(
                                        Modifier.size(42.dp).clip(CircleShape).background(badge.copy(alpha = 0.16f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            if (ok) Icons.Filled.Check else if (it0.outcome == "cancelled") Icons.Filled.Close else Icons.Filled.Warning,
                                            null, tint = badge, modifier = Modifier.size(22.dp)
                                        )
                                    }
                                    Column(Modifier.weight(1f)) {
                                        Text(name ?: fmtId(it0.peer), color = C.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        if (name != null) Text(fmtId(it0.peer), color = C.Muted, fontSize = 12.sp)
                                        Text(
                                            buildString {
                                                append(stringResource(outcomeRes(it0.outcome)))
                                                append(" · "); append(fmtTime(it0.at))
                                                if (ok && it0.durSec > 0) { append(" · "); append(fmtDur(it0.durSec)) }
                                            },
                                            color = if (ok) C.Muted else badge, fontSize = 12.sp
                                        )
                                    }
                                    if (name == null) RoundIconButton(Icons.Outlined.PersonAdd, a.end) { saveFor = it0.peer }
                                    RoundIconButton(Icons.Filled.Refresh, C.Text) { onConnect(it0.peer) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text(stringResource(R.string.hist_clear_q)) },
        confirmButton = {
            TextButton(onClick = { confirmClear = false; vm.clearHistory() }) { Text(stringResource(R.string.hist_clear)) }
        },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text(stringResource(R.string.cancel)) } }
    )
    saveFor?.let { id ->
        ContactDialog(
            title = stringResource(R.string.c_new), initialName = "", initialId = id, idEditable = false,
            onDismiss = { saveFor = null },
            onSave = { n, i ->
                vm.saveContact(Contact(i, n, System.currentTimeMillis()))
                Toast.makeText(ctx, R.string.c_saved, Toast.LENGTH_SHORT).show()
                saveFor = null
            }
        )
    }
}

// ---------------------------------------------------------------- контакти

@Composable
fun ContactsScreen(vm: SessionVm, onConnect: (String) -> Unit) {
    val a = LocalAccent.current
    val contacts by vm.contacts.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Contact?>(null) }
    var deleting by remember { mutableStateOf<Contact?>(null) }
    val never = stringResource(R.string.c_never)

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        ScreenHeader(stringResource(R.string.nav_contacts)) {
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(a.brush).clickable { adding = true },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Add, null, tint = Color.White) }
        }
        if (contacts.isEmpty()) {
            EmptyState(Icons.Outlined.People, stringResource(R.string.c_empty_title), stringResource(R.string.c_empty_text)) {
                GradButton(stringResource(R.string.c_add), Modifier.fillMaxWidth()) { adding = true }
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(contacts, key = { it.id }) { c ->
                    var menu by remember { mutableStateOf(false) }
                    val last = history.firstOrNull { it.peer == c.id && it.outcome == "ok" }
                    GlassCard(Modifier.fillMaxWidth().bounceClick { onConnect(c.id) }, RoundedCornerShape(20.dp)) {
                        Row(
                            Modifier.padding(start = 14.dp, end = 6.dp, top = 12.dp, bottom = 12.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                Modifier.size(46.dp).clip(CircleShape).background(a.brush),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    c.name.trim().firstOrNull()?.uppercase() ?: "#",
                                    color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold
                                )
                            }
                            Column(Modifier.weight(1f)) {
                                Text(c.name, color = C.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(fmtId(c.id), color = C.Muted, fontSize = 13.sp)
                                Text(
                                    if (last == null) never
                                    else stringResource(R.string.c_last, SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(last.at))),
                                    color = C.Muted, fontSize = 11.sp
                                )
                            }
                            RoundIconButton(Icons.Outlined.DesktopWindows, a.end) { onConnect(c.id) }
                            Box {
                                RoundIconButton(Icons.Filled.MoreVert, C.Muted) { menu = true }
                                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                    DropdownMenuItem(text = { Text(stringResource(R.string.c_edit)) }, onClick = { menu = false; editing = c })
                                    DropdownMenuItem(text = { Text(stringResource(R.string.c_delete)) }, onClick = { menu = false; deleting = c })
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (adding) ContactDialog(
        title = stringResource(R.string.c_new), initialName = "", initialId = "", idEditable = true,
        onDismiss = { adding = false },
        onSave = { n, i -> vm.saveContact(Contact(i, n, System.currentTimeMillis())); adding = false }
    )
    editing?.let { c ->
        ContactDialog(
            title = stringResource(R.string.c_edit_title), initialName = c.name, initialId = c.id, idEditable = false,
            onDismiss = { editing = null },
            onSave = { n, i -> vm.saveContact(Contact(i, n, c.added)); editing = null }
        )
    }
    deleting?.let { c ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text(stringResource(R.string.c_delete_q, c.name)) },
            confirmButton = { TextButton(onClick = { vm.deleteContact(c.id); deleting = null }) { Text(stringResource(R.string.c_delete)) } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

@Composable
private fun ContactDialog(
    title: String, initialName: String, initialId: String, idEditable: Boolean,
    onDismiss: () -> Unit, onSave: (name: String, id: String) -> Unit
) {
    var name by remember { mutableStateOf(initialName) }
    var id by remember { mutableStateOf(initialId) }
    Dialog(onDismissRequest = onDismiss) {
        CardBox(Modifier.fillMaxWidth()) {
            Text(title, color = C.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                name, { v -> name = v.take(24) }, singleLine = true,
                label = { Text(stringResource(R.string.c_name)) },
                shape = RoundedCornerShape(16.dp), colors = fieldColors(), modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                id, { v -> if (idEditable) id = v.filter { it.isDigit() }.take(9) }, singleLine = true,
                readOnly = !idEditable,
                label = { Text(stringResource(R.string.field_id)) },
                visualTransformation = IdTransform(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                shape = RoundedCornerShape(16.dp), colors = fieldColors(), modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TextButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.cancel)) }
                GradButton(stringResource(R.string.c_save), Modifier.weight(1f), enabled = id.length == 9) {
                    onSave(name.trim().ifBlank { fmtId(id) }, id)
                }
            }
        }
    }
}
