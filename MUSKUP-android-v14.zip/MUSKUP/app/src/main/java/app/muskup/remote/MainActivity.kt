package app.muskup.remote

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.core.view.WindowCompat

class MainActivity : ComponentActivity() {
    private val vm: SessionVm by viewModels()
    private val handler = Handler(Looper.getMainLooper())
    private val bgTask = Runnable { vm.onBackgroundTimeout() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Повноекранний режим: система малює смуги прозорими поверх нашого темного фону (без білої смуги внизу)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        AppLog.init(applicationContext)
        // Бета: записуємо збої в лог, щоб тестувальник міг його надіслати
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching { AppLog.log("crash", e.stackTraceToString().take(3000)) }
            prev?.uncaughtException(t, e)
        }
        if (savedInstanceState == null) handle(intent)
        setContent { MuskupApp(vm) }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handle(intent) }

    /** Ярлик «Виконати команду»: відкриваємо вікно підключення, команда піде лише після згоди власника ПК. */
    private fun handle(i: Intent?) {
        if (i?.action == Shortcuts.ACTION) {
            vm.setPending(i.getStringExtra("device") ?: "", i.getStringExtra("macro") ?: return)
        }
    }

    override fun onStart() {
        super.onStart()
        vm.inBackground = false
        handler.removeCallbacks(bgTask)
        AppLog.log("act", "onStart state=${vm.state.value}")
    }

    /** Без фонової поведінки: згорнули більше ніж на 5 с — сеанс закривається. */
    override fun onStop() {
        super.onStop()
        val screenOn = (getSystemService(POWER_SERVICE) as? PowerManager)?.isInteractive ?: true
        AppLog.log("act", "onStop screenOn=$screenOn cfg=$isChangingConfigurations finishing=$isFinishing state=${vm.state.value}")
        if (!isChangingConfigurations) {
            vm.inBackground = true
            vm.bgReason = if (screenOn) "інше вікно чи застосунок зверху" else "екран телефону вимкнувся"
            handler.postDelayed(bgTask, 5000)
        }
    }
}
