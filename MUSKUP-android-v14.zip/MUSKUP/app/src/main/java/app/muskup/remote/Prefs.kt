package app.muskup.remote

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.ds by preferencesDataStore("muskup")

data class Settings(
    val myId: String = "",
    val serverUrl: String = ServerConfig.signalUrl,
    val theme: String = "purple",
    val turnUrl: String = "",
    val turnUser: String = "",
    val turnPass: String = "",
    val keepOn: Boolean = true,
    val macrosJson: String = "",
    val lastPeer: String = "",
    val quality: String = "high",
    val sens: Float = 1.4f,
    val invertScroll: Boolean = false,
    val haptics: Boolean = true,
    val startTouch: Boolean = false,
    val autoHide: Boolean = true,
    val bgClose: Boolean = true,
    val contactsJson: String = "[]",
    val historyJson: String = "[]",
)

object K {
    val id = stringPreferencesKey("id")
    val server = stringPreferencesKey("server")
    val theme = stringPreferencesKey("theme")
    val turnUrl = stringPreferencesKey("turn_url")
    val turnUser = stringPreferencesKey("turn_user")
    val turnPass = stringPreferencesKey("turn_pass")
    val keepOn = booleanPreferencesKey("keep_on")
    val macros = stringPreferencesKey("macros")
    val lastPeer = stringPreferencesKey("last_peer")
    val quality = stringPreferencesKey("quality")
    val sens = floatPreferencesKey("sens")
    val invertScroll = booleanPreferencesKey("invert_scroll")
    val haptics = booleanPreferencesKey("haptics")
    val startTouch = booleanPreferencesKey("start_touch")
    val autoHide = booleanPreferencesKey("auto_hide")
    val bgClose = booleanPreferencesKey("bg_close")
    val contacts = stringPreferencesKey("contacts")
    val history = stringPreferencesKey("history")
}

class Prefs(private val ctx: Context) {
    val flow: Flow<Settings> = ctx.ds.data.map { p ->
        Settings(
            myId = p[K.id] ?: "",
            serverUrl = ServerConfig.signalUrl,
            theme = p[K.theme] ?: "purple",
            turnUrl = ServerConfig.turnUrl,
            turnUser = ServerConfig.turnUser,
            turnPass = ServerConfig.turnPass,
            keepOn = p[K.keepOn] ?: true,
            macrosJson = p[K.macros] ?: "",
            lastPeer = p[K.lastPeer] ?: "",
            quality = p[K.quality] ?: "high",
            sens = p[K.sens] ?: 1.4f,
            invertScroll = p[K.invertScroll] ?: false,
            haptics = p[K.haptics] ?: true,
            startTouch = p[K.startTouch] ?: false,
            autoHide = p[K.autoHide] ?: true,
            bgClose = p[K.bgClose] ?: true,
            contactsJson = p[K.contacts] ?: "[]",
            historyJson = p[K.history] ?: "[]",
        )
    }

    suspend fun ensureId(): String {
        val cur = ctx.ds.data.first()[K.id]
        if (!cur.isNullOrEmpty()) return cur
        val n = (100_000_000..999_999_999).random().toString()
        ctx.ds.edit { it[K.id] = n }
        return n
    }

    suspend fun setString(k: Preferences.Key<String>, v: String) { ctx.ds.edit { it[k] = v } }
    /** Атомарне оновлення рядка (читання-зміна-запис в одній транзакції). */
    suspend fun update(k: Preferences.Key<String>, f: (String) -> String) { ctx.ds.edit { it[k] = f(it[k] ?: "") } }
    suspend fun setFloat(k: Preferences.Key<Float>, v: Float) { ctx.ds.edit { it[k] = v } }
    suspend fun setBool(k: Preferences.Key<Boolean>, v: Boolean) { ctx.ds.edit { it[k] = v } }
}
