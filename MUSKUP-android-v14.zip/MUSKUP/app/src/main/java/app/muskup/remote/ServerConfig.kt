package app.muskup.remote

/**
 * Вбудована конфігурація сервера. В інтерфейсі вона НЕ показується й не редагується.
 * Адреса зберігається не відкритим текстом (проста обфускація від випадкового перегляду в APK;
 * це не заміна серверному захисту — див. BETA.md).
 *
 * TURN: якщо потрібен, впишіть адресу й облікові дані нижче (turn:host:3478). Порожнє значення = без TURN.
 */
object ServerConfig {
    private val KEY = intArrayOf(0x5A, 0x13, 0x7C, 0x29, 0x41, 0x6E)
    private val SIGNAL = intArrayOf(45, 96, 15, 19, 110, 65, 55, 102, 15, 66, 52, 30, 119, 96, 21, 78, 47, 15, 54, 61, 15, 93, 53, 15, 40, 102, 23, 68, 32, 26, 44, 122, 5, 7, 54, 1, 40, 120, 25, 91, 50, 64, 62, 118, 10)

    val signalUrl: String by lazy {
        String(ByteArray(SIGNAL.size) { (SIGNAL[it] xor KEY[it % KEY.size]).toByte() })
    }
    /** Хост сервера — для прибирання з логів. */
    val host: String by lazy { signalUrl.substringAfter("://").substringBefore("/") }

    const val turnUrl = ""
    const val turnUser = ""
    const val turnPass = ""
}
