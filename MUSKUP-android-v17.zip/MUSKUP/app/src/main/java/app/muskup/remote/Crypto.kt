package app.muskup.remote

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Шифрування значень налаштувань ключем з Android Keystore (AES-256-GCM, ключ не покидає TEE/Keystore). */
object SecureBox {
    private const val ALIAS = "muskup_master_v1"
    private const val PREFIX = "e1:"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return g.generateKey()
    }

    fun encrypt(plain: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        return PREFIX + Base64.encodeToString(c.iv + ct, Base64.NO_WRAP)
    }

    /** null — якщо значення пошкоджене або ключ недоступний. */
    fun decrypt(s: String): String? {
        if (!s.startsWith(PREFIX)) return null
        return try {
            val raw = Base64.decode(s.substring(PREFIX.length), Base64.NO_WRAP)
            if (raw.size < 13 + 16) return null
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw, 0, 12))
            String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }
}

/** Утиліти реєстрації на сервері. */
object V2 {
    private val rnd = SecureRandom()
    fun random(n: Int): ByteArray = ByteArray(n).also { rnd.nextBytes(it) }
    fun hex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }
    fun sha256(b: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(b)

    /** Реєстраційний токен: hex(SHA-256("muskup-reg|" + hex_секрету)), 64 символи нижнього регістру. */
    fun regTok(secretHex: String): String = hex(sha256("muskup-reg|$secretHex".toByteArray(Charsets.UTF_8)))
}

/** Самоперевірка сховища при старті (результат пишеться в лог, без секретів). */
object CryptoSelfTest {
    fun run(): String {
        val ok = try { SecureBox.decrypt(SecureBox.encrypt("x")) == "x" } catch (e: Throwable) { false }
        return "keystore=${if (ok) "ok" else "FAIL"}"
    }
}
