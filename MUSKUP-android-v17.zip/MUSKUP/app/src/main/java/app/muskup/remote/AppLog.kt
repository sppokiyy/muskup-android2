package app.muskup.remote

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Лог у файл. НІКОЛИ не передавай сюди пароль ПК. */
object AppLog {
    private var file: File? = null
    private val fmt = SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US)

    fun init(ctx: Context) {
        val f = File(ctx.filesDir, "muskup.log")
        if (f.length() > 1_000_000) f.delete()
        file = f
    }

    @Synchronized
    fun log(tag: String, msg: String) {
        val line = "${fmt.format(Date())} $tag: ${clean(msg)}"
        Log.d("MUSKUP", line)
        runCatching { file?.appendText(line + "\n") }
    }

    /** Прибирає адресу сервера з тексту (логи можуть потрапити до тестувальників/підтримки). */
    private val idRe = Regex("""\b\d{3} ?\d{3} ?\d{3}\b""")
    private fun clean(s: String): String = runCatching { s.replace(ServerConfig.host, "•••").replace(idRe, "•••") }.getOrDefault(s)

    fun read(): String = runCatching { clean(file?.readText() ?: "") }.getOrDefault("")
}
