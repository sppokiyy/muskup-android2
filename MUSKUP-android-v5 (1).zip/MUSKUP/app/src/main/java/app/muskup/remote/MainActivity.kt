package app.muskup.remote

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels

class MainActivity : ComponentActivity() {
    private val vm: SessionVm by viewModels()
    private val handler = Handler(Looper.getMainLooper())
    private val bgTask = Runnable { vm.onBackgroundTimeout() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLog.init(applicationContext)
        if (savedInstanceState == null) handle(intent)
        setContent { MuskupApp(vm) }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handle(intent) }

    /** Ярлик «Виконати команду»: відкриваємо вікно підключення, команда піде лише після згоди власника ПК. */
    private fun handle(i: Intent?) {
        if (i?.action == Shortcuts.ACTION) {
            vm.setPending(i.getStringExtra("device") ?: "", i.getStringExtra("macro") ?: return)
        }
    }

    override fun onStart() { super.onStart(); handler.removeCallbacks(bgTask) }

    /** Без фонової поведінки: згорнули більше ніж на 5 с — сеанс закривається. */
    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) handler.postDelayed(bgTask, 5000)
    }
}
