package app.muskup.remote

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.SystemClock
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.outlined.Gamepad
import androidx.compose.material.icons.outlined.FlashOn
import androidx.compose.material.icons.outlined.Keyboard
import androidx.compose.material.icons.outlined.Mouse
import androidx.compose.material.icons.outlined.TouchApp
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.ZoomOutMap
import androidx.compose.material3.Icon
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import kotlinx.coroutines.delay
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEvent
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import org.webrtc.EglBase
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.abs
import kotlin.math.max

private const val SENT = "\u200B\u200B\u200B\u200B\u200B\u200B\u200B\u200B"

private fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }
    return null
}

@Composable
fun SessionScreen(vm: SessionVm) {
    val track by vm.video.collectAsStateWithLifecycle()
    val vsize by vm.videoSize.collectAsStateWithLifecycle()
    val perms by vm.perms.collectAsStateWithLifecycle()
    val stats by vm.stats.collectAsStateWithLifecycle()
    val ctlOn by vm.controlEnabled.collectAsStateWithLifecycle()
    val mods by vm.mods.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val haptic = LocalHapticFeedback.current
    val view = LocalView.current

    var touchMode by rememberSaveable { mutableStateOf(vm.settings.value?.startTouch ?: false) }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    var showKeys by remember { mutableStateOf(false) }
    var showKb by remember { mutableStateOf(false) }
    var showMacros by remember { mutableStateOf(false) }
    var barOpen by rememberSaveable { mutableStateOf(true) }
    val statsNow by rememberUpdatedState(stats)
    val pingHist = remember { mutableStateListOf<Int>() }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            pingHist.add(statsNow.pingMs.coerceAtLeast(0))
            while (pingHist.size > 40) pingHist.removeAt(0)
        }
    }
    LaunchedEffect(Unit) { delay(6000); if (vm.settings.value?.autoHide != false) barOpen = false }
    val canControl = perms.control && ctlOn

    // Повноекранний режим + утримання екрана
    DisposableEffect(Unit) {
        val w = view.context.findActivity()?.window
        val c = w?.let { WindowCompat.getInsetsController(it, view) }
        c?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { c?.show(WindowInsetsCompat.Type.systemBars()) }
    }
    val keepOn = settings?.keepOn ?: true
    DisposableEffect(keepOn) { view.keepScreenOn = keepOn; onDispose { view.keepScreenOn = false } }

    // Прямокутник відео в контейнері (збереження пропорцій)
    fun fit(): Rect {
        val vw = max(vsize.first, 1).toFloat(); val vh = max(vsize.second, 1).toFloat()
        val cw = max(box.width, 1).toFloat(); val ch = max(box.height, 1).toFloat()
        val k = minOf(cw / vw, ch / vh)
        val w = vw * k; val h = vh * k
        return Rect((cw - w) / 2f, (ch - h) / 2f, (cw + w) / 2f, (ch + h) / 2f)
    }

    Box(Modifier.fillMaxSize().background(Color.Black).onSizeChanged { box = it }) {
        VideoView(
            track, vm.engine.egl, vm::onVideoSize,
            Modifier.fillMaxSize().graphicsLayer(
                scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y
            )
        )

        // Шар жестів
        Box(
            Modifier.fillMaxSize().pointerInput(touchMode, canControl) {
                remoteGestures(
                    touchMode = touchMode, canControl = { canControl }, fit = { fit() },
                    getView = { Pair(scale, offset) },
                    setView = { s, o -> scale = s; offset = o },
                    vm = vm,
                    onLongPress = { if (settings?.haptics != false) haptic.performHapticFeedback(HapticFeedbackType.LongPress) },
                    onTap = { if (settings?.haptics != false) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) },
                    sens = { settings?.sens ?: 1.4f },
                    invert = { settings?.invertScroll ?: false }
                )
            }
        )

        // Верхня панель: сучасна «скляна» док-панель, що згортається
        val pingColor = when {
            stats.pingMs < 0 -> C.Muted
            stats.pingMs < 60 -> C.Online
            stats.pingMs < 150 -> C.Warn
            else -> C.Danger
        }
        val pingTxt = if (stats.pingMs >= 0) "${stats.pingMs} мс" else "— мс"
        val statTxt = "${stats.fps} fps · $pingTxt · ${"%.1f".format(stats.mbps)} Мбіт/с"
        val pill = RoundedCornerShape(50)
        if (!barOpen) {
            Row(
                Modifier.align(Alignment.TopCenter).displayCutoutPadding().padding(top = 8.dp)
                    .clip(pill).background(Glass).border(1.dp, C.Border, pill)
                    .clickable { barOpen = true }.padding(start = 14.dp, end = 10.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(pingColor))
                Spacer(Modifier.width(8.dp))
                Text(pingTxt, color = C.Text, fontSize = 12.sp)
                Spacer(Modifier.width(6.dp))
                Icon(Icons.Filled.KeyboardArrowDown, null, tint = C.Muted, modifier = Modifier.size(18.dp))
            }
        } else {
            val card = RoundedCornerShape(24.dp)
            Column(
                Modifier.align(Alignment.TopCenter).displayCutoutPadding().padding(8.dp)
                    .widthIn(max = 720.dp).fillMaxWidth()
                    .clip(card).background(Glass).border(1.dp, C.Border, card).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(9.dp).clip(CircleShape).background(pingColor))
                    Spacer(Modifier.width(8.dp))
                    Text(statTxt, color = C.Muted, fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f))
                    Sparkline(pingHist, pingColor, Modifier.width(56.dp).height(22.dp))
                    Spacer(Modifier.width(6.dp))
                    Box(
                        Modifier.size(36.dp).clip(CircleShape).clickable { barOpen = false },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Filled.KeyboardArrowUp, null, tint = C.Muted) }
                    Spacer(Modifier.width(4.dp))
                    Row(
                        Modifier.clip(pill).background(C.Danger).clickable { vm.cancel() }
                            .padding(start = 10.dp, end = 14.dp, top = 8.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Close, null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.end_session), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (perms.control) {
                        DockButton(stringResource(if (ctlOn) R.string.mode_control else R.string.mode_view), ctlOn,
                            icon = if (ctlOn) Icons.Outlined.Gamepad else Icons.Outlined.Visibility) {
                            vm.controlEnabled.value = !ctlOn
                        }
                    } else {
                        DockButton(stringResource(R.string.mode_view), false, icon = Icons.Filled.Lock, tint = C.Warn) {}
                    }
                    DockButton(stringResource(if (touchMode) R.string.mode_touch else R.string.mode_touchpad), true,
                        icon = if (touchMode) Icons.Outlined.TouchApp else Icons.Outlined.Mouse) { touchMode = !touchMode }
                    DockButton(stringResource(R.string.kb_label), showKb, icon = Icons.Outlined.Keyboard) { showKb = !showKb }
                    DockButton("Fn", showKeys, glyph = "Fn") { showKeys = !showKeys }
                    DockButton(stringResource(R.string.kb_macros), showMacros, icon = Icons.Outlined.FlashOn) { showMacros = !showMacros }
                    if (scale > 1.01f) DockButton("100%", false, icon = Icons.Outlined.ZoomOutMap) { scale = 1f; offset = Offset.Zero }
                }
            }
        }

        MacroPanelHost(vm, showMacros, Modifier.align(Alignment.CenterEnd))

        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding()) {
            if (showKeys) {
                val topShape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
                Box(Modifier.fillMaxWidth().clip(topShape).background(Glass).border(1.dp, C.Border, topShape).padding(10.dp)) {
                    KeysPanel(vm, mods)
                }
            }
            if (showKb) KeyboardBar(vm) { showKb = false }
        }
    }
}

private val Glass = Color(0xEB0F0F17)

/** Міні-графік пінгу за останні ~40 секунд. */
@Composable
private fun Sparkline(values: List<Int>, color: Color, modifier: Modifier) {
    Canvas(modifier) {
        if (values.size < 2) return@Canvas
        val mx = max(values.maxOrNull() ?: 0, 20).toFloat()
        val step = size.width / (values.size - 1)
        val path = Path()
        values.forEachIndexed { i, v ->
            val x = i * step
            val y = size.height - (v / mx) * size.height
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, color, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
private fun DockButton(
    label: String, selected: Boolean, icon: ImageVector? = null, glyph: String? = null,
    tint: Color? = null, onClick: () -> Unit
) {
    val a = LocalAccent.current
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier.width(72.dp).clip(shape)
            .background(if (selected) a.start.copy(alpha = 0.30f) else Color.White.copy(alpha = 0.05f))
            .border(1.dp, if (selected) a.end.copy(alpha = 0.55f) else Color.Transparent, shape)
            .clickable(onClick = onClick).padding(vertical = 9.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) {
            if (icon != null) Icon(icon, null, tint = tint ?: if (selected) Color.White else C.Text, modifier = Modifier.size(22.dp))
            else Text(glyph ?: "", color = if (selected) Color.White else C.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }
        Text(label, color = if (selected) C.Text else C.Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun Chip(text: String, selected: Boolean, color: Color? = null, onClick: () -> Unit) {
    val a = LocalAccent.current
    val bg = if (selected) (color ?: a.start) else C.Card
    Box(
        Modifier.clip(RoundedCornerShape(12.dp)).background(bg).clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = if (selected) Color.White else C.Text, fontSize = 12.sp, maxLines = 1) }
}

@Composable
fun KeysPanel(vm: SessionVm, mods: Map<String, Int>) {
    val keys = listOf(
        "Esc" to "Esc", "Tab" to "Tab", "Ctrl" to "Ctrl", "Alt" to "Alt", "Win" to "Win", "Shift" to "Shift",
        "←" to "Left", "↑" to "Up", "↓" to "Down", "→" to "Right", "Del" to "Delete",
        "Enter" to "Enter", "Bksp" to "Backspace", "Home" to "Home", "End" to "End", "PgUp" to "PageUp", "PgDn" to "PageDown",
    ) + (1..12).map { "F$it" to "F$it" }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        keys.forEach { (label, name) ->
            val m = mods[name] ?: 0
            Chip(label + if (m == 2) " 🔒" else "", selected = m > 0) {
                if (name in MODS) vm.toggleMod(name) else vm.pressKey(name)
            }
        }
    }
}

/** Ховає службові нульової ширини символи на початку поля (потрібні, щоб ловити Backspace у порожньому полі). */
private object HideSentinel : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val n = minOf(SENT.length, text.length)
        return TransformedText(AnnotatedString(text.text.substring(n)), object : OffsetMapping {
            override fun originalToTransformed(offset: Int) = (offset - n).coerceAtLeast(0)
            override fun transformedToOriginal(offset: Int) = offset + n
        })
    }
}

/**
 * Видима панель вводу над системною клавіатурою. Усе, що ви набираєте, одразу летить на ПК
 * (різниця між старим і новим текстом → Backspace + набір). Коректно працює з автозаміною та кирилицею.
 */
@Composable
private fun KeyboardBar(vm: SessionVm, onClose: () -> Unit) {
    val a = LocalAccent.current
    val focus = remember { FocusRequester() }
    val kb = LocalSoftwareKeyboardController.current
    var tf by remember { mutableStateOf(TextFieldValue(SENT, TextRange(SENT.length))) }
    val reset = { tf = TextFieldValue(SENT, TextRange(SENT.length)) }

    LaunchedEffect(Unit) {
        delay(80)
        runCatching { focus.requestFocus() }
        kb?.show()
    }
    DisposableEffect(Unit) { onDispose { kb?.hide() } }

    val shape = RoundedCornerShape(24.dp)
    Row(
        Modifier.fillMaxWidth().padding(8.dp).clip(shape).background(Glass).border(1.dp, C.Border, shape)
            .padding(start = 14.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Outlined.Keyboard, null, tint = a.end, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f).height(44.dp), contentAlignment = Alignment.CenterStart) {
            if (tf.text.length <= SENT.length) Text(stringResource(R.string.kb_hint), color = C.Muted, fontSize = 14.sp, maxLines = 1)
            BasicTextField(
                value = tf,
                onValueChange = { nv ->
                    val old = tf.text; val new = nv.text
                    var p = 0
                    val lim = minOf(old.length, new.length)
                    while (p < lim && old[p] == new[p]) p++
                    val removed = old.length - p
                    val added = new.substring(p)
                    if (removed > 0) repeat(removed) { vm.pressKey("Backspace") }
                    if (added.isNotEmpty()) vm.typed(added)
                    val rest = new.dropWhile { it == '\u200B' }
                    val keep = if (rest.length > 80 || rest.lastOrNull() == ' ') "" else rest
                    val txt = SENT + keep
                    tf = if (txt == new) nv else TextFieldValue(txt, TextRange(txt.length))
                },
                modifier = Modifier.fillMaxWidth().focusRequester(focus),
                singleLine = true,
                textStyle = TextStyle(color = C.Text, fontSize = 16.sp),
                cursorBrush = SolidColor(a.end),
                visualTransformation = HideSentinel,
                keyboardOptions = KeyboardOptions(autoCorrect = false, keyboardType = KeyboardType.Text, imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { vm.pressKey("Enter"); reset() }),
            )
        }
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(a.start.copy(alpha = 0.30f))
                .clickable { vm.pressKey("Enter"); reset() },
            contentAlignment = Alignment.Center
        ) { Text("↵", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold) }
        Spacer(Modifier.width(6.dp))
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.06f)).clickable(onClick = onClose),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Filled.Close, null, tint = C.Muted, modifier = Modifier.size(20.dp)) }
    }
}

@Composable
fun VideoView(track: VideoTrack?, egl: EglBase, onSize: (Int, Int) -> Unit, modifier: Modifier) {
    class Holder { var t: VideoTrack? = null }
    val holder = remember { Holder() }
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            SurfaceViewRenderer(ctx).apply {
                init(egl.eglBaseContext, object : RendererCommon.RendererEvents {
                    override fun onFirstFrameRendered() {}
                    override fun onFrameResolutionChanged(w: Int, h: Int, rotation: Int) {
                        if (rotation % 180 == 0) onSize(w, h) else onSize(h, w)
                    }
                })
                setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT)
                setEnableHardwareScaler(true)
            }
        },
        update = { r ->
            if (holder.t !== track) {
                holder.t?.let { runCatching { it.removeSink(r) } }
                track?.addSink(r)
                holder.t = track
            }
        },
        onRelease = { r ->
            holder.t?.let { runCatching { it.removeSink(r) } }
            holder.t = null
            r.release()
        }
    )
}

/**
 * Жести. Координати йдуть нормалізовано по КАДРУ відео (не по екрану).
 * Тачпад: рух = відносний курсор; тап = ЛКМ; тап 2 пальцями = ПКМ; 2 пальці = колесо (або щіпок = масштаб);
 * довге утримання + рух = перетягування. Дотик: курсор у точці дотику; рух = перетягування; 2 пальці = масштаб/переміщення.
 */
private suspend fun PointerInputScope.remoteGestures(
    touchMode: Boolean,
    canControl: () -> Boolean,
    fit: () -> Rect,
    getView: () -> Pair<Float, Offset>,
    setView: (Float, Offset) -> Unit,
    vm: SessionVm,
    onLongPress: () -> Unit,
    onTap: () -> Unit,
    sens: () -> Float,
    invert: () -> Boolean,
) {
    val slop = viewConfiguration.touchSlop
    val longMs = 450L
    val scrollStep = 24f

    fun center() = Offset(size.width / 2f, size.height / 2f)
    fun norm(p: Offset): Offset {
        val (s, t) = getView()
        val q = center() + (p - center() - t) / s
        val r = fit()
        return Offset(((q.x - r.left) / r.width).coerceIn(0f, 1f), ((q.y - r.top) / r.height).coerceIn(0f, 1f))
    }
    fun clampT(t: Offset, s: Float): Offset {
        val mx = (s - 1f) * size.width / 2f; val my = (s - 1f) * size.height / 2f
        return Offset(t.x.coerceIn(-mx, mx), t.y.coerceIn(-my, my))
    }

    awaitEachGesture {
        val first = awaitFirstDown(requireUnconsumed = false)
        val t0 = SystemClock.uptimeMillis()
        var maxPtr = 1
        var moved = 0f
        var armed = true
        var dragging = false
        var pressedTouch = false
        var mode = 0 // 0 — не визначено, 1 — масштаб/переміщення, 2 — прокрутка
        var twoStarted = false
        var startSpan = 0f; var startCentroid = Offset.Zero
        var prevSpan = 0f; var prevCentroid = Offset.Zero
        var acc = Offset.Zero
        var lastPos = first.position
        val startPos = first.position
        first.consume()

        while (true) {
            val ev: PointerEvent? = if (armed) {
                val left = longMs - (SystemClock.uptimeMillis() - t0)
                withTimeoutOrNull(max(left, 1L)) { awaitPointerEvent() }
            } else awaitPointerEvent()

            if (ev == null) { // таймаут довгого утримання
                armed = false
                if (maxPtr == 1 && moved < slop && canControl()) {
                    dragging = true
                    if (touchMode) vm.moveTo(norm(lastPos).x, norm(lastPos).y, true)
                    vm.button("l", true)
                    onLongPress()
                }
                continue
            }

            val pressed = ev.changes.filter { it.pressed }
            if (pressed.isEmpty()) {
                val dur = SystemClock.uptimeMillis() - t0
                if (canControl()) {
                    when {
                        dragging || pressedTouch -> vm.button("l", false)
                        maxPtr == 1 && moved < slop && dur < longMs -> {
                            if (touchMode) { val n = norm(lastPos); vm.moveTo(n.x, n.y, true) }
                            vm.click("l"); onTap()
                        }
                        maxPtr == 2 && mode == 0 && dur < 500 -> vm.click("r")
                    }
                    vm.flushMove()
                }
                ev.changes.forEach { it.consume() }
                break
            }

            maxPtr = max(maxPtr, pressed.size)

            if (pressed.size == 1 && maxPtr == 1) {
                val c = pressed[0]
                val d = c.position - c.previousPosition
                moved += d.getDistance()
                if (moved >= slop) armed = false
                if (canControl()) {
                    if (touchMode) {
                        if (!dragging && !pressedTouch && moved >= slop) {
                            val n = norm(startPos); vm.moveTo(n.x, n.y, true)
                            vm.button("l", true); pressedTouch = true
                        }
                        if (dragging || pressedTouch) { val n = norm(c.position); vm.moveTo(n.x, n.y) }
                    } else if (moved >= slop || dragging) {
                        val r = fit(); val s = getView().first
                        val k = sens()
                        vm.moveBy(d.x * k / (r.width * s), d.y * k / (r.height * s))
                    }
                }
                lastPos = c.position
            } else if (pressed.size >= 2) {
                armed = false
                val a = pressed[0]; val b = pressed[1]
                val cNow = (a.position + b.position) / 2f
                val sNow = (a.position - b.position).getDistance()
                if (!twoStarted) {
                    twoStarted = true
                    if (pressedTouch) { vm.button("l", false); pressedTouch = false }
                    startSpan = sNow; startCentroid = cNow; prevSpan = sNow; prevCentroid = cNow
                } else {
                    if (mode == 0) {
                        val spanD = abs(sNow - startSpan)
                        val panD = (cNow - startCentroid).getDistance()
                        if (spanD > slop && spanD > panD) mode = 1
                        else if (panD > slop) mode = if (touchMode || !canControl()) 1 else 2
                    }
                    val delta = cNow - prevCentroid
                    if (mode == 1) {
                        val (s, t) = getView()
                        val zoom = if (prevSpan > 0f) sNow / prevSpan else 1f
                        val s2 = (s * zoom).coerceIn(1f, 6f)
                        val t2 = cNow - center() - (prevCentroid - center() - t) * (s2 / s)
                        setView(s2, clampT(t2, s2))
                    } else if (mode == 2) {
                        acc += delta
                        val sy = (acc.y / scrollStep).toInt()
                        val sx = (acc.x / scrollStep).toInt()
                        if (sy != 0 || sx != 0) {
                            val sg = if (invert()) -1 else 1
                            vm.wheel(-sx * 120 * sg, sy * 120 * sg)
                            acc = Offset(acc.x - sx * scrollStep, acc.y - sy * scrollStep)
                        }
                    }
                    prevCentroid = cNow; prevSpan = sNow
                }
            }
            ev.changes.forEach { it.consume() }
        }
    }
}
