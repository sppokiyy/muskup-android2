package app.muskup.remote

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.animation.AnimatedContent
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import androidx.compose.animation.core.Easing
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.graphics.drawscope.clipPath
import kotlin.math.sin
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import kotlinx.coroutines.launch
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.coerceIn
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay

private val CardBorderBrush = Brush.verticalGradient(listOf(Color(0x30FFFFFF), Color(0x0DFFFFFF)))
private val CardFillBrush = Brush.verticalGradient(listOf(Color(0xFF14141D), Color(0xFF0C0C13)))

/** Картка зі скляним градієнтом і світлою верхньою кромкою. */
@Composable
fun GlassCard(modifier: Modifier, shape: Shape, content: @Composable BoxScope.() -> Unit) {
    Box(modifier.clip(shape).background(CardFillBrush).border(1.dp, CardBorderBrush, shape), propagateMinConstraints = true, content = content)
}

/** Натискання з легким «пружинним» стисканням. */
@Composable
fun Modifier.bounceClick(onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.97f else 1f, tween(90), label = "press")
    return this.graphicsLayer { scaleX = sc; scaleY = sc }
        .clickable(interactionSource = src, indication = null, onClick = onClick)
}

private fun logoPath(k: Float): Path = Path().apply {
    val pts = listOf(
        6f to 124f, 61f to 6f, 137f to 57f, 213f to 6f, 268f to 124f,
        222f to 109f, 195f to 69f, 137f to 105f, 79f to 69f, 52f to 109f
    )
    pts.forEachIndexed { i, p -> if (i == 0) moveTo(p.first * k, p.second * k) else lineTo(p.first * k, p.second * k) }
    close()
}

private var splashShown = false
private const val SPLASH_MS = 2100

private class SplashDot(val x: Float, val y: Float, val r: Float, val phase: Float)

/**
 * Стартова заставка: зорепад частинок, контур M «малюється» світлою кометою, заливається градієнтом,
 * по лого пробігає відблиск, розходиться кільце, літери бренду з'являються по черзі. Тап — пропустити.
 */
@Composable
fun SplashScreen(onSkip: () -> Unit) {
    val c1 = Color(0xFF4A2BE0); val c2 = Color(0xFF6D4AFF); val c3 = Color(0xFFA48DFF)
    val t = remember { Animatable(0f) }
    LaunchedEffect(Unit) { t.animateTo(1f, tween(SPLASH_MS, easing = LinearEasing)) }
    val dots = remember {
        val r = java.util.Random(7)
        List(40) { SplashDot(r.nextFloat(), r.nextFloat(), 0.8f + r.nextFloat() * 1.6f, r.nextFloat() * 6.28f) }
    }
    fun seg(a: Float, b: Float, e: Easing = FastOutSlowInEasing): Float = e.transform(((t.value - a) / (b - a)).coerceIn(0f, 1f))

    Box(
        Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) { detectTapGestures { onSkip() } },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val appear = seg(0f, 0.18f)
            dots.forEach { d ->
                val tw = 0.5f + 0.5f * sin(t.value * 9f + d.phase)
                drawCircle(
                    Color.White, radius = d.r.dp.toPx(),
                    center = Offset(d.x * size.width, (d.y - 0.05f * t.value) * size.height),
                    alpha = appear * (0.12f + 0.38f * tw)
                )
            }
            val g = seg(0.28f, 0.6f)
            val c = Offset(size.width / 2f, size.height * 0.46f)
            val rad = size.minDimension * 0.62f
            drawCircle(Brush.radialGradient(listOf(c1.copy(alpha = 0.5f * g), Color.Transparent), center = c, radius = rad), radius = rad, center = c)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Canvas(
                Modifier.width(190.dp).aspectRatio(274f / 130f)
                    .graphicsLayer { val s = 0.9f + 0.1f * seg(0f, 0.5f); scaleX = s; scaleY = s }
            ) {
                val k = size.width / 274f
                val path = logoPath(k)
                val brush = Brush.linearGradient(listOf(c2, c1), start = Offset.Zero, end = Offset(size.width, size.height))
                val d = seg(0.02f, 0.40f)
                val f = seg(0.30f, 0.55f)
                val rb = seg(0.50f, 0.88f)
                if (rb > 0f && rb < 1f) {
                    drawCircle(c3, radius = size.width * (0.25f + 0.95f * rb), center = center, alpha = 0.55f * (1f - rb),
                        style = Stroke(width = 2.dp.toPx()))
                }
                drawPath(path, brush, alpha = f)
                val pm = PathMeasure()
                pm.setPath(path, true)
                val len = pm.length
                val partial = Path()
                pm.getSegment(0f, len * d, partial, true)
                drawPath(partial, c3, alpha = 1f - 0.7f * f,
                    style = Stroke(width = 3.5f * k, cap = StrokeCap.Round, join = StrokeJoin.Round))
                if (d > 0.01f && d < 0.999f) {
                    val pos = pm.getPosition(len * d)
                    drawCircle(c3, radius = 13.dp.toPx(), center = pos, alpha = 0.35f)
                    drawCircle(Color.White, radius = 5.dp.toPx(), center = pos)
                }
                val sh = seg(0.50f, 0.78f)
                if (sh > 0f && sh < 1f) {
                    clipPath(path) {
                        val x0 = -size.width * 0.4f + sh * size.width * 1.8f
                        drawRect(Brush.linearGradient(
                            listOf(Color.Transparent, Color.White.copy(alpha = 0.45f), Color.Transparent),
                            start = Offset(x0, 0f), end = Offset(x0 + size.width * 0.35f, size.height * 0.5f)))
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                "MUSKUP".forEachIndexed { i, ch ->
                    Text(
                        ch.toString(), color = Color(0xFF9A9AAE), fontSize = 20.sp, fontWeight = FontWeight.Medium,
                        modifier = Modifier.graphicsLayer {
                            val p = seg(0.45f + i * 0.045f, 0.62f + i * 0.045f)
                            alpha = p; translationY = (1f - p) * 16.dp.toPx()
                        }
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            Text(
                stringResource(R.string.tagline2), color = Color(0xFF6E6E80), fontSize = 12.sp,
                modifier = Modifier.graphicsLayer { alpha = seg(0.72f, 0.92f) }
            )
        }
    }
}

/** Підлаштовує розмір усього інтерфейсу під екран конкретного телефону (еталон — 392 dp) і не дає системному масштабу шрифту ламати верстку. */
@Composable
fun AdaptiveUi(content: @Composable () -> Unit) {
    val cfg = LocalConfiguration.current
    val base = LocalDensity.current
    val sw = cfg.smallestScreenWidthDp
    val k = if (sw >= 600) 1f else (sw / 392f).coerceIn(0.82f, 1.12f)
    val d = Density(density = base.density * k, fontScale = base.fontScale.coerceIn(0.85f, 1.15f))
    CompositionLocalProvider(LocalDensity provides d, content = content)
}

@Composable
fun MuskupApp(vm: SessionVm) {
    AdaptiveUi {
        var splash by remember { mutableStateOf(!splashShown) }
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            MuskupAppInner(vm)
            AnimatedVisibility(visible = splash, enter = EnterTransition.None, exit = fadeOut(tween(380))) {
                SplashScreen(onSkip = { splash = false; splashShown = true })
            }
        }
        LaunchedEffect(Unit) { if (splash) { delay(SPLASH_MS + 150L); splash = false; splashShown = true } }
    }
}

@Composable
private fun MuskupAppInner(vm: SessionVm) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val st = s
    MuskupTheme(AppTheme.from(st?.theme ?: "purple")) {
        val state by vm.state.collectAsStateWithLifecycle()
        val notice by vm.notice.collectAsStateWithLifecycle()
        val secure by vm.secure.collectAsStateWithLifecycle()
        // Поки йде запит/підключення, екран не гасне — інакше застосунок «згортається» і сеанс закривається
        val busyView = androidx.compose.ui.platform.LocalView.current
        val busy = state !is SessionState.Idle
        DisposableEffect(busy) { busyView.keepScreenOn = busy; onDispose { } }
        Box(Modifier.fillMaxSize().background(C.Bg)) {
            if (st != null) {
                if (state is SessionState.Active) SessionScreen(vm) else MainScaffold(vm, st)
            }
            if (state is SessionState.Requesting || state is SessionState.Connecting) {
                WaitDialog(state is SessionState.Requesting, secure) { vm.cancel() }
            }
            NoticeBanner(notice) { vm.clearNotice() }
        }
    }
}

// ---------- спільні елементи ----------
@Composable
fun CardBox(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(modifier, color = C.Card, shape = RoundedCornerShape(24.dp), border = BorderStroke(1.dp, C.Border)) {
        Column(Modifier.padding(18.dp), content = content)
    }
}

@Composable
fun GradButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    val a = LocalAccent.current
    val bg = if (enabled) a.brush else Brush.horizontalGradient(listOf(C.Border, C.Border))
    Box(
        modifier.height(52.dp).clip(RoundedCornerShape(16.dp)).background(bg)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.SemiBold) }
}

/** Логотип MUSKUP (літера M) — вектор з макета; колір береться з активної теми. */
@Composable
fun LogoMark(width: Dp) {
    val a = LocalAccent.current
    Canvas(Modifier.width(width).aspectRatio(274f / 130f)) {
        val k = size.width / 274f
        val pts = listOf(
            6f to 124f, 61f to 6f, 137f to 57f, 213f to 6f, 268f to 124f,
            222f to 109f, 195f to 69f, 137f to 105f, 79f to 69f, 52f to 109f
        )
        val path = Path().apply {
            pts.forEachIndexed { i, p -> if (i == 0) moveTo(p.first * k, p.second * k) else lineTo(p.first * k, p.second * k) }
            close()
        }
        val brush = Brush.linearGradient(listOf(a.end, a.start), start = Offset.Zero, end = Offset(size.width, size.height))
        drawPath(path, brush)
        drawPath(path, brush, style = Stroke(width = 8f * k, join = StrokeJoin.Round))
    }
}

/** «M U S K U P» з великим розрідженням літер. */
@Composable
fun Wordmark(fontSize: Float) {
    Text("MUSKUP", color = C.Muted, fontSize = fontSize.sp, fontWeight = FontWeight.Medium, letterSpacing = (fontSize * 0.6f).sp)
}

/** Слабке діагональне світіння на фоні, як на макеті. */
fun Modifier.glow(color: Color): Modifier = drawBehind {
    val w = size.width; val h = size.height
    val top = Path().apply { moveTo(w * 0.5f, 0f); lineTo(w, 0f); lineTo(w, h * 0.3f); close() }
    drawPath(top, Brush.linearGradient(listOf(color.copy(alpha = 0.10f), Color.Transparent), start = Offset(w, 0f), end = Offset(w * 0.55f, h * 0.3f)))
    val bot = Path().apply { moveTo(0f, h * 0.72f); lineTo(w * 0.42f, h); lineTo(0f, h); close() }
    drawPath(bot, Brush.linearGradient(listOf(color.copy(alpha = 0.16f), Color.Transparent), start = Offset(0f, h), end = Offset(w * 0.25f, h * 0.78f)))
}

@Composable
fun NoticeBanner(n: Notice?, onDismiss: () -> Unit) {
    if (n == null) return
    LaunchedEffect(n.stamp) { delay(4500); onDismiss() }
    val color = when (n.kind) { NoticeKind.Success -> C.Online; NoticeKind.Warning -> C.Warn; NoticeKind.Error -> C.Danger }
    Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.TopCenter) {
        Surface(
            color = C.Card, shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, color),
            modifier = Modifier.clickable { onDismiss() }
        ) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(color))
                Text(n.text, color = C.Text, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun WaitDialog(requesting: Boolean, secure: Boolean, onCancel: () -> Unit) {
    Dialog(onDismissRequest = {}) {
        CardBox {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                CircularProgressIndicator(Modifier.size(28.dp), color = LocalAccent.current.end, strokeWidth = 3.dp)
                Text(
                    stringResource(
                        if (requesting && !secure) R.string.waiting_secure
                        else if (requesting) R.string.waiting_confirm else R.string.connecting_media
                    ), color = C.Text
                )
            }
            Spacer(Modifier.height(16.dp))
            TextButton(onClick = onCancel, modifier = Modifier.align(Alignment.End)) { Text(stringResource(R.string.cancel)) }
        }
    }
}

@Composable
fun fieldColors(): TextFieldColors {
    val a = LocalAccent.current
    return OutlinedTextFieldDefaults.colors(
        focusedBorderColor = a.end, unfocusedBorderColor = C.Border,
        focusedContainerColor = C.Card, unfocusedContainerColor = C.Card,
        focusedTextColor = C.Text, unfocusedTextColor = C.Text,
        cursorColor = a.end, focusedLabelColor = a.end, unfocusedLabelColor = C.Muted,
    )
}

// ---------- каркас: бічна панель (широкий екран) / нижня навігація ----------
class NavItem(val icon: ImageVector, val label: Int)

val navItems = listOf(
    NavItem(Icons.Outlined.DesktopWindows, R.string.nav_desktop),
    NavItem(Icons.Outlined.People, R.string.nav_contacts),
    NavItem(Icons.Outlined.FlashOn, R.string.nav_macros),
    NavItem(Icons.Outlined.History, R.string.nav_history),
    NavItem(Icons.Outlined.Settings, R.string.nav_settings),
    NavItem(Icons.Outlined.Info, R.string.nav_about),
)

@Composable
fun MainScaffold(vm: SessionVm, s: Settings) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var presetPeer by remember { mutableStateOf<String?>(null) }
    val a = LocalAccent.current
    val macros by vm.macros.collectAsStateWithLifecycle()
    val pending by vm.pending.collectAsStateWithLifecycle()
    val online by vm.signaling.registered.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    LaunchedEffect(macros, s.lastPeer) { Shortcuts.updateDynamic(ctx, macros, s.lastPeer) }
    LaunchedEffect(pending) { if (pending != null) tab = 0 }

    BoxWithConstraints(Modifier.fillMaxSize().background(C.Bg).glow(a.start)) {
        val wide = maxWidth >= 720.dp
        val imeOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = { if (!wide && !imeOpen) BottomBar(tab) { tab = it } }
        ) { pad ->
            Row(Modifier.padding(pad).consumeWindowInsets(pad).imePadding().fillMaxSize()) {
                if (wide) {
                    SideBar(tab, online) { tab = it }
                    Box(Modifier.width(1.dp).fillMaxHeight().background(C.Border))
                }
                Box(Modifier.weight(1f).fillMaxHeight()) {
                    AnimatedContent(
                        targetState = tab,
                        transitionSpec = {
                            val dir = if (targetState > initialState) 1 else -1
                            (fadeIn(tween(200, delayMillis = 50)) +
                                slideInHorizontally(tween(260, easing = FastOutSlowInEasing)) { dir * it / 12 }) togetherWith
                                (fadeOut(tween(100)) +
                                    slideOutHorizontally(tween(260, easing = FastOutSlowInEasing)) { -dir * it / 12 })
                        },
                        label = "tabs"
                    ) { t ->
                        when (t) {
                            0 -> HomeScreen(vm, s, presetPeer, { presetPeer = null }, onHistory = { tab = 3 }, onSettings = { tab = 4 })
                            1 -> ContactsScreen(vm) { id -> presetPeer = id; tab = 0 }
                            3 -> HistoryScreen(vm) { id -> presetPeer = id; tab = 0 }
                            2 -> MacrosScreen(vm, s)
                            4 -> SettingsScreen(vm, s)
                            5 -> AboutScreen()
                            else -> ComingSoon(navItems[t].label)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BottomBar(tab: Int, onTab: (Int) -> Unit) {
    val a = LocalAccent.current
    val shape = RoundedCornerShape(28.dp)
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 14.dp, vertical = 10.dp)) {
        Row(
            Modifier.fillMaxWidth().clip(shape).background(Color(0xF2101018)).border(1.dp, CardBorderBrush, shape).padding(6.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            navItems.take(5).forEachIndexed { i, item ->
                val sel = tab == i
                val bg by animateColorAsState(if (sel) a.start.copy(alpha = 0.55f) else Color.Transparent, tween(220), label = "bbBg")
                val fg by animateColorAsState(if (sel) Color.White else C.Muted, tween(220), label = "bbFg")
                Row(
                    Modifier.animateContentSize(tween(220)).clip(RoundedCornerShape(22.dp)).background(bg)
                        .clickable { onTab(i) }
                        .padding(horizontal = if (sel) 14.dp else 10.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(item.icon, null, tint = fg, modifier = Modifier.size(24.dp))
                    if (sel) {
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(item.label), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
fun SideBar(tab: Int, online: Boolean, onTab: (Int) -> Unit) {
    val a = LocalAccent.current
    Column(Modifier.width(232.dp).fillMaxHeight().background(C.Panel).padding(vertical = 20.dp)) {
        Column(Modifier.fillMaxWidth().padding(bottom = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            LogoMark(72.dp)
            Spacer(Modifier.height(8.dp))
            Wordmark(12f)
        }
        navItems.forEachIndexed { i, item ->
            val sel = tab == i
            val bgc by animateColorAsState(if (sel) Color.White.copy(alpha = 0.06f) else Color.Transparent, tween(220), label = "navBg")
            val barc by animateColorAsState(if (sel) a.end else Color.Transparent, tween(220), label = "navBar")
            val fgc by animateColorAsState(if (sel) Color.White else C.Muted, tween(220), label = "navFg")
            val txc by animateColorAsState(if (sel) C.Text else C.Muted, tween(220), label = "navTx")
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(bgc)
                    .clickable { onTab(i) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.width(3.dp).height(50.dp).background(barc))
                Spacer(Modifier.width(16.dp))
                Icon(item.icon, null, tint = fgc, modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(14.dp))
                Text(
                    stringResource(item.label), color = txc, fontSize = 14.sp,
                    fontWeight = if (sel) FontWeight.Medium else FontWeight.Normal, maxLines = 1
                )
            }
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.padding(horizontal = 24.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(if (online) C.Online else C.Muted))
            Spacer(Modifier.width(10.dp))
            Text(stringResource(if (online) R.string.online else R.string.offline), color = C.Text, fontSize = 14.sp)
        }
    }
}

@Composable
fun ComingSoon(label: Int) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(stringResource(label), color = C.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text(stringResource(R.string.soon), color = C.Muted)
        }
    }
}

@Composable
fun BetaBadge() {
    val a = LocalAccent.current
    Text(
        "BETA", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(a.start.copy(alpha = 0.7f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    )
}

@Composable
fun AboutScreen() {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        LogoMark(180.dp)
        Spacer(Modifier.height(10.dp))
        Wordmark(20f)
        Spacer(Modifier.height(20.dp))
        Text(stringResource(R.string.tagline_a), color = C.Text, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
        Text(stringResource(R.string.tagline_b), color = C.Muted, fontSize = 26.sp)
        Spacer(Modifier.height(12.dp))
        Text(stringResource(R.string.tagline2), color = C.Muted, fontSize = 14.sp)
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${stringResource(R.string.version)}: ${BuildConfig.VERSION_NAME}", color = C.Muted, fontSize = 12.sp)
            Spacer(Modifier.width(8.dp))
            BetaBadge()
        }
        Spacer(Modifier.height(10.dp))
        Text(stringResource(R.string.about_beta_text), color = C.Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
    }
}

// ---------- головний екран ----------
@Composable
fun HomeScreen(
    vm: SessionVm, s: Settings, presetPeer: String?, onPresetConsumed: () -> Unit,
    onHistory: () -> Unit, onSettings: () -> Unit
) {
    val ctx = LocalContext.current
    val online by vm.signaling.registered.collectAsStateWithLifecycle()
    var showConnect by remember { mutableStateOf(false) }
    var dialogPeer by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(presetPeer) {
        if (presetPeer != null) { dialogPeer = presetPeer; showConnect = true; onPresetConsumed() }
    }
    var showSec by remember { mutableStateOf(false) }
    val pending by vm.pending.collectAsStateWithLifecycle()
    val macros by vm.macros.collectAsStateWithLifecycle()
    LaunchedEffect(pending) {
        if (pending != null) {
            if (s.serverUrl.isBlank()) Toast.makeText(ctx, R.string.need_server, Toast.LENGTH_LONG).show() else showConnect = true
        }
    }

    val first = remember { !introDone }
    LaunchedEffect(Unit) { introDone = true }
    val connect: () -> Unit = {
        if (s.serverUrl.isBlank()) Toast.makeText(ctx, R.string.need_server, Toast.LENGTH_LONG).show()
        else showConnect = true
    }
    val copyId: () -> Unit = {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("id", s.myId))
        Toast.makeText(ctx, ctx.getString(R.string.id_copied), Toast.LENGTH_SHORT).show()
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val availW = maxWidth
        val wide = availW >= 560.dp
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = if (wide) 32.dp else 20.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            if (wide) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(28.dp), verticalAlignment = Alignment.CenterVertically) {
                    Hero(Modifier.weight(1f).appear(0, first), big = true, logoW = (availW * 0.3f).coerceIn(160.dp, 260.dp), online = online)
                    DesktopCard(Modifier.weight(1f).appear(90, first), online, showStatus = false, onConnect = connect, onSwap = onHistory)
                }
            } else {
                Hero(Modifier.fillMaxWidth().appear(0, first), big = false, logoW = (availW * 0.42f).coerceIn(96.dp, 180.dp), online = online)
                DesktopCard(Modifier.fillMaxWidth().appear(90, first), online, showStatus = true, onConnect = connect, onSwap = onHistory)
            }

            val idT = stringResource(R.string.tile_id)
            val idD = stringResource(R.string.tile_id_desc)
            val idA = stringResource(R.string.act_view)
            val seT = stringResource(R.string.tile_security)
            val seD = stringResource(R.string.tile_sec_desc)
            val seA = stringResource(R.string.act_details)
            val stT = stringResource(R.string.nav_settings)
            val stD = stringResource(R.string.tile_set_desc)
            val stA = stringResource(R.string.act_open)
            if (wide) {
                Row(Modifier.fillMaxWidth().height(IntrinsicSize.Max), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    InfoTile(Icons.Outlined.People, idT, idD, idA, Modifier.weight(1f).fillMaxHeight().appear(170, first), copyId)
                    InfoTile(Icons.Outlined.VerifiedUser, seT, seD, seA, Modifier.weight(1f).fillMaxHeight().appear(220, first)) { showSec = true }
                    InfoTile(Icons.Outlined.Settings, stT, stD, stA, Modifier.weight(1f).fillMaxHeight().appear(270, first), onSettings)
                }
            } else {
                InfoTile(Icons.Outlined.People, idT, idD, idA, Modifier.fillMaxWidth().appear(170, first), copyId)
                InfoTile(Icons.Outlined.VerifiedUser, seT, seD, seA, Modifier.fillMaxWidth().appear(220, first)) { showSec = true }
                InfoTile(Icons.Outlined.Settings, stT, stD, stA, Modifier.fillMaxWidth().appear(270, first), onSettings)
            }
            val idPill = RoundedCornerShape(50)
            Row(
                Modifier.align(Alignment.CenterHorizontally).bounceClick(copyId).clip(idPill)
                    .background(Color.White.copy(alpha = 0.05f)).border(1.dp, C.Border, idPill)
                    .padding(start = 18.dp, end = 12.dp, top = 10.dp, bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(stringResource(R.string.your_id), color = C.Muted, fontSize = 13.sp)
                Spacer(Modifier.width(10.dp))
                Text(fmtId(s.myId), color = C.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
                Spacer(Modifier.width(10.dp))
                Icon(Icons.Outlined.ContentCopy, null, tint = LocalAccent.current.end, modifier = Modifier.size(18.dp))
            }
        }
    }

    if (showConnect) ConnectDialog(
        initialId = dialogPeer ?: pending?.deviceId?.ifBlank { null } ?: "",
        hint = pending?.let { p -> macros.firstOrNull { it.id == p.macroId }?.let { stringResource(R.string.pending_hint, it.name) } },
        onDismiss = { showConnect = false; dialogPeer = null; vm.pending.value = null },
        onConnect = { id, pass -> showConnect = false; dialogPeer = null; vm.connect(id, pass) }
    )
    if (showSec) AlertDialog(
        onDismissRequest = { showSec = false },
        confirmButton = { TextButton(onClick = { showSec = false }) { Text(stringResource(R.string.ok)) } },
        title = { Text(stringResource(R.string.tile_security)) },
        text = { Text(stringResource(R.string.security_text)) },
        containerColor = C.Card, titleContentColor = C.Text, textContentColor = C.Muted
    )
}

fun fmtId(id: String) = id.chunked(3).joinToString(" ")

private var introDone = false

/** М'яка поява: прозорість + невеликий зсув знизу. Грає лише при першому показі головної. */
@Composable
fun Modifier.appear(delayMs: Int, enabled: Boolean): Modifier {
    if (!enabled) return this
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(delayMs.toLong()); shown = true }
    val p by animateFloatAsState(if (shown) 1f else 0f, tween(380, easing = FastOutSlowInEasing), label = "appear")
    return this.graphicsLayer { alpha = p; translationY = (1f - p) * 28.dp.toPx() }
}

/** Лого з «пульсом»: коли ПК/сервер онлайн, за лого розходиться м'яке сяйво. */
@Composable
fun PulseLogo(width: Dp, online: Boolean) {
    val a = LocalAccent.current
    Box(contentAlignment = Alignment.Center) {
        if (online) {
            val tr = rememberInfiniteTransition(label = "pulse")
            val p by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Restart), label = "p")
            Box(
                Modifier.size(width * 0.95f)
                    .graphicsLayer { scaleX = 0.7f + 0.7f * p; scaleY = 0.7f + 0.7f * p; alpha = (1f - p) * 0.55f }
                    .background(Brush.radialGradient(listOf(a.start.copy(alpha = 0.65f), Color.Transparent)), CircleShape)
            )
        }
        LogoMark(width)
    }
}

@Composable
fun Hero(modifier: Modifier, big: Boolean, logoW: Dp, online: Boolean) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        PulseLogo(logoW, online)
        Spacer(Modifier.height(if (big) 12.dp else 8.dp))
        Wordmark(if (big) 26f else 16f)
        Spacer(Modifier.height(if (big) 36.dp else 20.dp))
        Text(stringResource(R.string.tagline_a), color = C.Text, fontSize = if (big) 34.sp else 26.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Text(stringResource(R.string.tagline_b), color = C.Muted, fontSize = if (big) 34.sp else 26.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Text(stringResource(R.string.tagline2), color = C.Muted, fontSize = 14.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun DesktopCard(modifier: Modifier, online: Boolean, showStatus: Boolean, onConnect: () -> Unit, onSwap: () -> Unit) {
    val a = LocalAccent.current
    GlassCard(modifier, RoundedCornerShape(28.dp)) {
        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(22.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                Icon(Icons.Outlined.DesktopWindows, null, tint = Color(0xFFC4C4D2), modifier = Modifier.size(64.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(stringResource(R.string.nav_desktop), color = C.Text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                    Text(stringResource(R.string.desktop_desc), color = C.Muted, fontSize = 14.sp)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.weight(1f).height(56.dp).bounceClick(onConnect).clip(RoundedCornerShape(18.dp)).background(a.brush),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Outlined.DesktopWindows, null, tint = Color.White, modifier = Modifier.size(22.dp))
                        Text(stringResource(R.string.connect), color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    }
                }
                Box(
                    Modifier.size(56.dp).clip(RoundedCornerShape(18.dp)).background(Color(0xFF16161F)).clickable(onClick = onSwap),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Outlined.SwapHoriz, null, tint = C.Text) }
            }
            if (showStatus) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(9.dp).clip(CircleShape).background(if (online) C.Online else C.Muted))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(if (online) R.string.online else R.string.offline), color = if (online) C.Online else C.Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun InfoTile(icon: ImageVector, title: String, desc: String, action: String, modifier: Modifier, onClick: () -> Unit) {
    val a = LocalAccent.current
    GlassCard(modifier.bounceClick(onClick), RoundedCornerShape(24.dp)) {
        Row(Modifier.padding(20.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Icon(icon, null, tint = Color(0xFFC4C4D2), modifier = Modifier.size(38.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(title, color = C.Text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text(desc, color = C.Muted, fontSize = 14.sp)
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(action, color = a.end, fontSize = 14.sp)
                    Icon(Icons.Filled.ArrowForward, null, tint = a.end, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

/** Поле ID у вигляді 123 456 789 */
class IdTransform : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val t = text.text
        val out = buildString { t.forEachIndexed { i, c -> if (i == 3 || i == 6) append(' '); append(c) } }
        val map = object : OffsetMapping {
            override fun originalToTransformed(offset: Int) = offset + (if (offset > 6) 2 else if (offset > 3) 1 else 0)
            override fun transformedToOriginal(offset: Int) =
                (offset - (if (offset > 7) 2 else if (offset > 3) 1 else 0)).coerceIn(0, t.length)
        }
        return TransformedText(AnnotatedString(out), map)
    }
}

@Composable
fun ConnectDialog(initialId: String, hint: String?, onDismiss: () -> Unit, onConnect: (String, String) -> Unit) {
    var id by remember { mutableStateOf(initialId) }
    var pass by remember { mutableStateOf("") }
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            securePolicy = if (ServerConfig.blockScreenshots) SecureFlagPolicy.SecureOn else SecureFlagPolicy.Inherit
        )
    ) {
        CardBox(Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.dlg_connect_title), color = C.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            if (hint != null) { Spacer(Modifier.height(6.dp)); Text(hint, color = C.Muted, fontSize = 12.sp) }
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                id, { v -> id = v.filter { it.isDigit() }.take(9) }, singleLine = true,
                label = { Text(stringResource(R.string.field_id)) },
                visualTransformation = IdTransform(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                shape = RoundedCornerShape(16.dp), colors = fieldColors(), modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                pass, { v -> pass = V2.normPass(v).take(12) }, singleLine = true,
                label = { Text(stringResource(R.string.field_pass)) },
                placeholder = { Text("ABCD-EFGH-JKMN", color = C.Muted) },
                visualTransformation = PassTransform(),
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Characters, autoCorrect = false, keyboardType = KeyboardType.Ascii
                ),
                shape = RoundedCornerShape(16.dp), colors = fieldColors(), modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(16.dp))
            GradButton(stringResource(R.string.connect), Modifier.fillMaxWidth(), enabled = id.length == 9 && pass.length == 12) {
                onConnect(id, pass)
            }
        }
    }
}

/** Пароль виду ABCD-EFGH-JKMN: дефіси лише для показу, у значенні — 12 символів A-Z0-9. */
class PassTransform : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val t = text.text
        val out = buildString { t.forEachIndexed { i, c -> if (i == 4 || i == 8) append('-'); append(c) } }
        val map = object : OffsetMapping {
            override fun originalToTransformed(offset: Int) = offset + (if (offset > 8) 2 else if (offset > 4) 1 else 0)
            override fun transformedToOriginal(offset: Int) =
                (offset - (if (offset > 9) 2 else if (offset > 4) 1 else 0)).coerceIn(0, t.length)
        }
        return TransformedText(AnnotatedString(out), map)
    }
}

// ---------- налаштування ----------
@Composable
private fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Text(title, color = C.Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 6.dp, bottom = 8.dp))
        GlassCard(Modifier.fillMaxWidth(), RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) { content() }
        }
    }
}

@Composable
private fun SettingsDivider() { Box(Modifier.fillMaxWidth().height(1.dp).background(C.Border)) }

@Composable
private fun SwitchRow(title: String, desc: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = C.Text, fontSize = 15.sp)
            if (desc != null) Text(desc, color = C.Muted, fontSize = 12.sp)
        }
        Switch(checked, onChange, colors = SwitchDefaults.colors(checkedTrackColor = LocalAccent.current.end))
    }
}

@Composable
private fun SegRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val a = LocalAccent.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.05f)).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        options.forEachIndexed { i, t ->
            val sel = i == selected
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(11.dp))
                    .background(if (sel) a.start.copy(alpha = 0.55f) else Color.Transparent)
                    .clickable { onSelect(i) }.padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(t, color = if (sel) Color.White else C.Muted, fontSize = 13.sp, maxLines = 1,
                    fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal)
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: SessionVm, s: Settings) {
    val ctx = LocalContext.current
    val a = LocalAccent.current
    var sens by remember(s.sens) { mutableFloatStateOf(s.sens) }
    val qualityKeys = listOf("eco", "balanced", "high", "max")
    val qualityNames = listOf(R.string.q_eco, R.string.q_bal, R.string.q_high, R.string.q_max).map { stringResource(it) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Text(stringResource(R.string.nav_settings), color = C.Text, fontSize = 26.sp, fontWeight = FontWeight.Bold)

        SettingsCard(stringResource(R.string.set_sec_look)) {
            Text(stringResource(R.string.set_theme), color = C.Text, fontSize = 15.sp, modifier = Modifier.padding(top = 12.dp, bottom = 10.dp))
            Row(Modifier.padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AppTheme.entries.forEach { t ->
                    Box(
                        Modifier.size(38.dp).clip(CircleShape).background(t.brush).clickable { vm.saveString(K.theme, t.key) },
                        contentAlignment = Alignment.Center
                    ) { if (t.key == s.theme) Icon(Icons.Filled.Check, null, tint = Color.White) }
                }
            }
        }

        SettingsCard(stringResource(R.string.set_sec_session)) {
            Text(stringResource(R.string.set_quality), color = C.Text, fontSize = 15.sp, modifier = Modifier.padding(top = 12.dp, bottom = 10.dp))
            SegRow(qualityNames, qualityKeys.indexOf(s.quality).coerceAtLeast(0)) { vm.saveString(K.quality, qualityKeys[it]) }
            Text(stringResource(R.string.set_quality_hint), color = C.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp, bottom = 12.dp))
            SettingsDivider()

            Row(Modifier.padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.set_sens), color = C.Text, fontSize = 15.sp, modifier = Modifier.weight(1f))
                Text("%.1f×".format(sens), color = a.end, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
            Slider(
                value = sens, onValueChange = { sens = it }, valueRange = 0.6f..3f,
                onValueChangeFinished = { vm.saveFloat(K.sens, sens) },
                colors = SliderDefaults.colors(thumbColor = a.end, activeTrackColor = a.end, inactiveTrackColor = C.Border)
            )
            SettingsDivider()

            Text(stringResource(R.string.set_startmode), color = C.Text, fontSize = 15.sp, modifier = Modifier.padding(top = 12.dp, bottom = 10.dp))
            Box(Modifier.padding(bottom = 12.dp)) {
                SegRow(
                    listOf(stringResource(R.string.mode_touchpad), stringResource(R.string.mode_touch)),
                    if (s.startTouch) 1 else 0
                ) { vm.saveBool(K.startTouch, it == 1) }
            }
            SettingsDivider()
            SwitchRow(stringResource(R.string.set_invert), stringResource(R.string.set_invert_desc), s.invertScroll) { vm.saveBool(K.invertScroll, it) }
            SettingsDivider()
            SwitchRow(stringResource(R.string.set_haptics), stringResource(R.string.set_haptics_desc), s.haptics) { vm.saveBool(K.haptics, it) }
            SettingsDivider()
            SwitchRow(stringResource(R.string.set_autohide), stringResource(R.string.set_autohide_desc), s.autoHide) { vm.saveBool(K.autoHide, it) }
            SettingsDivider()
            SwitchRow(stringResource(R.string.set_keepon), null, s.keepOn) { vm.saveBool(K.keepOn, it) }
            SettingsDivider()
            SwitchRow(stringResource(R.string.set_bgclose), stringResource(R.string.set_bgclose_desc), s.bgClose) { vm.saveBool(K.bgClose, it) }
        }

        SettingsCard(stringResource(R.string.set_sec_support)) {
            Column(Modifier.padding(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("log", AppLog.read().takeLast(200_000)))
                    Toast.makeText(ctx, R.string.log_copied, Toast.LENGTH_SHORT).show()
                }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.set_log)) }
                Text(stringResource(R.string.set_log_hint), color = C.Muted, fontSize = 12.sp)
            }
        }

        Row(Modifier.align(Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "${stringResource(R.string.your_id)}: ${fmtId(s.myId)}   ·   ${stringResource(R.string.version)}: ${BuildConfig.VERSION_NAME}",
                color = C.Muted, fontSize = 12.sp, textAlign = TextAlign.Center
            )
            Spacer(Modifier.width(8.dp))
            BetaBadge()
        }
    }
}
