package app.muskup.remote

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.longOrNull
import java.math.BigInteger
import java.security.AlgorithmParameters
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyFactory
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.interfaces.ECPublicKey
import java.security.spec.ECGenParameterSpec
import java.security.spec.ECParameterSpec
import java.security.spec.ECPoint
import java.security.spec.ECPublicKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Шифрування значень налаштувань ключем з Android Keystore (AES-256-GCM, ключ не покидає TEE/Keystore). */
object SecureBox {
    private const val ALIAS = "muskup_master_v1"
    private const val PREFIX = "e1:"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return g.generateKey()
    }

    fun encrypt(plain: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        return PREFIX + Base64.encodeToString(c.iv + ct, Base64.NO_WRAP)
    }

    /** null — якщо значення пошкоджене або ключ недоступний. */
    fun decrypt(s: String): String? {
        if (!s.startsWith(PREFIX)) return null
        return try {
            val raw = Base64.decode(s.substring(PREFIX.length), Base64.NO_WRAP)
            if (raw.size < 13 + 16) return null
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw, 0, 12))
            String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }
}

/** Примітиви протоколу безпеки v2 (див. SECURITY.md). */
object V2 {
    private val rnd = SecureRandom()
    private val curve: ECParameterSpec by lazy {
        AlgorithmParameters.getInstance("EC").apply { init(ECGenParameterSpec("secp256r1")) }
            .getParameterSpec(ECParameterSpec::class.java)
    }

    fun random(n: Int): ByteArray = ByteArray(n).also { rnd.nextBytes(it) }
    fun b64(b: ByteArray): String = Base64.encodeToString(b, Base64.NO_WRAP)
    fun unb64(s: String?): ByteArray? = try {
        if (s == null) null else Base64.decode(s, Base64.DEFAULT)
    } catch (e: IllegalArgumentException) { null }

    fun hex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }
    fun sha256(b: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(b)

    /** Реєстраційний токен: hex(SHA-256("muskup-reg|" + hex_секрету)). */
    fun regTok(secretHex: String): String = hex(sha256("muskup-reg|$secretHex".toByteArray(Charsets.UTF_8)))

    /** Пароль: верхній регістр, лише A-Z0-9. */
    fun normPass(s: String): String = s.uppercase().filter { it in 'A'..'Z' || it in '0'..'9' }

    fun genKeyPair(): KeyPair =
        KeyPairGenerator.getInstance("EC").apply { initialize(ECGenParameterSpec("secp256r1")) }.generateKeyPair()

    private fun fixed32(x: BigInteger): ByteArray {
        val b = x.toByteArray()
        return when {
            b.size == 32 -> b
            b.size > 32 -> b.copyOfRange(b.size - 32, b.size)
            else -> ByteArray(32 - b.size) + b
        }
    }

    /** Публічний ключ: 65 байт, 0x04 ‖ X ‖ Y. */
    fun rawPublic(pub: ECPublicKey): ByteArray =
        byteArrayOf(4) + fixed32(pub.w.affineX) + fixed32(pub.w.affineY)

    fun parsePublic(raw: ByteArray): PublicKey {
        require(raw.size == 65 && raw[0] == 4.toByte()) { "bad public key" }
        val x = BigInteger(1, raw.copyOfRange(1, 33))
        val y = BigInteger(1, raw.copyOfRange(33, 65))
        return KeyFactory.getInstance("EC").generatePublic(ECPublicKeySpec(ECPoint(x, y), curve))
    }

    fun ecdh(priv: PrivateKey, pub: PublicKey): ByteArray {
        val ka = KeyAgreement.getInstance("ECDH")
        ka.init(priv)
        ka.doPhase(pub, true)
        return ka.generateSecret()
    }

    fun pbkdf2(pass: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pass.toCharArray(), salt, 200_000, 256)
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally { spec.clearPassword() }
    }

    fun hmac(key: ByteArray, data: ByteArray): ByteArray {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(key, "HmacSHA256"))
        return m.doFinal(data)
    }

    /** HKDF-SHA256, вихід 32 байти (один блок). */
    fun hkdf(ikm: ByteArray, salt: ByteArray, info: String): ByteArray = hkdf(ikm, salt, info.toByteArray(Charsets.UTF_8))

    fun hkdf(ikm: ByteArray, salt: ByteArray, info: ByteArray): ByteArray {
        val prk = hmac(salt, ikm)
        return hmac(prk, info + byteArrayOf(1))
    }

    /** lp(x) = 2 байти довжини (big-endian) ‖ x. */
    fun lp(x: ByteArray): ByteArray = byteArrayOf((x.size shr 8).toByte(), x.size.toByte()) + x
}

/**
 * Один сеанс рукостискання (клієнт = Android). Пароль лишається тільки в пам'яті й
 * зникає після виведення ключа P. Ключі сеансу, пароль і SDP у лог не потрапляють.
 */
class HandshakeV2(val myId: String, val hostId: String, password: String) {
    private val kp = V2.genKeyPair()
    val pubRaw: ByteArray = V2.rawPublic(kp.public as ECPublicKey)
    val nC: ByteArray = V2.random(16)

    private var pw: String = V2.normPass(password)
    @Volatile private var p: ByteArray? = null
    @Volatile private var t: ByteArray? = null
    @Volatile private var kC2H: ByteArray? = null
    @Volatile private var kH2C: ByteArray? = null
    private var sendSeq = 0L
    private var recvSeq = -1L

    @Volatile var hasChallenge = false
    @Volatile var authOk = false
    val ready: Boolean get() = kC2H != null

    /** PBKDF2 (200 000 ітерацій) — важка операція, викликати з фонового потоку. */
    @Synchronized
    fun derivePassKey() {
        if (p != null) return
        p = V2.pbkdf2(pw, "muskup-v2|$hostId".toByteArray(Charsets.UTF_8))
        pw = ""
    }

    /** Кроки 3–5. Повертає доказ клієнта HMAC(P, "C"‖T). */
    fun onChallenge(hPubRaw: ByteArray, nH: ByteArray): ByteArray {
        derivePassKey()
        val pk = p!!
        val z = V2.ecdh(kp.private, V2.parsePublic(hPubRaw))
        val tt = V2.lp(myId.toByteArray(Charsets.UTF_8)) + V2.lp(hostId.toByteArray(Charsets.UTF_8)) +
            V2.lp(pubRaw) + V2.lp(hPubRaw) + V2.lp(nC) + V2.lp(nH)
        val ikm = z + pk
        t = tt
        kC2H = V2.hkdf(ikm, tt, "muskup-v2 c2h")
        kH2C = V2.hkdf(ikm, tt, "muskup-v2 h2c")
        z.fill(0); ikm.fill(0)
        return V2.hmac(pk, byteArrayOf('C'.code.toByte()) + tt)
    }

    /** Крок 6: перевірка доказу хоста HMAC(P, "H"‖T) (порівняння за сталий час). */
    fun verifyHostProof(proof: ByteArray): Boolean {
        val pk = p ?: return false
        val tt = t ?: return false
        val expected = V2.hmac(pk, byteArrayOf('H'.code.toByte()) + tt)
        return MessageDigest.isEqual(expected, proof)
    }

    /** Крок 8 (відправка): d = base64(iv ‖ AES-GCM(c2h, aad, {"s":seq,"o":payload})). */
    @Synchronized
    fun seal(type: String, payload: JsonObject): String {
        val key = kC2H ?: error("no session key")
        val iv = V2.random(12)
        val aad = "$type|$myId|$hostId".toByteArray(Charsets.UTF_8)
        val plain = jo("s" to sendSeq++, "o" to payload).toString().toByteArray(Charsets.UTF_8)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        c.updateAAD(aad)
        return V2.b64(iv + c.doFinal(plain))
    }

    /** Крок 8 (прийом): розшифрувати пакет від хоста; невалідні й повторні (seq ≤ попереднього) відкидаються → null. */
    @Synchronized
    fun open(type: String, d: String): JsonObject? {
        val key = kH2C ?: return null
        val raw = V2.unb64(d) ?: return null
        if (raw.size < 12 + 16) return null
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, raw, 0, 12))
            c.updateAAD("$type|$hostId|$myId".toByteArray(Charsets.UTF_8))
            val obj = parseObj(String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)) ?: return null
            val s = (obj["s"] as? JsonPrimitive)?.longOrNull ?: return null
            if (s <= recvSeq) return null
            recvSeq = s
            obj["o"] as? JsonObject
        } catch (e: Exception) {
            null
        }
    }

    fun wipe() {
        p?.fill(0); kC2H?.fill(0); kH2C?.fill(0); t?.fill(0)
        p = null; kC2H = null; kH2C = null; t = null
        pw = ""
        authOk = false
    }
}

/** Самоперевірка криптографії при старті: результат пишеться в лог (без жодних секретів). */
object CryptoSelfTest {
    fun run(): String {
        val sb = StringBuilder()
        fun step(name: String, f: () -> Boolean) {
            val t0 = System.nanoTime()
            val ok = try { f() } catch (e: Throwable) { sb.append("[$name: ${e.javaClass.simpleName}] "); false }
            sb.append("$name=${if (ok) "ok" else "FAIL"}(${(System.nanoTime() - t0) / 1_000_000}ms) ")
        }
        step("ecdh") {
            val a = V2.genKeyPair(); val b = V2.genKeyPair()
            val za = V2.ecdh(a.private, V2.parsePublic(V2.rawPublic(b.public as ECPublicKey)))
            val zb = V2.ecdh(b.private, V2.parsePublic(V2.rawPublic(a.public as ECPublicKey)))
            za.size == 32 && za.contentEquals(zb) && V2.rawPublic(a.public as ECPublicKey).size == 65
        }
        step("pbkdf2") { V2.pbkdf2("ABCDEFGH1234", "muskup-v2|123456789".toByteArray()).size == 32 }
        step("hkdf") {
            val ikm = ByteArray(22) { 0x0b }
            val salt = ByteArray(13) { it.toByte() }
            val info = ByteArray(10) { (0xf0 + it).toByte() }
            V2.hex(V2.hkdf(ikm, salt, info)) == "3cb25f25faacd57a90434f64d0362f2a2d2d0a90cf1a5a4c5db02d56ecc4c5bf"
        }
        step("gcm") {
            val key = V2.random(32); val iv = V2.random(12)
            val enc = Cipher.getInstance("AES/GCM/NoPadding").apply {
                init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv)); updateAAD("aad".toByteArray())
            }.doFinal("test".toByteArray())
            val dec = Cipher.getInstance("AES/GCM/NoPadding").apply {
                init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv)); updateAAD("aad".toByteArray())
            }.doFinal(enc)
            String(dec) == "test"
        }
        step("keystore") { SecureBox.decrypt(SecureBox.encrypt("x")) == "x" }
        return sb.toString().trim()
    }
}
